"""Free, API-key-free Retrieval Service using TF-IDF and Cosine Similarity."""

import os
import re
from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
import numpy as np

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False

from config import SUPPORTED_LANGUAGES


@dataclass
class KnowledgeChunk:
    """A semantic chunk of knowledge for retrieval."""
    chunk_id: str
    source_file: str
    section_title: str
    language: str
    content: str


@dataclass
class RetrievalMatch:
    """A matched knowledge chunk with relevance score."""
    chunk: KnowledgeChunk
    similarity_score: float


@dataclass
class RetrievalResponse:
    """Formatted response from local retrieval."""
    answer: str
    matches: List[RetrievalMatch]
    best_similarity: float
    is_fallback: bool
    source_summary: str


class LocalRetrievalEngine:
    """Lightweight, offline-capable retrieval engine using TF-IDF."""

    def __init__(self, kb_dir: str = "knowledge_base"):
        self.kb_dir = kb_dir
        self.chunks: List[KnowledgeChunk] = []
        self.vectorizer: Optional[TfidfVectorizer] = None
        self.tfidf_matrix = None
        self.is_indexed = False
        self.load_and_index()

    def _split_into_chunks(self, filepath: str, text: str) -> List[KnowledgeChunk]:
        """Split a markdown or text file into section-based chunks."""
        filename = os.path.basename(filepath)
        chunks: List[KnowledgeChunk] = []

        # Guess language from filename or content
        lang = "en"
        lower_name = filename.lower()
        if "hindi" in lower_name or "_hi" in lower_name:
            lang = "hi"
        elif "punjabi" in lower_name or "_pa" in lower_name:
            lang = "pa"
        elif "spanish" in lower_name or "_es" in lower_name:
            lang = "es"
        elif "hinglish" in lower_name:
            lang = "hinglish"

        # Split on markdown headings (## or ###)
        sections = re.split(r"\n(?=#{1,3}\s)", text)
        idx = 0
        for section in sections:
            section = section.strip()
            if not section:
                continue

            lines = section.split("\n", 1)
            first_line = lines[0].strip()
            if first_line.startswith("#"):
                title = first_line.lstrip("#").strip()
                body = lines[1].strip() if len(lines) > 1 else first_line
            else:
                title = f"{filename} - Section {idx + 1}"
                body = section

            if len(body) > 15:  # Skip trivial snippets
                chunks.append(KnowledgeChunk(
                    chunk_id=f"{filename}_{idx}",
                    source_file=filename,
                    section_title=title,
                    language=lang,
                    content=body
                ))
                idx += 1

        return chunks

    def load_and_index(self) -> int:
        """Scan knowledge base directory and compute TF-IDF matrix."""
        self.chunks = []
        if not os.path.exists(self.kb_dir):
            os.makedirs(self.kb_dir, exist_ok=True)

        for root, _, files in os.walk(self.kb_dir):
            for file in files:
                if file.endswith((".md", ".txt")):
                    full_path = os.path.join(root, file)
                    try:
                        with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
                            text = f.read()
                        doc_chunks = self._split_into_chunks(full_path, text)
                        self.chunks.extend(doc_chunks)
                    except Exception as e:
                        print(f"Error loading {full_path}: {e}")

        if not self.chunks:
            # Fallback inline knowledge chunk if directory is empty
            self.chunks.append(KnowledgeChunk(
                chunk_id="default_0",
                source_file="system_guide.md",
                section_title="Multilingual AI Chatbot Default Guide",
                language="en",
                content="The Multilingual AI Chatbot supports English, Hindi, Punjabi, Spanish, and Hinglish. It operates in Free Local Retrieval Mode without requiring any API key."
            ))

        if HAS_SKLEARN and self.chunks:
            corpus = [f"{c.section_title} {c.content}" for c in self.chunks]
            # Use character and word n-grams to bridge multilingual tokenization
            self.vectorizer = TfidfVectorizer(
                token_pattern=r"(?u)\b\w+\b",
                ngram_range=(1, 2),
                sublinear_tf=True
            )
            self.tfidf_matrix = self.vectorizer.fit_transform(corpus)
            self.is_indexed = True

        return len(self.chunks)

    def add_custom_document(self, filename: str, content: str) -> int:
        """Add a dynamic custom document or user upload to the knowledge base."""
        filepath = os.path.join(self.kb_dir, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
        return self.load_and_index()

    def query(self, user_query: str, target_lang: str = "en", top_k: int = 3, threshold: float = 0.08) -> RetrievalResponse:
        """
        Search knowledge base for matches using TF-IDF cosine similarity.
        Returns formatted response with citations.
        """
        if not user_query or not user_query.strip():
            return RetrievalResponse(
                answer="Please enter a question to search the knowledge base.",
                matches=[],
                best_similarity=0.0,
                is_fallback=True,
                source_summary="No query provided"
            )

        if not HAS_SKLEARN or not self.is_indexed or self.vectorizer is None or self.tfidf_matrix is None:
            # Simple keyword matching fallback if sklearn is absent
            return self._keyword_search_fallback(user_query, target_lang)

        # Compute query vector and cosine similarity
        query_vec = self.vectorizer.transform([user_query])
        similarities = cosine_similarity(query_vec, self.tfidf_matrix)[0]

        # Rank indices by similarity descending
        ranked_indices = np.argsort(similarities)[::-1]

        matches: List[RetrievalMatch] = []
        for idx in ranked_indices[:top_k]:
            sim = float(similarities[idx])
            if sim >= threshold:
                matches.append(RetrievalMatch(
                    chunk=self.chunks[idx],
                    similarity_score=round(sim, 3)
                ))

        if not matches:
            fallback_msg = self._generate_fallback_message(target_lang, user_query)
            return RetrievalResponse(
                answer=fallback_msg,
                matches=[],
                best_similarity=float(similarities[ranked_indices[0]]) if len(ranked_indices) > 0 else 0.0,
                is_fallback=True,
                source_summary="No confident knowledge base match"
            )

        # Build informative retrieval answer
        best_match = matches[0]
        answer_text = best_match.chunk.content

        sources_list = [f"`{m.chunk.source_file}` ({m.chunk.section_title}) [Match: {m.similarity_score * 100:.1f}%]" for m in matches]
        sources_summary = ", ".join(sources_list)

        return RetrievalResponse(
            answer=answer_text,
            matches=matches,
            best_similarity=best_match.similarity_score,
            is_fallback=False,
            source_summary=sources_summary
        )

    def _generate_fallback_message(self, target_lang: str, query: str) -> str:
        """Language-appropriate fallback when question is outside the knowledge base."""
        fallbacks = {
            "en": (
                "ℹ️ **No exact match found in the local knowledge base.**\n\n"
                "In **Free Retrieval Mode (No API Key)**, the chatbot answers from verified documents "
                "about chatbot capabilities, language features, and setup guides.\n\n"
                "💡 **Try asking:**\n"
                "- *What languages are supported?*\n"
                "- *How does the dual engine work?*\n"
                "- *How to use manual language override?*\n\n"
                "*Tip: To ask open-domain questions, you can enter an optional Google Gemini API key in the sidebar.*"
            ),
            "hi": (
                "ℹ️ **स्थानीय ज्ञानकोश में कोई सीधा उत्तर नहीं मिला।**\n\n"
                "**निःशुल्क पुनर्प्राप्ति मोड (बिना API कुंजी)** में, चैटबॉट केवल सत्यापित ज्ञानकोश दस्तावेजों से उत्तर देता है।\n\n"
                "💡 **आप यह पूछ सकते हैं:**\n"
                "- *यह चैटबॉट किन भाषाओं का समर्थन करता है?*\n"
                "- *बिना API key के चैटबॉट कैसे काम करता है?*\n"
                "- *भाषा पहचान कैसे काम करती है?*\n\n"
                "*सुझाव: खुली बातचीत के लिए आप साइडबार में Google Gemini API कुंजी जोड़ सकते हैं।*"
            ),
            "pa": (
                "ℹ️ **ਸਥਾਨਕ ਗਿਆਨ-ਭੰਡਾਰ ਵਿੱਚੋਂ ਕੋਈ ਮੇਲ ਨਹੀਂ ਮਿਲਿਆ।**\n\n"
                "**ਮੁਫ਼ਤ ਗਿਆਨ ਮੋਡ (ਬਿਨਾਂ API ਕੁੰਜੀ)** ਵਿੱਚ, ਚੈਟਬੌਟ ਸਿਰਫ਼ ਸ਼ਾਮਲ ਕੀਤੇ ਗਏ ਦਸਤਾਵੇਜ਼ਾਂ ਦੇ ਆਧਾਰ 'ਤੇ ਜਵਾਬ ਦਿੰਦਾ ਹੈ।\n\n"
                "💡 **ਤੁਸੀਂ ਇਹ ਪੁੱਛ ਸਕਦੇ ਹੋ:**\n"
                "- *ਇਹ ਚੈਟਬੌਟ ਕਿਹੜੀਆਂ ਭਾਸ਼ਾਵਾਂ ਦਾ ਸਮਰਥਨ ਕਰਦਾ ਹੈ?*\n"
                "- *ਬਿਨਾਂ API ਕੁੰਜੀ ਦੇ ਇਹ ਕਿਵੇਂ ਕੰਮ ਕਰਦਾ ਹੈ?*\n"
                "- *ਗੁਰਮੁਖੀ ਲਿਪੀ ਵਿੱਚ ਗੱਲਬਾਤ ਕਿਵੇਂ ਕਰੀਏ?*\n\n"
                "*ਸੁਝਾਅ: ਵਿਆਪਕ ਸਵਾਲਾਂ ਲਈ ਤੁਸੀਂ ਸਾਈਡਬਾਰ ਵਿੱਚ ਆਪਣੀ Gemini API ਕੁੰਜੀ ਸ਼ਾਮਲ ਕਰ ਸਕਦੇ ਹੋ।*"
            ),
            "es": (
                "ℹ️ **No se encontró una coincidencia exacta en la base de conocimiento local.**\n\n"
                "En el **Modo Gratuito de Recuperación**, el chatbot responde utilizando documentos verificados sobre capacidades y configuración.\n\n"
                "💡 **Prueba preguntar:**\n"
                "- *¿Qué idiomas son compatibles?*\n"
                "- *¿Cómo funciona el modo sin clave API?*\n"
                "- *¿Cómo cambiar el idioma manualmente?*\n\n"
                "*Consejo: Para preguntas de dominio abierto, puedes ingresar una clave API de Google Gemini en la barra lateral.*"
            ),
            "hinglish": (
                "ℹ️ **Local knowledge base me koi direct match nahi mila.**\n\n"
                "**Free Retrieval Mode (Bina API key)** me chatbot sirf indexed documents ke answers deta hai.\n\n"
                "💡 **Aap yeh pooch sakte hain:**\n"
                "- *Yeh chatbot kon-kon si languages support karta hai?*\n"
                "- *Bina API key ke chatbot kaise kaam karta hai?*\n"
                "- *Manual language override kaise select karein?*\n\n"
                "*Tip: Kisi bhi generic question ke liye aap sidebar me Gemini API key configure kar sakte hain.*"
            )
        }
        return fallbacks.get(target_lang, fallbacks["en"])

    def _keyword_search_fallback(self, query: str, target_lang: str) -> RetrievalResponse:
        """Simple keyword matching when scikit-learn is unavailable."""
        query_words = set(re.findall(r"\w+", query.lower()))
        best_chunk = None
        best_count = 0

        for chunk in self.chunks:
            chunk_words = set(re.findall(r"\w+", (chunk.section_title + " " + chunk.content).lower()))
            common = len(query_words.intersection(chunk_words))
            if common > best_count:
                best_count = common
                best_chunk = chunk

        if best_chunk and best_count > 0:
            sim = min(0.3 + (best_count * 0.1), 0.9)
            return RetrievalResponse(
                answer=best_chunk.content,
                matches=[RetrievalMatch(chunk=best_chunk, similarity_score=sim)],
                best_similarity=sim,
                is_fallback=False,
                source_summary=f"`{best_chunk.source_file}` ({best_chunk.section_title})"
            )

        return RetrievalResponse(
            answer=self._generate_fallback_message(target_lang, query),
            matches=[],
            best_similarity=0.0,
            is_fallback=True,
            source_summary="No keyword match"
        )
