"""Services package for Multilingual AI Chatbot."""
