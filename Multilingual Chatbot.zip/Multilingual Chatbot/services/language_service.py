"""Language detection, classification, and localization service."""

import re
import unicodedata
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

try:
    from langdetect import detect_langs, DetectorFactory
    # Ensure deterministic detection across runs
    DetectorFactory.seed = 0
    HAS_LANGDETECT = True
except ImportError:
    HAS_LANGDETECT = False

from config import SUPPORTED_LANGUAGES, UI_STRINGS


@dataclass
class LanguageDetectionResult:
    """Structured result from language detection."""
    language_code: str
    language_name: str
    confidence: float
    is_low_confidence: bool
    detected_script: str
    details: str
    raw_scores: Dict[str, float] = field(default_factory=dict)


# Common Romanized Hindi (Hinglish) marker tokens
HINGLISH_KEYWORDS = {
    "kya", "kyu", "kyun", "kaise", "kaisa", "kaisi", "kaun", "kab", "kahan", "kidhar",
    "nahi", "nahin", "naa", "haan", "sahi", "theek", "thik", "accha", "achha", "bahut", "bohot",
    "bhai", "yaar", "dost", "aap", "aapka", "aapki", "aapke", "tum", "tumhara", "tumhari",
    "mera", "meri", "mere", "hum", "humara", "humari", "mujhe", "mujhko", "humein",
    "karo", "karna", "karte", "karti", "kiya", "karunga", "karungi", "raha", "rahi", "rahe",
    "hoga", "hogi", "honge", "hai", "hain", "ho", "tha", "thi", "the",
    "batao", "bolo", "samajh", "chahiye", "aaj", "kal", "ab", "abhi", "baat", "shukriya",
    "dhanyawad", "namaste", "alvida", "kaam", "puchna", "poochna", "sawal", "jawab",
    "lekin", "magar", "par", "aur", "bhi", "toh", "to", "matlab", "chal", "chalo"
}

# Distinctive Spanish markers
SPANISH_KEYWORDS = {
    "hola", "gracias", "por", "favor", "buenos", "dias", "noches", "tardes",
    "como", "estas", "bien", "amigo", "amiga", "que", "donde", "cuando", "quien",
    "porque", "para", "con", "sin", "pero", "tambien", "muy", "mucho", "muchas",
    "todos", "todas", "este", "esta", "estos", "estas", "estoy", "esta", "estan",
    "hablar", "espanol", "ingles", "hacer", "quiero", "puedo", "ayuda", "pregunta"
}

# Unicode Script Ranges
UNICODE_SCRIPTS = {
    "Devanagari": (0x0900, 0x097F),
    "Gurmukhi": (0x0A00, 0x0A7F),
    "Latin": (0x0041, 0x007A)
}


def _strip_emojis_and_symbols(text: str) -> str:
    """Remove emojis, symbols, and non-letter punctuation."""
    # Remove emojis and special pictographs
    cleaned = re.sub(
        r"[\U00010000-\U0010ffff\u2600-\u27bf\u2300-\u23ff\u2b50-\u2b55\u200d]",
        "",
        text
    )
    return cleaned.strip()


def _analyze_scripts(text: str) -> Dict[str, int]:
    """Count character frequencies across major unicode script ranges."""
    counts = {"Devanagari": 0, "Gurmukhi": 0, "Latin": 0, "Other": 0}
    for char in text:
        cp = ord(char)
        if 0x0900 <= cp <= 0x097F:
            counts["Devanagari"] += 1
        elif 0x0A00 <= cp <= 0x0A7F:
            counts["Gurmukhi"] += 1
        elif (0x0041 <= cp <= 0x005A) or (0x0061 <= cp <= 0x007A) or (0x00C0 <= cp <= 0x00FF):
            counts["Latin"] += 1
        elif not char.isspace() and not char.isnumeric():
            counts["Other"] += 1
    return counts


def _detect_hinglish(text: str) -> Tuple[bool, float]:
    """Check if Latin text is predominantly Hinglish (code-switched Hindi-English)."""
    words = re.findall(r"\b[a-zA-Z]+\b", text.lower())
    if not words:
        return False, 0.0

    hinglish_matches = sum(1 for w in words if w in HINGLISH_KEYWORDS)
    ratio = hinglish_matches / len(words)

    # If at least 2 distinct Hinglish words or ratio >= 25% for short phrases
    if hinglish_matches >= 2 or (len(words) <= 4 and hinglish_matches >= 1 and ratio >= 0.25):
        confidence = min(0.60 + (ratio * 0.35), 0.95)
        return True, confidence

    return False, ratio


def _detect_spanish_heuristic(text: str) -> Tuple[bool, float]:
    """Identify Spanish specific characters (á, é, í, ó, ú, ñ, ¿, ¡) or keyword markers."""
    lower = text.lower()
    has_spanish_punct = any(ch in text for ch in ["¿", "¡", "ñ", "á", "é", "í", "ó", "ú"])
    words = re.findall(r"\b[a-zA-Záéíóúñ]+\b", lower)

    if not words:
        return False, 0.0

    spanish_matches = sum(1 for w in words if w in SPANISH_KEYWORDS)
    ratio = spanish_matches / len(words)

    if has_spanish_punct:
        return True, 0.92

    if spanish_matches >= 2 or (len(words) <= 4 and spanish_matches >= 1 and ratio >= 0.3):
        return True, min(0.65 + (ratio * 0.30), 0.95)

    return False, ratio


def detect_language(text: str, default_lang: str = "en") -> LanguageDetectionResult:
    """
    Detect the primary language of the user's message.
    Handles:
    - Hindi (Devanagari script)
    - Punjabi (Gurmukhi script)
    - Spanish (Latin script + accents/keywords)
    - Hinglish (Latin script + Hindi lexicon)
    - English (Latin script)
    - Short messages, emojis, ambiguous or low-confidence inputs.
    """
    if not text or not text.strip():
        lang_meta = SUPPORTED_LANGUAGES.get(default_lang, SUPPORTED_LANGUAGES["en"])
        return LanguageDetectionResult(
            language_code=default_lang,
            language_name=lang_meta["name"],
            confidence=0.0,
            is_low_confidence=True,
            detected_script="Empty",
            details="Empty input message; using default language."
        )

    stripped = _strip_emojis_and_symbols(text)
    script_counts = _analyze_scripts(stripped)
    total_letters = script_counts["Devanagari"] + script_counts["Gurmukhi"] + script_counts["Latin"]

    # 1. Check for emoji-only or non-text messages
    if total_letters == 0:
        lang_meta = SUPPORTED_LANGUAGES.get(default_lang, SUPPORTED_LANGUAGES["en"])
        return LanguageDetectionResult(
            language_code=default_lang,
            language_name=lang_meta["name"],
            confidence=0.0,
            is_low_confidence=True,
            detected_script="Symbols/Emojis",
            details="Message contains only emojis or symbols. Maintained current language."
        )

    # 2. Strong Script-Based Detection for Devanagari (Hindi)
    if script_counts["Devanagari"] > 0:
        devanagari_ratio = script_counts["Devanagari"] / total_letters
        if devanagari_ratio >= 0.40:
            conf = min(0.70 + (devanagari_ratio * 0.28), 0.99)
            return LanguageDetectionResult(
                language_code="hi",
                language_name=SUPPORTED_LANGUAGES["hi"]["name"],
                confidence=round(conf, 2),
                is_low_confidence=(conf < 0.60 or len(stripped) < 4),
                detected_script="Devanagari",
                details=f"Devanagari script detected ({devanagari_ratio:.0%} of alphabetic characters)."
            )

    # 3. Strong Script-Based Detection for Gurmukhi (Punjabi)
    if script_counts["Gurmukhi"] > 0:
        gurmukhi_ratio = script_counts["Gurmukhi"] / total_letters
        if gurmukhi_ratio >= 0.40:
            conf = min(0.70 + (gurmukhi_ratio * 0.28), 0.99)
            return LanguageDetectionResult(
                language_code="pa",
                language_name=SUPPORTED_LANGUAGES["pa"]["name"],
                confidence=round(conf, 2),
                is_low_confidence=(conf < 0.60 or len(stripped) < 4),
                detected_script="Gurmukhi",
                details=f"Gurmukhi script detected ({gurmukhi_ratio:.0%} of alphabetic characters)."
            )

    # 4. Check for Hinglish in Latin Script
    is_hinglish, hinglish_conf = _detect_hinglish(stripped)
    if is_hinglish:
        return LanguageDetectionResult(
            language_code="hinglish",
            language_name=SUPPORTED_LANGUAGES["hinglish"]["name"],
            confidence=round(hinglish_conf, 2),
            is_low_confidence=False,
            detected_script="Latin (Hinglish)",
            details="Romanized Hindi (Hinglish) conversational markers identified."
        )

    # 5. Check for Spanish specific characters or lexical heuristics
    is_spanish, spanish_conf = _detect_spanish_heuristic(stripped)

    # 6. Statistical N-Gram Language Detection (langdetect) if available
    statistical_scores: Dict[str, float] = {}
    detected_via_model: Optional[str] = None
    model_conf = 0.50

    if HAS_LANGDETECT:
        try:
            langs = detect_langs(stripped)
            for l in langs:
                statistical_scores[l.lang] = round(l.prob, 3)

            if langs:
                top = langs[0]
                model_conf = top.prob
                if top.lang in ["es"]:
                    detected_via_model = "es"
                elif top.lang in ["hi"]:
                    # Devanagari or transliterated
                    detected_via_model = "hi"
                elif top.lang in ["pa"]:
                    detected_via_model = "pa"
                elif top.lang in ["en"]:
                    detected_via_model = "en"
        except Exception:
            statistical_scores = {}

    # Merge heuristic and statistical findings for Spanish
    if is_spanish or detected_via_model == "es":
        final_conf = max(spanish_conf, model_conf)
        return LanguageDetectionResult(
            language_code="es",
            language_name=SUPPORTED_LANGUAGES["es"]["name"],
            confidence=round(final_conf, 2),
            is_low_confidence=(final_conf < 0.60 or len(stripped) < 6),
            detected_script="Latin",
            details="Spanish language patterns and syntax identified.",
            raw_scores=statistical_scores
        )

    # Check for short or ambiguous English/Latin messages
    words_count = len(stripped.split())
    if words_count < 2 and len(stripped) < 6:
        # Ambiguous short input like "hi", "ok", "yes"
        return LanguageDetectionResult(
            language_code=default_lang,
            language_name=SUPPORTED_LANGUAGES.get(default_lang, SUPPORTED_LANGUAGES["en"])["name"],
            confidence=0.50,
            is_low_confidence=True,
            detected_script="Latin",
            details="Short input with ambiguous language markers. Kept active language.",
            raw_scores=statistical_scores
        )

    # Default to English for standard Latin script
    conf = model_conf if (detected_via_model == "en" and model_conf > 0.5) else 0.85
    return LanguageDetectionResult(
        language_code="en",
        language_name=SUPPORTED_LANGUAGES["en"]["name"],
        confidence=round(conf, 2),
        is_low_confidence=(conf < 0.60),
        detected_script="Latin",
        details="English text structure and grammar identified.",
        raw_scores=statistical_scores
    )


def get_ui_text(key: str, lang_code: str) -> str:
    """Retrieve localized UI text for a key, falling back gracefully to English."""
    normalized_lang = lang_code if lang_code in UI_STRINGS else "en"
    return UI_STRINGS.get(normalized_lang, {}).get(
        key,
        UI_STRINGS["en"].get(key, key)
    )


def get_language_display_label(lang_code: str) -> str:
    """Get human-readable label with flag for a language code."""
    meta = SUPPORTED_LANGUAGES.get(lang_code, SUPPORTED_LANGUAGES["en"])
    return f"{meta['flag']} {meta['name']} ({meta['native_name']})"
