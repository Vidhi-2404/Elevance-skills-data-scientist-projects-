"""Gemini Multilingual LLM Service supporting modern google-genai SDK."""

import os
from dataclasses import dataclass
from typing import List, Dict, Optional, Any

from config import (
    DEFAULT_GEMINI_MODEL,
    FALLBACK_GEMINI_MODELS,
    SUPPORTED_LANGUAGES,
    SYSTEM_PROMPT_TEMPLATE
)

# Modern google-genai SDK
try:
    from google import genai
    from google.genai import types as genai_types
    HAS_NEW_GENAI = True
except ImportError:
    HAS_NEW_GENAI = False

HAS_LEGACY_GENAI = False
try:
    if not HAS_NEW_GENAI:
        import google.generativeai as legacy_genai
        HAS_LEGACY_GENAI = True
except ImportError:
    HAS_LEGACY_GENAI = False



@dataclass
class LLMResponse:
    """Structured response from LLM generation."""
    text: str
    model_name: str
    is_success: bool
    error_message: Optional[str] = None
    target_language: str = "en"


def get_api_key(explicit_key: Optional[str] = None) -> Optional[str]:
    """
    Retrieve Gemini API key with strict fallback order:
    1. Explicit parameter from UI
    2. Environment variable GEMINI_API_KEY
    3. Streamlit secrets (st.secrets["GEMINI_API_KEY"])
    """
    if explicit_key and explicit_key.strip():
        return explicit_key.strip()

    env_key = os.environ.get("GEMINI_API_KEY")
    if env_key and env_key.strip():
        return env_key.strip()

    try:
        import streamlit as st
        if hasattr(st, "secrets") and "GEMINI_API_KEY" in st.secrets:
            secret_key = st.secrets["GEMINI_API_KEY"]
            if secret_key and str(secret_key).strip():
                return str(secret_key).strip()
    except Exception:
        pass

    return None


def is_gemini_available(api_key: Optional[str] = None) -> bool:
    """Check if Gemini SDK and credentials are ready."""
    return bool(get_api_key(api_key)) and (HAS_NEW_GENAI or HAS_LEGACY_GENAI)


def build_system_instruction(target_lang_code: str) -> str:
    """Format the system instruction with target language specifics."""
    meta = SUPPORTED_LANGUAGES.get(target_lang_code, SUPPORTED_LANGUAGES["en"])
    return SYSTEM_PROMPT_TEMPLATE.format(
        target_language_name=f"{meta['name']} ({meta['native_name']})",
        target_language_code=target_lang_code
    )


def generate_multilingual_response(
    messages: List[Dict[str, str]],
    target_language_code: str = "en",
    api_key: Optional[str] = None,
    preferred_model: str = DEFAULT_GEMINI_MODEL
) -> LLMResponse:
    """
    Generate conversational reply in target language with full context history.
    Gracefully handles credentials, rate limits, and network errors.
    """
    active_key = get_api_key(api_key)
    if not active_key:
        return LLMResponse(
            text="Gemini API Key is not configured. Please supply an API key or use Free Local Retrieval Mode.",
            model_name="None",
            is_success=False,
            error_message="Missing GEMINI_API_KEY",
            target_language=target_language_code
        )

    system_instruction = build_system_instruction(target_language_code)
    candidate_models = [preferred_model] + [m for m in FALLBACK_GEMINI_MODELS if m != preferred_model]

    # Try modern google-genai SDK
    if HAS_NEW_GENAI:
        try:
            client = genai.Client(api_key=active_key)
            formatted_contents: List[Any] = []

            for msg in messages:
                role = "user" if msg["role"] == "user" else "model"
                formatted_contents.append(
                    genai_types.Content(
                        role=role,
                        parts=[genai_types.Part.from_text(text=msg["content"])]
                    )
                )

            for model_id in candidate_models:
                try:
                    response = client.models.generate_content(
                        model=model_id,
                        contents=formatted_contents,
                        config=genai_types.GenerateContentConfig(
                            system_instruction=system_instruction,
                            temperature=0.7,
                            max_output_tokens=1024
                        )
                    )
                    if response and response.text:
                        return LLMResponse(
                            text=response.text.strip(),
                            model_name=model_id,
                            is_success=True,
                            target_language=target_language_code
                        )
                except Exception as model_err:
                    # Try next candidate model if available
                    continue
        except Exception as e:
            pass

    # Try legacy google-generativeai SDK as backup
    if HAS_LEGACY_GENAI:
        try:
            legacy_genai.configure(api_key=active_key)
            for model_id in candidate_models:
                try:
                    model = legacy_genai.GenerativeModel(
                        model_name=model_id,
                        system_instruction=system_instruction
                    )
                    # Convert history
                    chat_history = []
                    for msg in messages[:-1]:
                        role = "user" if msg["role"] == "user" else "model"
                        chat_history.append({"role": role, "parts": [msg["content"]]})

                    chat = model.start_chat(history=chat_history)
                    latest_query = messages[-1]["content"] if messages else ""
                    resp = chat.send_message(latest_query)
                    if resp and resp.text:
                        return LLMResponse(
                            text=resp.text.strip(),
                            model_name=model_id,
                            is_success=True,
                            target_language=target_language_code
                        )
                except Exception:
                    continue
        except Exception as e:
            return LLMResponse(
                text=f"Error connecting to Gemini API: {str(e)}",
                model_name="error",
                is_success=False,
                error_message=str(e),
                target_language=target_language_code
            )

    return LLMResponse(
        text="Could not reach Gemini service. Please verify your API key and network connection, or switch to Free Local Retrieval Mode.",
        model_name="error",
        is_success=False,
        error_message="All candidate models failed",
        target_language=target_language_code
    )
