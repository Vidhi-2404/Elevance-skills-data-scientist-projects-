"""Tests for language detection, script analysis, and localization."""

import pytest
from services.language_service import (
    detect_language,
    get_ui_text,
    get_language_display_label,
    LanguageDetectionResult
)


class TestLanguageDetection:
    """Test suite for language detection across supported languages and edge cases."""

    def test_english_detection(self):
        query = "What are the core capabilities of this multilingual chatbot?"
        res = detect_language(query)
        assert res.language_code == "en"
        assert res.detected_script == "Latin"
        assert res.confidence >= 0.70
        assert not res.is_low_confidence

    def test_hindi_devanagari_detection(self):
        query = "यह बहुभाषी चैटबॉट किन भाषाओं का समर्थन करता है?"
        res = detect_language(query)
        assert res.language_code == "hi"
        assert res.detected_script == "Devanagari"
        assert res.confidence >= 0.80

    def test_punjabi_gurmukhi_detection(self):
        query = "ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ ਜੀ, ਇਹ ਬਹੁਭਾਸ਼ਾਈ ਚੈਟਬੌਟ ਕਿਵੇਂ ਕੰਮ ਕਰਦਾ ਹੈ?"
        res = detect_language(query)
        assert res.language_code == "pa"
        assert res.detected_script == "Gurmukhi"
        assert res.confidence >= 0.80

    def test_spanish_detection(self):
        query = "¿Cómo funciona este chatbot multilingüe y qué modos tiene?"
        res = detect_language(query)
        assert res.language_code == "es"
        assert res.confidence >= 0.70

    def test_hinglish_code_switched_detection(self):
        query = "kya haal hai bhai mujhe python aur chatbot me help chahiye"
        res = detect_language(query)
        assert res.language_code == "hinglish"
        assert "Hinglish" in res.detected_script
        assert res.confidence >= 0.60

    def test_short_ambiguous_text(self):
        query = "ok"
        res = detect_language(query, default_lang="en")
        # Should gracefully flag low confidence or maintain default
        assert res.is_low_confidence is True
        assert res.confidence <= 0.60

    def test_emoji_only_text(self):
        query = "😀 🚀 ✨ 🎉"
        res = detect_language(query, default_lang="hi")
        # Emoji only should maintain the default active language
        assert res.language_code == "hi"
        assert res.is_low_confidence is True
        assert res.detected_script == "Symbols/Emojis"

    def test_empty_string(self):
        res = detect_language("", default_lang="pa")
        assert res.language_code == "pa"
        assert res.is_low_confidence is True


class TestLocalizationHelpers:
    """Test suite for localized strings and labels."""

    def test_get_ui_text_supported_languages(self):
        for lang in ["en", "hi", "pa", "es", "hinglish"]:
            text = get_ui_text("clear_chat", lang)
            assert isinstance(text, str)
            assert len(text) > 0

    def test_get_ui_text_fallback_for_unknown_lang(self):
        # Unknown language should fall back to English string safely
        text = get_ui_text("clear_chat", "xx")
        assert text == "Clear Conversation"

    def test_display_labels(self):
        label_hi = get_language_display_label("hi")
        assert "हिन्दी" in label_hi
        assert "🇮🇳" in label_hi

        label_pa = get_language_display_label("pa")
        assert "ਪੰਜਾਬੀ" in label_pa

        label_es = get_language_display_label("es")
        assert "Español" in label_es
