"""Tests for Local Retrieval Service (TF-IDF & Cosine Similarity)."""

import os
import pytest
from services.retrieval_service import LocalRetrievalEngine, RetrievalResponse


class TestLocalRetrievalEngine:
    """Test suite for offline knowledge base retrieval."""

    @pytest.fixture(scope="class")
    def engine(self):
        engine = LocalRetrievalEngine(kb_dir="knowledge_base")
        return engine

    def test_knowledge_base_indexing(self, engine):
        assert engine.is_indexed is True
        assert len(engine.chunks) > 0
        assert engine.tfidf_matrix is not None

    def test_english_query_retrieval(self, engine):
        res: RetrievalResponse = engine.query(
            "What are the supported languages and operating modes?",
            target_lang="en"
        )
        assert not res.is_fallback
        assert res.best_similarity > 0.10
        assert len(res.matches) > 0
        assert "kb_multilingual_chatbot.md" in res.source_summary

    def test_hindi_query_retrieval(self, engine):
        res: RetrievalResponse = engine.query(
            "चैटबॉट किन भाषाओं का समर्थन करता है?",
            target_lang="hi"
        )
        assert not res.is_fallback
        assert res.best_similarity > 0.10
        assert len(res.matches) > 0

    def test_punjabi_query_retrieval(self, engine):
        res: RetrievalResponse = engine.query(
            "ਇਹ ਚੈਟਬੌਟ ਕਿਹੜੀਆਂ ਭਾਸ਼ਾਵਾਂ ਦਾ ਸਮਰਥਨ ਕਰਦਾ ਹੈ?",
            target_lang="pa"
        )
        assert not res.is_fallback
        assert res.best_similarity > 0.10

    def test_spanish_query_retrieval(self, engine):
        res: RetrievalResponse = engine.query(
            "¿Cuáles son los idiomas compatibles y los modos de operación?",
            target_lang="es"
        )
        assert not res.is_fallback
        assert res.best_similarity > 0.10

    def test_hinglish_query_retrieval(self, engine):
        res: RetrievalResponse = engine.query(
            "bina api key ke free mode kaise chalta hai",
            target_lang="hinglish"
        )
        assert not res.is_fallback
        assert res.best_similarity > 0.10

    def test_out_of_scope_query_fallback(self, engine):
        # A completely irrelevant query should trigger graceful fallback message
        res: RetrievalResponse = engine.query(
            "what is the recipe for chocolate chip pancakes with syrup",
            target_lang="en",
            threshold=0.35
        )
        assert res.is_fallback is True
        assert "No exact match found" in res.answer or "Free Retrieval Mode" in res.answer

    def test_empty_query(self, engine):
        res = engine.query("", target_lang="en")
        assert res.is_fallback is True
        assert res.best_similarity == 0.0
