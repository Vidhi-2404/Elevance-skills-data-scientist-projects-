"""Tests for LLM service (Gemini SDK integration and error handling)."""

import os
from unittest.mock import patch, MagicMock
import pytest
from services.llm_service import (
    get_api_key,
    is_gemini_available,
    build_system_instruction,
    generate_multilingual_response,
    LLMResponse
)


class TestLLMService:
    """Test suite for LLM integration, credential handling, and language prompts."""

    def test_missing_credentials_handling(self):
        # When no API key is provided in environment, explicit, or secrets
        with patch.dict(os.environ, {}, clear=True):
            key = get_api_key(explicit_key=None)
            assert key is None
            assert is_gemini_available(api_key=None) is False

            # generate_multilingual_response should gracefully return error without raising
            resp = generate_multilingual_response(
                messages=[{"role": "user", "content": "Hello"}],
                target_language_code="en",
                api_key=None
            )
            assert resp.is_success is False
            assert "Missing GEMINI_API_KEY" in resp.error_message

    def test_explicit_api_key_override(self):
        test_key = "test_custom_gemini_key_12345"
        key = get_api_key(explicit_key=test_key)
        assert key == test_key

    def test_build_system_instruction_languages(self):
        inst_hi = build_system_instruction("hi")
        assert "हिन्दी" in inst_hi
        assert "Devanagari" in inst_hi

        inst_pa = build_system_instruction("pa")
        assert "ਪੰਜਾਬੀ" in inst_pa
        assert "Gurmukhi" in inst_pa

        inst_es = build_system_instruction("es")
        assert "Español" in inst_es

        inst_hinglish = build_system_instruction("hinglish")
        assert "Hinglish" in inst_hinglish

    @patch("services.llm_service.genai.Client")
    def test_mocked_gemini_response_generation(self, mock_client_cls):
        # Mock modern genai.Client response
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.text = "नमस्ते! मैं आपकी सहायता के लिए तैयार हूँ।"
        mock_client.models.generate_content.return_value = mock_response
        mock_client_cls.return_value = mock_client

        history = [
            {"role": "user", "content": "नमस्ते, आप कौन हैं?"}
        ]

        resp = generate_multilingual_response(
            messages=history,
            target_language_code="hi",
            api_key="dummy_valid_key"
        )

        assert resp.is_success is True
        assert "नमस्ते" in resp.text
        assert resp.target_language == "hi"
