"""Integration tests for conversational context retention and language switching."""

import pytest
from services.language_service import detect_language
from services.retrieval_service import LocalRetrievalEngine


class TestConversationalIntegration:
    """Test multi-turn conversation logic, switching languages, and history tracking."""

    @pytest.fixture(scope="class")
    def engine(self):
        return LocalRetrievalEngine(kb_dir="knowledge_base")

    def test_multi_turn_language_switch_conversation(self, engine):
        """Simulate a user starting in English, switching to Hindi, then to Spanish."""
        conversation_history = []

        # Turn 1: English
        user_msg_1 = "What are the capabilities of this chatbot?"
        det_1 = detect_language(user_msg_1, default_lang="en")
        assert det_1.language_code == "en"

        conversation_history.append({"role": "user", "content": user_msg_1, "language": det_1.language_code})
        resp_1 = engine.query(user_msg_1, target_lang=det_1.language_code)
        conversation_history.append({"role": "assistant", "content": resp_1.answer, "language": det_1.language_code})

        assert len(conversation_history) == 2

        # Turn 2: Switch to Hindi
        user_msg_2 = "यह चैटबॉट किन भाषाओं का समर्थन करता है?"
        det_2 = detect_language(user_msg_2, default_lang=det_1.language_code)
        assert det_2.language_code == "hi"

        conversation_history.append({"role": "user", "content": user_msg_2, "language": det_2.language_code})
        resp_2 = engine.query(user_msg_2, target_lang=det_2.language_code)
        conversation_history.append({"role": "assistant", "content": resp_2.answer, "language": det_2.language_code})

        # Turn 3: Switch to Spanish
        user_msg_3 = "¿Cómo funciona el modo sin clave de API?"
        det_3 = detect_language(user_msg_3, default_lang=det_2.language_code)
        assert det_3.language_code == "es"

        conversation_history.append({"role": "user", "content": user_msg_3, "language": det_3.language_code})
        resp_3 = engine.query(user_msg_3, target_lang=det_3.language_code)
        conversation_history.append({"role": "assistant", "content": resp_3.answer, "language": det_3.language_code})

        # Verify all turns are preserved
        assert len(conversation_history) == 6
        languages = [msg["language"] for msg in conversation_history]
        assert languages == ["en", "en", "hi", "hi", "es", "es"]

    def test_manual_override_priority(self, engine):
        """When manual override is active, the response language should honor user choice."""
        # User types in English, but manual override is Hindi
        user_msg = "Hello there"
        override_lang = "hi"

        resp = engine.query(user_msg, target_lang=override_lang)
        # Result should respond with Hindi fallback or context
        assert resp is not None
