"""Configuration and constants for the Multilingual AI Chatbot."""

import os
from typing import Dict, Any

# Application Metadata
APP_TITLE = "Multilingual AI Chatbot"
APP_TAGLINE = "Intelligent conversations in English, हिन्दी, ਪੰਜਾਬੀ, and Español"
APP_VERSION = "1.0.0"

# Default Model Configuration
DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"
FALLBACK_GEMINI_MODELS = ["gemini-1.5-flash", "gemini-1.5-pro"]

# Supported Languages Mapping
# Language code -> details
SUPPORTED_LANGUAGES: Dict[str, Dict[str, str]] = {
    "en": {
        "name": "English",
        "native_name": "English",
        "flag": "🇬🇧",
        "script": "Latin",
        "sample": "Hello! How can I help you today?"
    },
    "hi": {
        "name": "Hindi",
        "native_name": "हिन्दी",
        "flag": "🇮🇳",
        "script": "Devanagari",
        "sample": "नमस्ते! आज मैं आपकी क्या सहायता कर सकता हूँ?"
    },
    "pa": {
        "name": "Punjabi",
        "native_name": "ਪੰਜਾਬੀ",
        "flag": "🇮🇳",
        "script": "Gurmukhi",
        "sample": "ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ! ਅੱਜ ਮੈਂ ਤੁਹਾਡੀ ਕਿਵੇਂ ਮਦਦ ਕਰ ਸਕਦਾ ਹਾਂ?"
    },
    "es": {
        "name": "Spanish",
        "native_name": "Español",
        "flag": "🇪🇸",
        "script": "Latin",
        "sample": "¡Hola! ¿En qué puedo ayudarte hoy?"
    },
    "hinglish": {
        "name": "Hinglish",
        "native_name": "Hinglish (Hindi in Roman script)",
        "flag": "🇮🇳",
        "script": "Latin (Code-switched)",
        "sample": "Namaste! Main aapki kya help kar sakta hoon?"
    }
}

# UI Localized Strings for Interface Elements
UI_STRINGS: Dict[str, Dict[str, str]] = {
    "en": {
        "input_placeholder": "Ask a question in English, Hindi, Punjabi, Spanish, or Hinglish...",
        "clear_chat": "Clear Conversation",
        "settings": "Settings & Language Control",
        "lang_mode": "Language Selection Mode",
        "auto_detect": "Automatic Detection",
        "manual_override": "Manual Override",
        "active_language": "Active Language",
        "detected_language": "Detected Language",
        "confidence": "Confidence",
        "execution_mode": "Inference Engine",
        "free_mode": "Free Local Retrieval Mode (No API Key Required)",
        "gemini_mode": "Google Gemini Generative AI",
        "source_reference": "Verified Knowledge Base Sources",
        "similarity_score": "Similarity Match",
        "retrieval_notice": "ℹ️ Response generated using verified local knowledge-base retrieval (Free Mode, 100% offline-capable, no API key).",
        "gemini_notice": "✨ Response generated with Google Gemini Generative AI.",
        "low_confidence_warning": "⚠️ Low confidence detection. You can manually set the language in the sidebar if needed.",
        "sample_questions_title": "💡 Suggested Questions:",
        "knowledge_base_title": "📚 Knowledge Base Status",
        "docs_loaded": "documents indexed"
    },
    "hi": {
        "input_placeholder": "हिन्दी, English, ਪੰਜਾਬੀ, Español या Hinglish में प्रश्न पूछें...",
        "clear_chat": "बातचीत साफ़ करें",
        "settings": "सेटिंग्स और भाषा नियंत्रण",
        "lang_mode": "भाषा चयन मोड",
        "auto_detect": "स्वचालित पहचान (Auto-detect)",
        "manual_override": "मैन्युअल चयन (Manual Override)",
        "active_language": "सक्रिय भाषा",
        "detected_language": "पहचानी गई भाषा",
        "confidence": "सटीकता / विश्वास स्तर",
        "execution_mode": "इंजन मोड",
        "free_mode": "निःशुल्क स्थानीय पुनर्प्राप्ति मोड (Free Local Retrieval)",
        "gemini_mode": "गूगल जेमिनी जेनेरेटिव एआई (Google Gemini)",
        "source_reference": "सत्यापित ज्ञानकोश स्रोत (Sources)",
        "similarity_score": "समानता स्कोर",
        "retrieval_notice": "ℹ️ यह उत्तर सत्यापित स्थानीय ज्ञानकोश से पुनर्प्राप्त किया गया है (निःशुल्क मोड, बिना किसी API कुंजी के)।",
        "gemini_notice": "✨ यह उत्तर Google Gemini AI द्वारा तैयार किया गया है।",
        "low_confidence_warning": "⚠️ भाषा पहचान में कम सटीकता। आप साइडबार में भाषा चुन सकते हैं।",
        "sample_questions_title": "💡 सुझाए गए प्रश्न:",
        "knowledge_base_title": "📚 ज्ञानकोश स्थिति",
        "docs_loaded": "दस्तावेज़ लोड किए गए"
    },
    "pa": {
        "input_placeholder": "ਪੰਜਾਬੀ, हिन्दी, English, Español ਜਾਂ Hinglish ਵਿੱਚ ਸਵਾਲ ਪੁੱਛੋ...",
        "clear_chat": "ਗੱਲਬਾਤ ਸਾਫ਼ ਕਰੋ",
        "settings": "ਸੈਟਿੰਗਾਂ ਅਤੇ ਭਾਸ਼ਾ ਨਿਯੰਤਰਣ",
        "lang_mode": "ਭਾਸ਼ਾ ਚੋਣ ਮੋਡ",
        "auto_detect": "ਸਵੈ-ਚਾਲਤ ਪਛਾਣ (Auto-detect)",
        "manual_override": "ਮੈਨੂਅਲ ਚੋਣ (Manual Override)",
        "active_language": "ਸਰਗਰਮ ਭਾਸ਼ਾ",
        "detected_language": "ਪਛਾਣੀ ਗਈ ਭਾਸ਼ਾ",
        "confidence": "ਭਰੋਸੇਯੋਗਤਾ ਦਰ",
        "execution_mode": "ਇੰਜਨ ਮੋਡ",
        "free_mode": "ਮੁਫ਼ਤ ਸਥਾਨਕ ਗਿਆਨ ਮੋਡ (Free Retrieval)",
        "gemini_mode": "ਗੂਗਲ ਜੇਮਿਨੀ ਏਆਈ (Google Gemini)",
        "source_reference": "ਪ੍ਰਮਾਣਿਤ ਗਿਆਨ ਸਰੋਤ (Sources)",
        "similarity_score": "ਸਮਾਨਤਾ ਮੇਲ",
        "retrieval_notice": "ℹ️ ਇਹ ਜਵਾਬ ਮੁਫ਼ਤ ਸਥਾਨਕ ਗਿਆਨ-ਭੰਡਾਰ ਰਾਹੀਂ ਤਿਆਰ ਕੀਤਾ ਗਿਆ ਹੈ (ਬਿਨਾਂ ਕਿਸੇ API ਕੁੰਜੀ ਦੇ)।",
        "gemini_notice": "✨ ਇਹ ਜਵਾਬ Google Gemini AI ਦੁਆਰਾ ਤਿਆਰ ਕੀਤਾ ਗਿਆ ਹੈ।",
        "low_confidence_warning": "⚠️ ਭਾਸ਼ਾ ਦੀ ਪਛਾਣ ਘੱਟ ਭਰੋਸੇਯੋਗ ਹੈ। ਤੁਸੀਂ ਸਾਈਡਬਾਰ ਵਿੱਚ ਭਾਸ਼ਾ ਚੁਣ ਸਕਦੇ ਹੋ।",
        "sample_questions_title": "💡 ਸੁਝਾਏ ਗਏ ਸਵਾਲ:",
        "knowledge_base_title": "📚 ਗਿਆਨ-ਭੰਡਾਰ ਸਥਿਤੀ",
        "docs_loaded": "ਦਸਤਾਵੇਜ਼ ਸ਼ਾਮਲ ਹਨ"
    },
    "es": {
        "input_placeholder": "Escribe una pregunta en español, inglés, hindi, punjabi o hinglish...",
        "clear_chat": "Borrar conversación",
        "settings": "Configuración y Control de Idioma",
        "lang_mode": "Modo de selección de idioma",
        "auto_detect": "Detección automática",
        "manual_override": "Selección manual",
        "active_language": "Idioma activo",
        "detected_language": "Idioma detectado",
        "confidence": "Nivel de confianza",
        "execution_mode": "Motor de inferencia",
        "free_mode": "Modo de recuperación local gratuito (sin clave API)",
        "gemini_mode": "IA generativa Google Gemini",
        "source_reference": "Fuentes verificadas de la base de conocimiento",
        "similarity_score": "Coincidencia de similitud",
        "retrieval_notice": "ℹ️ Respuesta generada mediante recuperación de conocimiento local verificada (Modo gratuito, 100% offline, sin clave API).",
        "gemini_notice": "✨ Respuesta generada con Google Gemini AI.",
        "low_confidence_warning": "⚠️ Detección con baja confianza. Puedes seleccionar el idioma manualmente en la barra lateral.",
        "sample_questions_title": "💡 Preguntas sugeridas:",
        "knowledge_base_title": "📚 Estado de la Base de Conocimiento",
        "docs_loaded": "documentos indexados"
    },
    "hinglish": {
        "input_placeholder": "Hinglish, Hindi, English, Punjabi ya Spanish mein sawal poochhein...",
        "clear_chat": "Chat Reset Karein",
        "settings": "Settings & Language Control",
        "lang_mode": "Language Selection Mode",
        "auto_detect": "Automatic Detection",
        "manual_override": "Manual Override",
        "active_language": "Active Language",
        "detected_language": "Detected Language",
        "confidence": "Confidence Score",
        "execution_mode": "Engine Mode",
        "free_mode": "Free Local Retrieval Mode (No API Key Required)",
        "gemini_mode": "Google Gemini AI Mode",
        "source_reference": "Knowledge Base Sources",
        "similarity_score": "Similarity Match",
        "retrieval_notice": "ℹ️ Yeh answer verified local knowledge-base se retrieve kiya gaya hai (Free Mode, bina kisi API key ke).",
        "gemini_notice": "✨ Yeh answer Google Gemini AI se generate kiya gaya hai.",
        "low_confidence_warning": "⚠️ Detection confidence kam hai. Aap sidebar se manually language choose kar sakte hain.",
        "sample_questions_title": "💡 Suggested Questions:",
        "knowledge_base_title": "📚 Knowledge Base Status",
        "docs_loaded": "documents ready hain"
    }
}

# System Prompt Template for Gemini Generative Mode
SYSTEM_PROMPT_TEMPLATE = """You are a polite, helpful, and highly competent Multilingual AI Assistant.
Target Language for this response: {target_language_name} ({target_language_code}).

CORE BEHAVIOR GUIDELINES:
1. Respond fluently and naturally in the requested target language: {target_language_name}.
   - If the target language is Hinglish, reply in natural, friendly Hinglish (Hindi written in the Roman/Latin alphabet).
   - If Hindi, use standard respectful Hindi in Devanagari script.
   - If Punjabi, use authentic respectful Punjabi in Gurmukhi script.
   - If Spanish, use natural, clear Spanish with proper accentuation.
   - If English, use clean, helpful English.
2. Maintain conversation continuity: If the user switched language mid-conversation, remember all previous context, concepts, and details from prior messages, but seamlessly provide your new reply in the requested target language.
3. Preserve proper nouns, entity names, programming syntax, code snippets, and standard technical terms without unnecessary or awkward transliteration.
4. Uphold the highest standards of safety, respect, and factuality. Do not invent false facts or hallucinate citations.
5. If you do not know the answer or lack enough context, be honest and admit it politely in the target language.
"""

# Sample Questions for Quick Testing
SAMPLE_QUESTIONS = [
    {"lang": "en", "label": "🇬🇧 English", "query": "What are the capabilities of this multilingual chatbot?"},
    {"lang": "hi", "label": "🇮🇳 हिन्दी", "query": "यह बहुभाषी चैटबॉट किन भाषाओं का समर्थन करता है?"},
    {"lang": "pa", "label": "🇮🇳 ਪੰਜਾਬੀ", "query": "ਇਹ ਬਹੁਭਾਸ਼ਾਈ ਚੈਟਬੌਟ ਕਿਵੇਂ ਕੰਮ ਕਰਦਾ ਹੈ?"},
    {"lang": "es", "label": "🇪🇸 Español", "query": "¿Cómo funciona este chatbot multilingüe y qué modos tiene?"},
    {"lang": "hinglish", "label": "🇮🇳 Hinglish", "query": "Yeh chatbot bina API key ke kaise chalta hai?"}
]
