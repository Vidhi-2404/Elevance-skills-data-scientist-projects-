# Chatbot de Inteligencia Artificial Multilingüe - Base de Conocimiento en Español

## Introducción y Propósito
El Chatbot de IA Multilingüe es una solución de comunicación conversacional de última generación, creada para permitir diálogos naturales y fluidos en múltiples idiomas: inglés, hindi, punyabí, español y hinglish.

## Modos de Operación
1. **Modo Gratuito de Recuperación Local (Sin Clave API)**:
   - Este modo funciona 100% de manera local en Streamlit Community Cloud utilizando técnicas de indexación TF-IDF y similitud coseno.
   - Permite responder preguntas basadas en esta base de conocimientos sin requerir ninguna clave de API ni generar costes.
   - Incluye referencias transparentes de las fuentes y el porcentaje de similitud encontrado.
2. **Modo Generativo con Google Gemini**:
   - Se activa opcionalmente si el usuario proporciona una clave `GEMINI_API_KEY`.
   - Proporciona respuestas generativas completas manteniendo el hilo conversacional y el contexto entre diferentes idiomas.

## Idiomas Compatibles
- **Español (es)**: Compatible con acentos y puntuación española (á, é, í, ó, ú, ñ, ¿, ¡).
- **Inglés (en)**: Comunicación técnica y general en alfabeto latino.
- **Hindi (hi)**: Escritura estándar en alfabeto devanagari.
- **Punyabí (pa)**: Escritura en alfabeto gurmukhi.
- **Hinglish (hinglish)**: Hindi conversacional escrito en alfabeto latino.
