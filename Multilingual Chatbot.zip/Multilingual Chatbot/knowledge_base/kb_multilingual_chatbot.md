# Multilingual AI Chatbot: System Architecture & User Guide

## Overview
The Multilingual AI Chatbot is an intelligent conversational platform designed to bridge language barriers across diverse linguistic communities. It natively supports English, Hindi (हिन्दी), Punjabi (ਪੰਜਾਬੀ), Spanish (Español), and Hinglish (code-switched Hindi-English).

## Dual Operating Modes
1. **Free Local Retrieval Mode (Zero API Key Required)**:
   - Operates 100% locally and cost-free using TF-IDF vectorization and cosine similarity matching over this curated knowledge base.
   - Ideal for public deployment on Streamlit Community Cloud without exposing credentials or requiring paid tokens.
   - Provides exact document citations, similarity match percentages, and transparent source references.
2. **Google Gemini Generative AI Mode**:
   - Optional enhancement enabled when a valid Google Gemini API Key (`GEMINI_API_KEY`) is provided via environment variables or Streamlit secrets.
   - Supports generative conversational dialogue with context retention across multiple language switches.

## Supported Languages & Scripts
- **English (`en`)**: Global lingua franca in standard Latin script.
- **Hindi (`hi`)**: Official language of India, written in Devanagari script (`[\u0900-\u097F]`).
- **Punjabi (`pa`)**: Prominent South Asian language, written in authentic Gurmukhi script (`[\u0A00-\u0A7F]`).
- **Spanish (`es`)**: Major Romance language spoken worldwide, written in Latin script with distinctive diacritics (á, é, í, ó, ú, ñ).
- **Hinglish (`hinglish`)**: Conversational hybrid of Hindi written in the Latin alphabet, heavily utilized across digital communication.

## Language Detection Mechanism
The system utilizes a hybrid detection pipeline:
1. Unicode script boundary analysis for Devanagari and Gurmukhi scripts with high precision.
2. Lexicon and phonetic marker inspection for Hinglish code-switching detection.
3. Statistical n-gram language detection (`langdetect`) with deterministic seeding for Latin-based languages.
4. Ambiguity and emoji-only filters that gracefully preserve existing conversational context when short or symbolic text is provided.
5. Instant manual language override accessible directly in the sidebar settings.
