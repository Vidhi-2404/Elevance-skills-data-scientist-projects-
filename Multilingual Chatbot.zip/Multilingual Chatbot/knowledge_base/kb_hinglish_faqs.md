# Multilingual Chatbot Guide - Hinglish Knowledge Base

## Introduction
Yeh Multilingual AI Chatbot ek smart conversational assistant hai jo multiple languages me baatein kar sakta hai: English, Hindi, Punjabi, Spanish, aur Hinglish.

## Key Features & Modes
1. **Free Local Retrieval Mode (Bina Kisi API Key Ke)**:
   - Yeh chatbot Streamlit Community Cloud par bina kisi Gemini API key ke 100% free kaam karta hai.
   - Yeh local knowledge-base se TF-IDF aur cosine similarity matching ke zariye sawalon ka accurate jawab dhoondhta hai.
   - Har jawab ke saath source document aur similarity match percentage transparently dikhata hai.
2. **Google Gemini AI Mode**:
   - Agar aapke paas Gemini API Key hai, toh aap generative AI responses enable kar sakte hain.
   - Gemini mode me chatbot natural conversational dialogue deta hai aur language switch karne par bhi purana context yaad rakhta hai.

## Kaise Use Karein
- Bas chat box me apna message type karein (English, Hindi, Punjabi, Spanish ya Hinglish).
- Chatbot automatically language detect kar lega.
- Agar aap manually language set karna chahte hain, toh sidebar me "Manual Override" select karein.
- Chat history reset karne ke liye sidebar me "Clear Conversation" button click karein.
