"""Multilingual AI Chatbot - Standalone Streamlit Application.

Supports English, Hindi, Punjabi, Spanish, and Hinglish.
Features dual inference modes:
1. Free Local Retrieval Mode (100% offline, zero API keys required).
2. Google Gemini Generative AI Mode (optional enhancement).
"""

import os
import streamlit as st

# Configure Streamlit page settings first
st.set_page_config(
    page_title="Multilingual AI Chatbot",
    page_icon="🌐",
    layout="wide",
    initial_sidebar_state="expanded"
)

from config import (
    APP_TITLE,
    APP_TAGLINE,
    APP_VERSION,
    SUPPORTED_LANGUAGES,
    DEFAULT_GEMINI_MODEL,
    SAMPLE_QUESTIONS
)
from services.language_service import (
    detect_language,
    get_ui_text,
    get_language_display_label,
    LanguageDetectionResult
)
from services.retrieval_service import LocalRetrievalEngine, RetrievalResponse
from services.llm_service import (
    generate_multilingual_response,
    is_gemini_available,
    get_api_key
)

# Custom Responsive CSS for a sleek conversational UI (Not a dashboard)
CUSTOM_CSS = """
<style>
/* Modern Fonts & Base Theme */
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');

html, body, [class*="css"] {
    font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
}

/* Header Banner */
.chat-header-container {
    padding: 1.25rem 1.5rem;
    border-radius: 16px;
    background: linear-gradient(135deg, rgba(30, 41, 59, 0.7) 0%, rgba(15, 23, 42, 0.85) 100%);
    border: 1px solid rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(12px);
    margin-bottom: 1.5rem;
    box-shadow: 0 4px 20px -2px rgba(0, 0, 0, 0.25);
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
}

.chat-header-title {
    font-size: 1.6rem;
    font-weight: 700;
    color: #f8fafc;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.chat-header-subtitle {
    font-size: 0.9rem;
    color: #94a3b8;
    margin-top: 0.25rem;
}

/* Badges */
.badge-group {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
    align-items: center;
}

.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.35rem;
    padding: 0.35rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.8rem;
    font-weight: 600;
    letter-spacing: 0.02em;
}

.badge-mode-free {
    background: rgba(16, 185, 129, 0.15);
    color: #34d399;
    border: 1px solid rgba(16, 185, 129, 0.3);
}

.badge-mode-gemini {
    background: rgba(99, 102, 241, 0.15);
    color: #818cf8;
    border: 1px solid rgba(99, 102, 241, 0.3);
}

.badge-lang {
    background: rgba(255, 255, 255, 0.08);
    color: #e2e8f0;
    border: 1px solid rgba(255, 255, 255, 0.12);
}

/* Chat Message Styling */
.user-meta-pill {
    font-size: 0.75rem;
    color: #94a3b8;
    margin-bottom: 0.25rem;
    font-weight: 500;
}

.assistant-source-card {
    margin-top: 0.75rem;
    padding: 0.65rem 0.85rem;
    border-radius: 10px;
    background: rgba(15, 23, 42, 0.6);
    border: 1px dashed rgba(255, 255, 255, 0.15);
    font-size: 0.82rem;
    color: #94a3b8;
}

.assistant-source-card strong {
    color: #38bdf8;
}

/* Quick prompt pills */
.quick-prompt-btn {
    margin-bottom: 0.4rem;
}

/* Mobile Responsiveness */
@media (max-width: 768px) {
    .chat-header-container {
        padding: 1rem;
        flex-direction: column;
        align-items: flex-start;
    }
    .chat-header-title {
        font-size: 1.3rem;
    }
}
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


@st.cache_resource
def get_retrieval_engine() -> LocalRetrievalEngine:
    """Initialize and cache the local retrieval engine."""
    return LocalRetrievalEngine(kb_dir="knowledge_base")


# Initialize session states
if "messages" not in st.session_state:
    st.session_state.messages = []

if "active_language" not in st.session_state:
    st.session_state.active_language = "en"

if "last_detection" not in st.session_state:
    st.session_state.last_detection = None

if "custom_api_key" not in st.session_state:
    st.session_state.custom_api_key = ""

# Load Retrieval Engine
retrieval_engine = get_retrieval_engine()

# -------------------------------------------------------------
# SIDEBAR CONTROLS
# -------------------------------------------------------------
with st.sidebar:
    st.markdown("### 🌐 Language Controls")

    lang_mode = st.radio(
        "Detection Strategy",
        options=["auto", "manual"],
        format_func=lambda x: "✨ Automatic Detection" if x == "auto" else "📌 Manual Override",
        help="In Automatic mode, the chatbot detects Hindi, Punjabi, Spanish, Hinglish, or English automatically. In Manual mode, you fix the active response language."
    )

    if lang_mode == "manual":
        selected_lang = st.selectbox(
            "Select Response Language",
            options=list(SUPPORTED_LANGUAGES.keys()),
            format_func=lambda code: get_language_display_label(code),
            index=list(SUPPORTED_LANGUAGES.keys()).index(st.session_state.active_language)
            if st.session_state.active_language in SUPPORTED_LANGUAGES else 0
        )
        st.session_state.active_language = selected_lang
    else:
        st.info(f"Active Language: **{get_language_display_label(st.session_state.active_language)}**")

    st.markdown("---")
    st.markdown("### ⚙️ Inference Engine")

    # Detect if any Gemini key is present
    has_system_gemini_key = bool(get_api_key(st.session_state.custom_api_key))

    engine_options = ["free"]
    if has_system_gemini_key:
        engine_options.append("gemini")

    engine_mode = st.radio(
        "Chatbot Engine",
        options=engine_options,
        format_func=lambda x: "🟢 Free Local Retrieval (No API Key)" if x == "free" else "✨ Google Gemini AI",
        help="Free Local Retrieval uses TF-IDF matching over verified local documents. Gemini AI provides generative responses when an API key is available."
    )

    # Optional Gemini Key entry expander (Never mandatory)
    with st.expander("🔑 Optional: Google Gemini API Key"):
        st.caption("Not required for the app to work! Free Local Retrieval Mode runs 100% without an API key.")
        new_key = st.text_input(
            "Enter Gemini API Key (optional):",
            type="password",
            value=st.session_state.custom_api_key,
            help="Get a free key at https://aistudio.google.com"
        )
        if new_key != st.session_state.custom_api_key:
            st.session_state.custom_api_key = new_key
            st.rerun()

    st.markdown("---")
    st.markdown("### 📚 Knowledge Base")
    doc_count = len(retrieval_engine.chunks)
    st.caption(f"Currently indexed: **{doc_count} semantic sections**.")

    with st.expander("➕ Upload Knowledge Document"):
        uploaded_file = st.file_uploader("Upload .txt or .md file", type=["txt", "md"])
        if uploaded_file is not None:
            file_contents = uploaded_file.read().decode("utf-8", errors="ignore")
            retrieval_engine.add_custom_document(uploaded_file.name, file_contents)
            st.success(f"Indexed '{uploaded_file.name}' into local knowledge base!")

    st.markdown("---")
    if st.button("🗑️ " + get_ui_text("clear_chat", st.session_state.active_language), use_container_width=True):
        st.session_state.messages = []
        st.session_state.last_detection = None
        st.rerun()

    st.markdown("---")
    st.caption("### 💡 Detection Guidance")
    st.caption(
        "• **Hindi**: Devanagari script is detected with >95% accuracy.\n"
        "• **Punjabi**: Gurmukhi script is detected with >95% accuracy.\n"
        "• **Hinglish**: Code-switched messages with marker tokens ('kya haal hai', 'bhai') are identified.\n"
        "• **Short text**: 1-2 words ('hi', 'ok') or emoji-only inputs keep the active language."
    )


# -------------------------------------------------------------
# MAIN INTERFACE
# -------------------------------------------------------------
active_lang_meta = SUPPORTED_LANGUAGES.get(st.session_state.active_language, SUPPORTED_LANGUAGES["en"])

# Top Responsive Header
mode_badge_html = (
    '<span class="status-badge badge-mode-gemini">✨ Gemini Generative AI</span>'
    if engine_mode == "gemini"
    else '<span class="status-badge badge-mode-free">🟢 Free Local Retrieval Mode (No API Key)</span>'
)

lang_badge_html = f'<span class="status-badge badge-lang">{active_lang_meta["flag"]} {active_lang_meta["name"]}</span>'

header_html = f"""
<div class="chat-header-container">
    <div>
        <h1 class="chat-header-title">🌐 {APP_TITLE}</h1>
        <div class="chat-header-subtitle">{APP_TAGLINE}</div>
    </div>
    <div class="badge-group">
        {mode_badge_html}
        {lang_badge_html}
    </div>
</div>
"""
st.markdown(header_html, unsafe_allow_html=True)

# Suggested Prompts Bar (when chat is empty)
if not st.session_state.messages:
    st.markdown(f"**{get_ui_text('sample_questions_title', st.session_state.active_language)}**")
    prompt_cols = st.columns(len(SAMPLE_QUESTIONS))
    for i, q in enumerate(SAMPLE_QUESTIONS):
        with prompt_cols[i]:
            if st.button(f"{q['label']}\n{q['query'][:28]}...", key=f"sq_{i}", use_container_width=True):
                # Trigger user query
                user_prompt = q["query"]
                st.session_state["preset_query"] = user_prompt
                st.rerun()

# Check for preset query trigger
preset_query = st.session_state.pop("preset_query", None)


# Render Conversation History
for msg in st.session_state.messages:
    role = msg["role"]
    with st.chat_message(role):
        if role == "user":
            meta_lang = msg.get("language", "en")
            conf = msg.get("confidence", 1.0)
            flag = SUPPORTED_LANGUAGES.get(meta_lang, {}).get("flag", "🌐")
            st.markdown(f'<div class="user-meta-pill">{flag} Detected: {meta_lang.upper()} (Confidence: {conf:.0%})</div>', unsafe_allow_html=True)
            st.write(msg["content"])
        else:
            st.write(msg["content"])
            # Display source citation badge for retrieval responses
            if msg.get("mode") == "retrieval" and msg.get("sources"):
                st.markdown(
                    f'<div class="assistant-source-card">📚 <strong>{get_ui_text("source_reference", st.session_state.active_language)}:</strong> {msg["sources"]}</div>',
                    unsafe_allow_html=True
                )


# Chat Input Handling
input_placeholder = get_ui_text("input_placeholder", st.session_state.active_language)
user_input = st.chat_input(input_placeholder) or preset_query

if user_input:
    # 1. Automatic Language Detection
    detection: LanguageDetectionResult = detect_language(
        user_input,
        default_lang=st.session_state.active_language
    )
    st.session_state.last_detection = detection

    # Determine target language: use manual override if selected, else detected language
    if lang_mode == "manual":
        effective_language = st.session_state.active_language
    else:
        effective_language = detection.language_code
        st.session_state.active_language = effective_language

    # Append user message
    st.session_state.messages.append({
        "role": "user",
        "content": user_input,
        "language": detection.language_code,
        "confidence": detection.confidence,
        "mode": engine_mode
    })

    # Render User Message immediately
    with st.chat_message("user"):
        flag = SUPPORTED_LANGUAGES.get(detection.language_code, {}).get("flag", "🌐")
        st.markdown(f'<div class="user-meta-pill">{flag} Detected: {detection.language_code.upper()} (Confidence: {detection.confidence:.0%})</div>', unsafe_allow_html=True)
        st.write(user_input)

    # 2. Generate Chatbot Response
    with st.chat_message("assistant"):
        with st.spinner("Processing..."):
            response_text = ""
            sources_summary = ""
            sim_score = 0.0

            if engine_mode == "gemini":
                # Gemini Generative AI mode
                api_key = get_api_key(st.session_state.custom_api_key)
                llm_resp = generate_multilingual_response(
                    messages=st.session_state.messages,
                    target_language_code=effective_language,
                    api_key=api_key
                )
                response_text = llm_resp.text
                if not llm_resp.is_success:
                    st.warning(f"Note: {llm_resp.error_message}. Falling back to Free Local Retrieval Mode.")
                    # Fallback to retrieval
                    retrieval_resp: RetrievalResponse = retrieval_engine.query(
                        user_query=user_input,
                        target_lang=effective_language
                    )
                    response_text = retrieval_resp.answer
                    sources_summary = retrieval_resp.source_summary
                    sim_score = retrieval_resp.best_similarity
            else:
                # Free Local Retrieval Mode (Zero API Key)
                retrieval_resp = retrieval_engine.query(
                    user_query=user_input,
                    target_lang=effective_language
                )
                response_text = retrieval_resp.answer
                sources_summary = retrieval_resp.source_summary
                sim_score = retrieval_resp.best_similarity

            # Render response
            st.write(response_text)

            if engine_mode == "free" and sources_summary and "No confident" not in sources_summary:
                st.markdown(
                    f'<div class="assistant-source-card">📚 <strong>{get_ui_text("source_reference", effective_language)}:</strong> {sources_summary}</div>',
                    unsafe_allow_html=True
                )

            # Store assistant response in history
            st.session_state.messages.append({
                "role": "assistant",
                "content": response_text,
                "language": effective_language,
                "mode": engine_mode,
                "sources": sources_summary,
                "similarity": sim_score
            })
