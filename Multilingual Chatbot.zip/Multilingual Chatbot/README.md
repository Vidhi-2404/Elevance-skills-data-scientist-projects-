# 🌐 Multilingual AI Chatbot

A standalone, production-ready conversational AI assistant built with **Python**, **Streamlit**, and **NLP Language Detection**.

It features an intelligent dual-engine architecture:
1. **Free Local Retrieval Mode (Default)**: Operates 100% offline without requiring any API key or credit card. Uses TF-IDF vectorization and cosine similarity over a verified multilingual knowledge base, returning transparent source citations and similarity scores.
2. **Google Gemini Generative AI Mode (Optional)**: Automatically enabled when a Google Gemini API Key (`GEMINI_API_KEY`) is configured via environment variables, Streamlit secrets, or runtime UI input.

---

## 🚀 Key Features

- **Conversational Chat Interface (Not a Dashboard)**: Focused, mobile-responsive chat layout with user message pills, assistant bubble cards, clear history action, and one-click sample question triggers.
- **Multilingual Support**:
  - 🇬🇧 **English** (`en`): Latin script.
  - 🇮🇳 **Hindi** (`hi`): Devanagari script (`[\u0900-\u097F]`).
  - 🇮🇳 **Punjabi** (`pa`): Gurmukhi script (`[\u0A00-\u0A7F]`).
  - 🇪🇸 **Spanish** (`es`): Latin script with Spanish diacritics and syntax.
  - 🇮🇳 **Hinglish** (`hinglish`): Code-switched conversational Hindi written in Roman script.
- **Hybrid Language Detection Pipeline (`services/language_service.py`)**:
  - Deterministic Unicode script detection for Devanagari and Gurmukhi (>95% accuracy).
  - Lexical token matching for Romanized Hindi / Hinglish.
  - Deterministic n-gram statistical classification via `langdetect`.
  - Graceful handling of short messages, emoji-only strings, and ambiguous text.
- **Cross-Lingual Context Continuity**: Retains conversation history across mid-dialogue language switches (e.g., asking in English, continuing in Hindi or Spanish).
- **Manual Language Override**: Option to lock the conversation language in the sidebar regardless of detected input.
- **Dynamic Knowledge Base Ingestion**: Sidebar upload widget allowing users to add custom `.txt` or `.md` documents that are immediately indexed into the retrieval engine.
- **Zero API Key Crash Protection**: The app never crashes if `GEMINI_API_KEY` is absent; it seamlessly falls back to Free Local Retrieval Mode with clear, honest labeling.

---

## 🛠️ Project Architecture

```
multilingual-ai-chatbot/
├── app.py                      # Streamlit application entry point (Responsive Chat UI)
├── config.py                   # App metadata, language mappings, prompts, UI strings
├── requirements.txt            # Minimal, pinned Python dependencies
├── .env.example                # Template for optional environment variables
├── .gitignore                  # Git ignore rules for Python, Streamlit, and secrets
├── README.md                   # Complete documentation and deployment guide
├── services/
│   ├── __init__.py
│   ├── language_service.py     # Script detection, Hinglish heuristics, confidence scoring
│   ├── retrieval_service.py    # Free TF-IDF knowledge base retriever & source citations
│   └── llm_service.py          # Gemini SDK wrapper with context retention & graceful fallback
├── knowledge_base/             # Multilingual markdown documents indexed by retrieval engine
│   ├── kb_multilingual_chatbot.md
│   ├── kb_hindi_faqs.md
│   ├── kb_punjabi_faqs.md
│   ├── kb_spanish_faqs.md
│   └── kb_hinglish_faqs.md
└── tests/                      # Automated test suite (25/25 passing)
    ├── __init__.py
    ├── test_language_service.py
    ├── test_retrieval_service.py
    ├── test_llm_service.py
    └── test_app_integration.py
```

---

## 💻 Local Quickstart

### Prerequisites
- Python 3.10 or 3.11
- Git

### 1. Clone & Navigate to Project
```bash
git clone https://github.com/<your-username>/multilingual-ai-chatbot.git
cd multilingual-ai-chatbot
```

### 2. Create Virtual Environment & Install Dependencies
```bash
python -m venv venv

# On Windows (PowerShell):
.\venv\Scripts\Activate.ps1

# On macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
```

### 3. (Optional) Configure Gemini API Key
If you wish to use Google Gemini Generative AI, copy `.env.example` to `.env` and add your key:
```bash
cp .env.example .env
```
Edit `.env`:
```ini
GEMINI_API_KEY=AIzaSy...your_gemini_api_key_here
```
> **Note**: This step is completely optional. If skipped, the app automatically runs in Free Local Retrieval Mode.

### 4. Run the Streamlit Application
```bash
streamlit run app.py
```
Open your browser at `http://localhost:8501`.

---

## 🧪 Testing & Verification

Run the full automated test suite:
```bash
python -m pytest -v
```

### Test Coverage Highlights (25 / 25 Passed):
- `test_language_service.py`:
  - English Latin detection (`confidence >= 70%`)
  - Hindi Devanagari script detection (`confidence >= 80%`)
  - Punjabi Gurmukhi script detection (`confidence >= 80%`)
  - Spanish syntax and diacritics detection (`confidence >= 70%`)
  - Hinglish code-switching detection (`confidence >= 60%`)
  - Short ambiguous inputs ("ok", "hi") preserving default language
  - Emoji-only strings ("😀 🚀 ✨") gracefully retaining context
  - Localized UI text across all supported languages
- `test_retrieval_service.py`:
  - TF-IDF indexing across multilingual documents
  - Cosine similarity matching in English, Hindi, Punjabi, Spanish, Hinglish
  - Verified source references and similarity scores
  - Fallback messaging for out-of-scope questions
- `test_llm_service.py`:
  - Missing credentials verification (zero crash guarantee)
  - Explicit API key override handling
  - Multilingual system prompt formatting
  - Mocked Gemini response generation
- `test_app_integration.py`:
  - Multi-turn conversation across language switches (English -> Hindi -> Spanish)
  - Manual override priority verification

---

## ☁️ Streamlit Community Cloud Deployment

This standalone repository is pre-configured for one-click deployment on **Streamlit Community Cloud**.

### Step 1: Create GitHub Repository
1. Initialize git and commit:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Standalone Multilingual AI Chatbot"
   git branch -M main
   ```
2. Create a new public repository on GitHub named `multilingual-ai-chatbot`.
3. Push your code:
   ```bash
   git remote add origin https://github.com/<your-username>/multilingual-ai-chatbot.git
   git push -u origin main
   ```

### Step 2: Deploy on Streamlit Community Cloud
1. Go to [share.streamlit.io](https://share.streamlit.io) and log in with your GitHub account.
2. Click **New app**.
3. Select your repository: `<your-username>/multilingual-ai-chatbot`.
4. Set branch: `main`.
5. Set main file path: `app.py`.
6. Click **Deploy!**

### Step 3: Zero-Config Free Mode vs Optional Gemini Key
- **Zero-Config (Recommended)**: The app deploys immediately and runs in **Free Local Retrieval Mode** with zero configuration!
- **Optional Gemini Mode**: In the Streamlit app management dashboard:
  1. Click **Settings** (⚙️) -> **Secrets**.
  2. Add:
     ```toml
     GEMINI_API_KEY = "AIzaSy..."
     ```
  3. Save. The app will automatically unlock Gemini Generative AI mode.

---

## 🔍 Language Detection Limitations & Best Practices

1. **Short Messages (1-2 words)**: Common short words like "hi", "ok", or "no" occur across multiple languages. The system flags these with `is_low_confidence=True` and retains the current conversation language rather than abruptly switching.
2. **Code-Switching (Hinglish)**: Hinglish detection uses lexical markers. Messages consisting almost entirely of English technical jargon may be identified as English. Users can manually switch to Hinglish via the sidebar override.
3. **Emoji & Non-Text Inputs**: Inputs containing exclusively emojis or symbols maintain the active language without throwing errors.

---

## 📄 License
MIT License. Free for educational and commercial use.
