"""
Image processing and generation service.
Handles validation of uploaded images (type, size, integrity) and Imagen 3 generation.
"""

import io
from dataclasses import dataclass
from typing import Optional, Tuple
from PIL import Image, ImageDraw, ImageFont

from config import (
    MAX_IMAGE_SIZE_BYTES,
    ALLOWED_IMAGE_TYPES,
    ALLOWED_IMAGE_EXTENSIONS,
    DEFAULT_IMAGE_GEN_MODEL,
)


@dataclass
class ImageValidationResult:
    is_valid: bool
    image: Optional[Image.Image] = None
    error_message: Optional[str] = None
    format: Optional[str] = None
    size_bytes: int = 0
    dimensions: Optional[Tuple[int, int]] = None


def validate_uploaded_image(uploaded_file) -> ImageValidationResult:
    """
    Validates uploaded image file:
    - Verifies file exists
    - Checks file size under MAX_IMAGE_SIZE_BYTES
    - Validates image integrity using Pillow
    - Verifies format is supported (JPEG, PNG, WEBP)
    """
    if uploaded_file is None:
        return ImageValidationResult(is_valid=False, error_message="No file uploaded.")

    # 1. Check file size
    try:
        # Streamlit UploadedFile has .size
        size_bytes = getattr(uploaded_file, "size", None)
        if size_bytes is None:
            uploaded_file.seek(0, io.SEEK_END)
            size_bytes = uploaded_file.tell()
            uploaded_file.seek(0)
    except Exception:
        size_bytes = 0

    if size_bytes > MAX_IMAGE_SIZE_BYTES:
        max_mb = MAX_IMAGE_SIZE_BYTES / (1024 * 1024)
        curr_mb = size_bytes / (1024 * 1024)
        return ImageValidationResult(
            is_valid=False,
            size_bytes=size_bytes,
            error_message=f"File size ({curr_mb:.2f} MB) exceeds maximum allowed limit of {max_mb:.0f} MB."
        )

    # 2. Check MIME type / extension if available
    filename = getattr(uploaded_file, "name", "").lower()
    if filename:
        ext = "." + filename.rsplit(".", 1)[-1] if "." in filename else ""
        if ext and ext not in ALLOWED_IMAGE_EXTENSIONS:
            return ImageValidationResult(
                is_valid=False,
                size_bytes=size_bytes,
                error_message=f"Unsupported file extension '{ext}'. Allowed: {', '.join(ALLOWED_IMAGE_EXTENSIONS)}."
            )

    # 3. Read and verify image data with Pillow
    try:
        if hasattr(uploaded_file, "seek"):
            uploaded_file.seek(0)
        img_bytes = uploaded_file.read() if hasattr(uploaded_file, "read") else uploaded_file
        if hasattr(uploaded_file, "seek"):
            uploaded_file.seek(0)

        if not img_bytes:
            return ImageValidationResult(is_valid=False, error_message="Uploaded file is empty.")

        image = Image.open(io.BytesIO(img_bytes))
        image.load()  # Verify image integrity

        fmt = (image.format or "").upper()
        if fmt not in ["JPEG", "JPG", "PNG", "WEBP"]:
            return ImageValidationResult(
                is_valid=False,
                size_bytes=len(img_bytes),
                error_message=f"Image format '{fmt}' is not supported. Please upload JPEG, PNG, or WebP."
            )

        return ImageValidationResult(
            is_valid=True,
            image=image,
            format=fmt,
            size_bytes=len(img_bytes),
            dimensions=image.size
        )
    except Exception as e:
        return ImageValidationResult(
            is_valid=False,
            size_bytes=size_bytes,
            error_message=f"Corrupt or unreadable image file: {str(e)}"
        )


def generate_image_with_imagen(
    prompt: str,
    api_key: Optional[str],
    model: str = DEFAULT_IMAGE_GEN_MODEL
) -> Tuple[bool, Optional[bytes], Optional[str]]:
    """
    Generate an image using Google GenAI SDK (Imagen 3).
    Returns (success, image_bytes, error_message).
    """
    if not prompt or not prompt.strip():
        return False, None, "Prompt cannot be empty."

    if not api_key or not api_key.strip():
        return False, None, "Gemini API key is required for image generation. Please configure GEMINI_API_KEY."

    try:
        from google import genai
        from google.genai import types

        client = genai.Client(api_key=api_key.strip())
        config = types.GenerateImagesConfig(
            number_of_images=1,
            output_mime_type="image/jpeg",
        )

        response = client.models.generate_images(
            model=model,
            prompt=prompt.strip(),
            config=config
        )

        if not response or not getattr(response, "generated_images", None):
            return False, None, "The image generation API returned an empty response. The prompt may have triggered safety policies."

        generated_image = response.generated_images[0]
        image_bytes = getattr(generated_image.image, "image_bytes", None)

        if not image_bytes:
            return False, None, "No image byte data received from Imagen API."

        return True, image_bytes, None

    except Exception as e:
        err_msg = str(e)
        if "API_KEY_INVALID" in err_msg or "403" in err_msg:
            return False, None, "Invalid Gemini API Key. Please verify your credentials."
        elif "RESOURCE_EXHAUSTED" in err_msg or "429" in err_msg:
            return False, None, "Gemini quota exceeded. Please check your billing or rate limits."
        elif "NOT_FOUND" in err_msg or "404" in err_msg:
            return False, None, f"Image generation model '{model}' was not found or is unavailable for this API key."
        return False, None, f"Image generation failed: {err_msg}"


def generate_offline_demo_image(prompt: str) -> bytes:
    """
    Creates a simulated preview banner clearly labeled as OFFLINE DEMO MODE.
    Ensures users are never misled into thinking this was generated by Gemini.
    """
    width, height = 768, 512
    # Create dark gradient-like slate background
    img = Image.new("RGB", (width, height), color=(26, 32, 44))
    draw = ImageDraw.Draw(img)

    # Decorative frame
    draw.rectangle([16, 16, width - 16, height - 16], outline=(79, 70, 229), width=3)
    draw.rectangle([24, 24, width - 24, height - 24], outline=(55, 65, 81), width=1)

    # Header banner
    draw.rectangle([30, 30, width - 30, 90], fill=(234, 88, 12))  # Orange banner
    draw.text((45, 50), "[DEMONSTRATION MODE - NO API KEY]", fill=(255, 255, 255))

    # Center prompt preview
    draw.text((45, 120), "Requested Prompt:", fill=(156, 163, 175))

    # Wrap prompt text
    wrapped_lines = []
    words = prompt.split()
    current_line = ""
    for w in words:
        if len(current_line + " " + w) > 55:
            wrapped_lines.append(current_line)
            current_line = w
        else:
            current_line = current_line + " " + w if current_line else w
    if current_line:
        wrapped_lines.append(current_line)

    y = 150
    for line in wrapped_lines[:6]:
        draw.text((45, y), line, fill=(243, 244, 246))
        y += 24

    # Notice at bottom
    draw.text((45, height - 120), "Notice:", fill=(239, 68, 68))
    draw.text(
        (45, height - 90),
        "Actual Imagen 3 generation requires a valid GEMINI_API_KEY.\n"
        "Configure GEMINI_API_KEY in Streamlit Secrets or .env to activate live image generation.",
        fill=(209, 213, 219)
    )

    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=90)
    return buf.getvalue()
