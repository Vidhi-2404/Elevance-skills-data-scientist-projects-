"""
Retrieval-based Knowledge Base service.
Provides an offline, API-key-free question-answering mode using TF-IDF and keyword matching.
All answers from this service are strictly retrieval-based and clearly labeled.
"""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
import re

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from config import DEFAULT_KB_PATH, DEFAULT_TOP_K_RESULTS, TFIDF_SIMILARITY_THRESHOLD


@dataclass
class Document:
    id: str
    title: str
    content: str
    category: str = "General"
    source: str = "Knowledge Base"


@dataclass
class SearchResult:
    document: Document
    score: float
    snippet: str


@dataclass
class RetrievalAnswer:
    query: str
    has_answer: bool
    answer_text: str
    sources: List[SearchResult] = field(default_factory=list)
    mode_label: str = "Retrieval-Based Answering (Knowledge Base)"


class KnowledgeBaseService:
    """
    Manages knowledge documents and performs TF-IDF search for zero-API-key mode.
    """

    def __init__(self, default_kb_path: Optional[Path] = DEFAULT_KB_PATH):
        self.documents: List[Document] = []
        self.vectorizer: Optional[TfidfVectorizer] = None
        self.tfidf_matrix = None
        self.default_kb_path = default_kb_path
        self._load_default_documents()

    def _load_default_documents(self):
        """Loads default knowledge base documents from disk if available."""
        if self.default_kb_path and self.default_kb_path.exists():
            try:
                with open(self.default_kb_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    for item in data:
                        doc = Document(
                            id=item.get("id", str(len(self.documents))),
                            title=item.get("title", "Untitled Document"),
                            content=item.get("content", ""),
                            category=item.get("category", "General"),
                            source=item.get("source", "Built-in Knowledge Base")
                        )
                        self.documents.append(doc)
            except Exception as e:
                print(f"Warning: Failed to load default knowledge base: {e}")

        # If no default docs were loaded, initialize with a foundational document
        if not self.documents:
            self.documents.append(
                Document(
                    id="intro-kb",
                    title="Multimodal Chatbot Overview",
                    content="This application supports Gemini multimodal conversation, vision understanding, Imagen 3 generation, and free offline knowledge retrieval.",
                    category="System",
                    source="System Default"
                )
            )

        self._reindex()

    def add_document(self, title: str, content: str, category: str = "User Ingested", source: str = "Uploaded Document") -> Document:
        """Add a custom document to the knowledge base and refresh index."""
        doc_id = f"doc_{len(self.documents) + 1}_{re.sub(r'[^a-zA-Z0-9]', '_', title)[:15]}"
        doc = Document(
            id=doc_id,
            title=title.strip(),
            content=content.strip(),
            category=category,
            source=source
        )
        self.documents.append(doc)
        self._reindex()
        return doc

    def ingest_text_file(self, filename: str, text_content: str) -> Document:
        """Ingest raw text or markdown from an uploaded file."""
        title = Path(filename).stem.replace("_", " ").title()
        return self.add_document(
            title=title,
            content=text_content,
            category="User Ingested",
            source=filename
        )

    def _reindex(self):
        """Recomputes the TF-IDF index over all documents."""
        if not self.documents:
            self.vectorizer = None
            self.tfidf_matrix = None
            return

        corpus = [f"{d.title} {d.category} {d.content}" for d in self.documents]
        self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        self.tfidf_matrix = self.vectorizer.fit_transform(corpus)

    def search(self, query: str, top_k: int = DEFAULT_TOP_K_RESULTS) -> List[SearchResult]:
        """
        Search documents using TF-IDF cosine similarity.
        Falls back to keyword matching if query terms are sparse.
        """
        if not query or not query.strip() or not self.documents or self.vectorizer is None:
            return []

        results: List[SearchResult] = []
        try:
            query_vec = self.vectorizer.transform([query])
            sim_scores = cosine_similarity(query_vec, self.tfidf_matrix).flatten()

            ranked_indices = sim_scores.argsort()[::-1]

            for idx in ranked_indices:
                score = float(sim_scores[idx])
                if score >= TFIDF_SIMILARITY_THRESHOLD and len(results) < top_k:
                    doc = self.documents[idx]
                    snippet = self._extract_relevant_snippet(doc.content, query)
                    results.append(SearchResult(document=doc, score=score, snippet=snippet))
        except Exception:
            pass

        # Keyword fallback if TF-IDF returned no results
        if not results:
            query_terms = set(re.findall(r"\w+", query.lower()))
            for doc in self.documents:
                doc_terms = set(re.findall(r"\w+", (doc.title + " " + doc.content).lower()))
                overlap = query_terms.intersection(doc_terms)
                if overlap:
                    score = len(overlap) / max(len(query_terms), 1) * 0.5
                    snippet = self._extract_relevant_snippet(doc.content, query)
                    results.append(SearchResult(document=doc, score=score, snippet=snippet))
            results.sort(key=lambda r: r.score, reverse=True)
            results = results[:top_k]

        return results

    def _extract_relevant_snippet(self, content: str, query: str, max_chars: int = 240) -> str:
        """Extract a snippet of content relevant to the search query."""
        terms = [t for t in re.findall(r"\w+", query.lower()) if len(t) > 2]
        lower_content = content.lower()

        best_pos = -1
        for term in terms:
            pos = lower_content.find(term)
            if pos != -1:
                best_pos = pos
                break

        if best_pos == -1:
            return content[:max_chars] + ("..." if len(content) > max_chars else "")

        start = max(0, best_pos - 40)
        end = min(len(content), start + max_chars)
        snippet = content[start:end].strip()
        if start > 0:
            snippet = "..." + snippet
        if end < len(content):
            snippet = snippet + "..."
        return snippet

    def answer_query(self, query: str, top_k: int = DEFAULT_TOP_K_RESULTS) -> RetrievalAnswer:
        """
        Synthesizes a response strictly from matching knowledge-base articles.
        Clearly labels the response as retrieval-based, citing source documents.
        """
        results = self.search(query, top_k=top_k)

        if not results:
            answer_text = (
                "**No matching documents found in the Knowledge Base.**\n\n"
                "*Note: The application is currently running in **Free Knowledge-Base Retrieval Mode** "
                "(no Gemini API key required). In this mode, answers are retrieved exclusively from "
                "local ingested documents rather than generated by Gemini AI.*\n\n"
                "**Suggestions:**\n"
                "- Try querying topics present in the default knowledge base (e.g., 'Gemini models', 'vision capabilities', 'Imagen 3', 'Streamlit deployment').\n"
                "- Ingest your own text files (.txt, .md) using the Knowledge Base manager in the sidebar.\n"
                "- To enable generative Gemini AI, configure `GEMINI_API_KEY`."
            )
            return RetrievalAnswer(
                query=query,
                has_answer=False,
                answer_text=answer_text,
                sources=[]
            )

        # Synthesize answer from top matches
        top_doc = results[0].document
        top_snippet = results[0].snippet

        parts = [
            f"### 📖 {top_doc.title} ({top_doc.category})\n",
            f"{top_doc.content}\n"
        ]

        if len(results) > 1:
            parts.append("\n**Additional Relevant Context:**\n")
            for res in results[1:]:
                parts.append(f"- **{res.document.title}**: {res.snippet} *(Relevance: {res.score:.2f})*")

        parts.append(
            "\n\n---\n"
            "🔍 *Source: Local Knowledge Base (TF-IDF Retrieval) | Mode: Free Offline (No API Key Required)*"
        )

        return RetrievalAnswer(
            query=query,
            has_answer=True,
            answer_text="".join(parts),
            sources=results
        )


# Singleton instance for the application
_kb_instance: Optional[KnowledgeBaseService] = None


def get_knowledge_base() -> KnowledgeBaseService:
    global _kb_instance
    if _kb_instance is None:
        _kb_instance = KnowledgeBaseService()
    return _kb_instance
