"""
Gemini LLM and Vision Service.
Uses the official google-genai SDK to interact with Google Gemini models.
Provides independent configuration for text conversation and vision understanding,
with robust error handling for missing keys, quotas, network issues, and invalid models.
"""

from typing import List, Dict, Any, Optional, Tuple
from PIL import Image

from config import (
    get_gemini_api_key,
    DEFAULT_TEXT_MODEL,
    DEFAULT_VISION_MODEL,
)


class GeminiService:
    """
    Wrapper for Google GenAI SDK.
    Handles text chat, multimodal vision analysis, and error parsing.
    """

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key if api_key else get_gemini_api_key()
        self._client = None

    @property
    def is_configured(self) -> bool:
        """Returns True if a non-empty API key is available."""
        return bool(self.api_key and self.api_key.strip())

    def _get_client(self):
        """Lazy initialization of google.genai.Client."""
        if not self.is_configured:
            return None
        if self._client is None:
            from google import genai
            self._client = genai.Client(api_key=self.api_key.strip())
        return self._client

    def generate_text_response(
        self,
        prompt: str,
        history: Optional[List[Dict[str, str]]] = None,
        model: str = DEFAULT_TEXT_MODEL,
        system_instruction: Optional[str] = None
    ) -> Tuple[bool, str]:
        """
        Generates a text response from Gemini given the user prompt and optional conversation history.
        Returns (success: bool, response_or_error: str).
        """
        if not self.is_configured:
            return (
                False,
                "Gemini API key is not configured. Please provide GEMINI_API_KEY in Streamlit secrets, "
                "in a .env file, or switch to Free Knowledge-Base Retrieval mode."
            )

        if not prompt or not prompt.strip():
            return False, "Prompt cannot be empty."

        try:
            from google.genai import types

            client = self._get_client()
            if not client:
                return False, "Failed to initialize Gemini client."

            # Build contents list preserving conversation history
            contents: List[types.Content] = []

            if history:
                # Add previous conversation turns
                for msg in history:
                    role = msg.get("role")
                    content = msg.get("content", "")
                    if role in ["user", "assistant"] and content:
                        genai_role = "user" if role == "user" else "model"
                        contents.append(
                            types.Content(
                                role=genai_role,
                                parts=[types.Part.from_text(text=content)]
                            )
                        )

            # Append current user prompt
            contents.append(
                types.Content(
                    role="user",
                    parts=[types.Part.from_text(text=prompt.strip())]
                )
            )

            # Optional config (e.g. system instructions)
            config = None
            if system_instruction:
                config = types.GenerateContentConfig(
                    system_instruction=system_instruction
                )

            response = client.models.generate_content(
                model=model,
                contents=contents,
                config=config
            )

            if not response or not response.text:
                return False, "Gemini returned an empty response. The request may have been filtered by safety settings."

            return True, response.text

        except Exception as e:
            return False, self._format_gemini_error(e, model=model)

    def generate_multimodal_response(
        self,
        prompt: str,
        image: Image.Image,
        history: Optional[List[Dict[str, Any]]] = None,
        model: str = DEFAULT_VISION_MODEL
    ) -> Tuple[bool, str]:
        """
        Generates a multimodal response from Gemini given a PIL Image and a textual prompt.
        Allows users to ask questions, describe image contents, and extract text.
        Returns (success: bool, response_or_error: str).
        """
        if not self.is_configured:
            return (
                False,
                "Gemini API key is not configured. Vision understanding requires a valid GEMINI_API_KEY."
            )

        if image is None:
            return False, "No valid image provided for multimodal analysis."

        user_prompt = prompt.strip() if (prompt and prompt.strip()) else "Describe this image in detail and extract any visible text."

        try:
            client = self._get_client()
            if not client:
                return False, "Failed to initialize Gemini client."

            # Pass prompt and PIL image directly into contents
            contents = [user_prompt, image]

            response = client.models.generate_content(
                model=model,
                contents=contents
            )

            if not response or not response.text:
                return False, "Gemini vision model returned an empty response. The image or prompt may have been filtered."

            return True, response.text

        except Exception as e:
            return False, self._format_gemini_error(e, model=model)

    def _format_gemini_error(self, error: Exception, model: str = "") -> str:
        """Translates raw exceptions into friendly, actionable diagnostic messages."""
        err_str = str(error)

        if "API_KEY_INVALID" in err_str or "403" in err_str:
            return (
                "❌ **Authentication Error (HTTP 403)**: The provided Gemini API key is invalid or unauthorized.\n\n"
                "Please verify your API key at [Google AI Studio](https://aistudio.google.com/app/apikey) "
                "and ensure it has sufficient permissions."
            )
        elif "RESOURCE_EXHAUSTED" in err_str or "429" in err_str:
            return (
                "⚠️ **Quota Exceeded (HTTP 429)**: The Gemini API rate limit or project quota has been reached.\n\n"
                "Please wait a moment before sending another request, check your billing tier, "
                "or switch to Free Knowledge-Base Retrieval mode."
            )
        elif "NOT_FOUND" in err_str or "404" in err_str:
            return (
                f"❌ **Model Unavailable (HTTP 404)**: The model `{model}` was not found or is deprecated.\n\n"
                "Try selecting a different supported model (such as `gemini-2.5-flash` or `gemini-1.5-flash`) "
                "in the sidebar settings."
            )
        elif "Failed to connect" in err_str or "timeout" in err_str.lower() or "ConnectionError" in err_str:
            return (
                "🌐 **Network Error**: Unable to reach Google Gemini API endpoints.\n\n"
                "Please check your internet connection or firewall settings."
            )
        else:
            return f"❌ **Gemini API Error**: {err_str}"
