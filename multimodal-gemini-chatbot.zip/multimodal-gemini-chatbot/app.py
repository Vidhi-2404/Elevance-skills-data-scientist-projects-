"""
Multimodal AI Chatbot with Google Gemini & Free Offline Knowledge Retrieval.
Entry point for Streamlit Community Cloud and local execution.
"""

import streamlit as st
from PIL import Image
import io
import time
from typing import Optional

# Internal modules
import config
from services.llm_service import GeminiService
from services.image_service import (
    validate_uploaded_image,
    generate_image_with_imagen,
    generate_offline_demo_image,
)
from services.retrieval_service import get_knowledge_base, RetrievalAnswer

# ---------------------------------------------------------
# Page Configuration
# ---------------------------------------------------------
st.set_page_config(
    page_title="Multimodal AI Chatbot | Gemini & Free Retrieval",
    page_icon="✨",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ---------------------------------------------------------
# Custom Styling (Glassmorphism & Responsive Layout)
# ---------------------------------------------------------
st.markdown(
    """
    <style>
    /* Global styling */
    .stApp {
        background: radial-gradient(circle at 15% 15%, #111827 0%, #0b0f19 100%);
        color: #f3f4f6;
    }
    
    /* Header card */
    .header-card {
        background: rgba(31, 41, 55, 0.6);
        backdrop-filter: blur(12px);
        border: 1px solid rgba(75, 85, 99, 0.4);
        padding: 1.5rem;
        border-radius: 14px;
        margin-bottom: 1.5rem;
        box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
    }
    
    /* Badges */
    .mode-badge-gemini {
        display: inline-block;
        background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
        color: white;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.8rem;
        font-weight: 600;
        letter-spacing: 0.05em;
    }
    
    .mode-badge-retrieval {
        display: inline-block;
        background: linear-gradient(135deg, #059669 0%, #10b981 100%);
        color: white;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.8rem;
        font-weight: 600;
        letter-spacing: 0.05em;
    }

    .mode-badge-demo {
        display: inline-block;
        background: linear-gradient(135deg, #d97706 0%, #f59e0b 100%);
        color: white;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.8rem;
        font-weight: 600;
    }
    
    .source-box {
        background: rgba(17, 24, 39, 0.8);
        border-left: 3px solid #10b981;
        padding: 0.6rem 0.9rem;
        border-radius: 0 8px 8px 0;
        margin-top: 0.5rem;
        font-size: 0.85rem;
    }
    
    /* Responsive image container */
    .image-preview-container {
        border: 1px dashed rgba(156, 163, 175, 0.4);
        border-radius: 10px;
        padding: 0.75rem;
        text-align: center;
        background: rgba(17, 24, 39, 0.3);
    }
    </style>
    """,
    unsafe_allow_html=True
)

# ---------------------------------------------------------
# Session State Initialization
# ---------------------------------------------------------
if "messages" not in st.session_state:
    st.session_state.messages = []

if "session_api_key" not in st.session_state:
    st.session_state.session_api_key = ""

if "current_image" not in st.session_state:
    st.session_state.current_image = None

if "last_generated_image" not in st.session_state:
    st.session_state.last_generated_image = None

# Initialize Knowledge Base
kb_service = get_knowledge_base()

# Determine active API Key
env_or_secret_key = config.get_gemini_api_key()
active_api_key = st.session_state.session_api_key.strip() if st.session_state.session_api_key.strip() else env_or_secret_key
has_api_key = bool(active_api_key and active_api_key.strip())

# Initialize Gemini LLM Service
llm_service = GeminiService(api_key=active_api_key)

# ---------------------------------------------------------
# Sidebar Navigation and Configuration
# ---------------------------------------------------------
with st.sidebar:
    st.markdown("## 🤖 Multimodal AI Hub")
    st.caption("Google Gemini & Free Retrieval System")

    st.markdown("---")

    # API Status Banner
    if has_api_key:
        st.success("🟢 **Gemini API Configured**")
        mode_options = ["Gemini Multimodal Mode", "Free Knowledge-Base Retrieval Mode"]
    else:
        st.info("🔵 **Free Retrieval Mode (Zero Key)**")
        st.caption(
            "No API key detected. Running safely in free TF-IDF retrieval mode without crashing. "
            "You may enter an API key below to unlock live Gemini features."
        )
        mode_options = ["Free Knowledge-Base Retrieval Mode", "Gemini Multimodal Mode"]

    selected_mode = st.selectbox("Operating Mode", mode_options, index=0)
    is_gemini_mode = (selected_mode == "Gemini Multimodal Mode")

    # Optional Session API Key Input (never stored permanently)
    with st.expander("🔑 Session API Key (Optional)", expanded=not has_api_key):
        temp_key = st.text_input(
            "Enter Gemini API Key",
            type="password",
            value=st.session_state.session_api_key,
            help="Your key is kept in memory during your active session and never saved to disk."
        )
        if temp_key != st.session_state.session_api_key:
            st.session_state.session_api_key = temp_key
            st.rerun()

    st.markdown("---")

    # Independent Model Configuration
    st.markdown("### ⚙️ Model Settings")
    selected_text_model = st.selectbox(
        "Text Conversation Model",
        config.AVAILABLE_TEXT_MODELS,
        index=0,
        help="Model used for text conversation reasoning."
    )

    selected_vision_model = st.selectbox(
        "Vision Understanding Model",
        config.AVAILABLE_VISION_MODELS,
        index=0,
        help="Model used to inspect, describe, and extract text from images."
    )

    selected_image_gen_model = st.selectbox(
        "Image Generation Model",
        config.AVAILABLE_IMAGE_GEN_MODELS,
        index=0,
        help="Foundation model used for text-to-image synthesis."
    )

    st.markdown("---")

    # Knowledge Base Management
    st.markdown("### 📚 Knowledge Base")
    doc_count = len(kb_service.documents)
    st.caption(f"Currently indexing **{doc_count} documents** for offline retrieval.")

    with st.expander("➕ Ingest Custom Document"):
        uploaded_doc = st.file_uploader(
            "Upload .txt or .md file",
            type=["txt", "md"],
            key="kb_file_uploader"
        )
        if uploaded_doc is not None:
            if st.button("Ingest Uploaded File", key="btn_ingest_file"):
                try:
                    text = uploaded_doc.read().decode("utf-8")
                    new_doc = kb_service.ingest_text_file(uploaded_doc.name, text)
                    st.success(f"Ingested '{new_doc.title}' ({len(text)} chars)!")
                    time.sleep(1)
                    st.rerun()
                except Exception as e:
                    st.error(f"Failed to ingest file: {e}")

        st.markdown("**Or Enter Text Snippet:**")
        custom_title = st.text_input("Title", key="kb_custom_title")
        custom_content = st.text_area("Content", key="kb_custom_content")
        if st.button("Add Snippet", key="btn_add_snippet"):
            if custom_title and custom_content:
                kb_service.add_document(custom_title, custom_content)
                st.success("Snippet successfully added to index!")
                time.sleep(1)
                st.rerun()
            else:
                st.warning("Please provide both title and content.")

    st.markdown("---")

    # Reset Conversation
    if st.button("🗑️ Reset Chat History", use_container_width=True):
        st.session_state.messages = []
        st.session_state.current_image = None
        st.session_state.last_generated_image = None
        st.success("Conversation history cleared.")
        st.rerun()


# ---------------------------------------------------------
# Main Interface Layout
# ---------------------------------------------------------
# Top Header Card
st.markdown(
    f"""
    <div class="header-card">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
            <div>
                <h1 style="margin: 0; font-size: 1.8rem; font-weight: 700;">✨ Multimodal AI Chatbot</h1>
                <p style="margin: 0.3rem 0 0 0; color: #9ca3af; font-size: 0.95rem;">
                    Powered by Google Gemini 2.5 Flash, Imagen 3, and Free Local Knowledge Base Retrieval
                </p>
            </div>
            <div style="margin-top: 0.5rem;">
                <span class="{'mode-badge-gemini' if is_gemini_mode else 'mode-badge-retrieval'}">
                    {'🟢 GEMINI MULTIMODAL MODE' if is_gemini_mode else '🔵 FREE KNOWLEDGE BASE RETRIEVAL MODE'}
                </span>
            </div>
        </div>
    </div>
    """,
    unsafe_allow_html=True
)

# Navigation Tabs
tab_chat, tab_image_gen, tab_kb = st.tabs([
    "💬 Multimodal Chat & Vision",
    "🎨 Image Generation (Imagen 3)",
    "📖 Knowledge Base Explorer"
])


# =========================================================
# TAB 1: Multimodal Chat & Vision Understanding
# =========================================================
with tab_chat:
    st.markdown("### 💬 Conversational Assistant")

    # Image Upload & Multimodal Drawer
    with st.expander("📷 Attach Image for Vision Understanding", expanded=(st.session_state.current_image is not None)):
        uploaded_img_file = st.file_uploader(
            "Upload an image (JPEG, PNG, WebP — max 10MB)",
            type=["jpg", "jpeg", "png", "webp"],
            key="chat_image_uploader",
            help="Uploaded images are processed in-memory and not permanently saved to disk."
        )

        col_img_prev, col_img_ops = st.columns([1, 2])

        if uploaded_img_file is not None:
            val_res = validate_uploaded_image(uploaded_img_file)
            if not val_res.is_valid:
                st.error(f"⚠️ {val_res.error_message}")
                st.session_state.current_image = None
            else:
                st.session_state.current_image = val_res.image
                with col_img_prev:
                    st.image(val_res.image, caption=f"Attached ({val_res.format}, {val_res.dimensions[0]}x{val_res.dimensions[1]})", use_container_width=True)
                with col_img_ops:
                    st.success("✅ Image validated and attached to your prompt context.")
                    st.markdown("**Quick Prompts:**")
                    qp1, qp2, qp3 = st.columns(3)
                    if qp1.button("🔍 Describe Image", key="qp_describe"):
                        st.session_state.preset_prompt = "Describe this image in comprehensive detail, noting key subjects, composition, and colors."
                    if qp2.button("📝 Extract Text (OCR)", key="qp_ocr"):
                        st.session_state.preset_prompt = "Extract and transcribe all visible printed or handwritten text in this image verbatim."
                    if qp3.button("❓ Key Elements", key="qp_elements"):
                        st.session_state.preset_prompt = "Identify and list the prominent objects, figures, and background setting in this image."
        else:
            if st.session_state.current_image is not None:
                st.session_state.current_image = None

    # Render Conversation History
    chat_container = st.container()
    with chat_container:
        if not st.session_state.messages:
            # Welcoming banner with guidance
            st.info(
                "👋 **Welcome! Ask anything or upload an image above.**\n\n"
                "- **Gemini Mode**: Full conversational AI, multimodal image question answering, and OCR.\n"
                "- **Free Retrieval Mode**: Instant, offline answers sourced from the indexed knowledge base without requiring an API key!"
            )
        else:
            for msg in st.session_state.messages:
                with st.chat_message(msg["role"]):
                    if "image" in msg and msg["image"] is not None:
                        st.image(msg["image"], width=300, caption="Attached Image")
                    
                    st.markdown(msg["content"])
                    
                    # Display metadata badges or source citations
                    if msg.get("mode") == "retrieval":
                        st.caption("🏷️ *Answering Mode: Retrieval-based (Local Knowledge Base, not Gemini-generated AI)*")
                    elif msg.get("mode") == "gemini":
                        st.caption(f"✨ *Generated by Gemini ({msg.get('model', 'gemini')})*")

    # Chat Input
    default_prompt = st.session_state.pop("preset_prompt", "")
    user_input = st.chat_input("Type your message here...", key="chat_input_field")

    # If preset button was pressed, override input
    effective_prompt = default_prompt if default_prompt else user_input

    if effective_prompt:
        active_image = st.session_state.current_image

        # Append User Message to history
        st.session_state.messages.append({
            "role": "user",
            "content": effective_prompt,
            "image": active_image
        })

        # Display user message immediately
        with st.chat_message("user"):
            if active_image:
                st.image(active_image, width=300, caption="Attached Image")
            st.markdown(effective_prompt)

        # Assistant Response Container
        with st.chat_message("assistant"):
            response_placeholder = st.empty()

            if is_gemini_mode:
                if not has_api_key:
                    st.error(
                        "⚠️ **API Key Missing**: Gemini Multimodal Mode requires an active GEMINI_API_KEY. "
                        "Please enter your key in the sidebar or switch to Free Knowledge-Base Retrieval Mode."
                    )
                else:
                    with st.spinner("✨ Gemini is thinking..."):
                        if active_image is not None:
                            # Multimodal Call
                            success, reply = llm_service.generate_multimodal_response(
                                prompt=effective_prompt,
                                image=active_image,
                                model=selected_vision_model
                            )
                        else:
                            # Text Chat Call with History
                            success, reply = llm_service.generate_text_response(
                                prompt=effective_prompt,
                                history=st.session_state.messages[:-1],
                                model=selected_text_model
                            )

                    if success:
                        response_placeholder.markdown(reply)
                        st.caption(f"✨ *Generated by Gemini ({selected_vision_model if active_image else selected_text_model})*")
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": reply,
                            "mode": "gemini",
                            "model": selected_vision_model if active_image else selected_text_model
                        })
                    else:
                        response_placeholder.markdown(reply)
            else:
                # Free Knowledge-Base Retrieval Mode (Zero API Key)
                with st.spinner("🔍 Searching Knowledge Base..."):
                    retrieval_answer: RetrievalAnswer = kb_service.answer_query(effective_prompt)

                response_placeholder.markdown(retrieval_answer.answer_text)
                st.caption("🏷️ *Answering Mode: Retrieval-based (Local Knowledge Base, not Gemini-generated AI)*")

                st.session_state.messages.append({
                    "role": "assistant",
                    "content": retrieval_answer.answer_text,
                    "mode": "retrieval",
                    "sources": [s.document.title for s in retrieval_answer.sources]
                })

        # Clear active image once processed in this turn
        st.session_state.current_image = None
        st.rerun()


# =========================================================
# TAB 2: Image Generation (Imagen 3)
# =========================================================
with tab_image_gen:
    st.markdown("### 🎨 Text-to-Image Generation (Imagen 3)")
    st.caption("Generate high-fidelity, photorealistic images from descriptive prompts using Google Imagen 3.")

    col_prompt, col_controls = st.columns([3, 1])

    with col_prompt:
        image_prompt = st.text_area(
            "Image Generation Prompt",
            height=120,
            placeholder="e.g. A serene Japanese zen garden with cherry blossoms, koi pond, and morning mist at dawn, 8k photorealistic.",
            key="img_gen_prompt_input"
        )

        st.markdown("**Sample Prompts (Click to Use):**")
        pcol1, pcol2, pcol3 = st.columns(3)
        if pcol1.button("🌸 Zen Garden", key="sp_zen"):
            image_prompt = "A serene Japanese zen garden with cherry blossoms, koi pond, and morning mist at dawn, photorealistic."
        if pcol2.button("🚀 Sci-Fi Laboratory", key="sp_lab"):
            image_prompt = "A futuristic holographic research laboratory with glowing neon circuits and volumetric lighting, cinematic."
        if pcol3.button("🦊 Cyberpunk Red Panda", key="sp_panda"):
            image_prompt = "A cute cyberpunk red panda wearing high-tech goggles in a rainy Tokyo alleyway, 3D digital art."

    with col_controls:
        st.markdown("**Configuration**")
        st.info(f"Model: `{selected_image_gen_model}`")
        generate_btn = st.button("✨ Generate Image", type="primary", use_container_width=True)

        if not has_api_key:
            demo_btn = st.button("🖼️ Generate Demo Preview", use_container_width=True, help="Test UI & download without API key")
        else:
            demo_btn = False

    # Execution logic
    if generate_btn:
        if not image_prompt or not image_prompt.strip():
            st.warning("Please provide a prompt before generating.")
        elif not has_api_key:
            st.warning(
                "⚠️ **Gemini API Key Required for Live Imagen 3 Generation**\n\n"
                "To generate genuine images using Google Imagen 3, please configure `GEMINI_API_KEY` in Streamlit secrets or sidebar. "
                "You can also click **'Generate Demo Preview'** to verify UI and download controls without an API key."
            )
        else:
            with st.spinner("🎨 Synthesizing image with Imagen 3..."):
                success, img_bytes, err = generate_image_with_imagen(
                    prompt=image_prompt,
                    api_key=active_api_key,
                    model=selected_image_gen_model
                )

            if success and img_bytes:
                st.session_state.last_generated_image = {
                    "bytes": img_bytes,
                    "prompt": image_prompt,
                    "is_demo": False
                }
                st.success("🎉 Image successfully generated!")
            else:
                st.error(err)

    if demo_btn:
        if not image_prompt or not image_prompt.strip():
            image_prompt = "Demonstration prompt for multimodal UI verification."
        with st.spinner("🖼️ Generating offline demonstration preview..."):
            demo_bytes = generate_offline_demo_image(image_prompt)
            st.session_state.last_generated_image = {
                "bytes": demo_bytes,
                "prompt": image_prompt,
                "is_demo": True
            }
            st.info("Demonstration preview created.")

    # Image Preview and Download Area
    if st.session_state.last_generated_image is not None:
        st.markdown("---")
        st.markdown("### 🖼️ Generated Result Preview")

        gen_data = st.session_state.last_generated_image
        col_res_img, col_res_meta = st.columns([2, 1])

        with col_res_img:
            st.image(gen_data["bytes"], caption=f"Prompt: {gen_data['prompt']}", use_container_width=True)

        with col_res_meta:
            if gen_data.get("is_demo"):
                st.markdown("<span class='mode-badge-demo'>OFFLINE DEMO PREVIEW</span>", unsafe_allow_html=True)
                st.caption("This preview was rendered locally for offline interface testing.")
            else:
                st.markdown("<span class='mode-badge-gemini'>GENUINE IMAGEN 3 OUTPUT</span>", unsafe_allow_html=True)
                st.caption(f"Synthesized by model `{selected_image_gen_model}`.")

            st.markdown(f"**Prompt:**\n*{gen_data['prompt']}*")
            st.download_button(
                label="⬇️ Download Image (JPEG)",
                data=gen_data["bytes"],
                file_name="gemini_generated_image.jpg",
                mime="image/jpeg",
                use_container_width=True
            )


# =========================================================
# TAB 3: Knowledge Base Explorer
# =========================================================
with tab_kb:
    st.markdown("### 📖 Knowledge Base & Retrieval Explorer")
    st.caption("Inspect indexed articles and test the TF-IDF search engine powering the zero-API-key mode.")

    search_query = st.text_input("🔍 Search Knowledge Base", placeholder="e.g. vision capabilities, Imagen 3, deployment...")

    if search_query:
        search_results = kb_service.search(search_query, top_k=5)
        if search_results:
            st.success(f"Found {len(search_results)} relevant document(s):")
            for res in search_results:
                with st.expander(f"📄 {res.document.title} — Relevance Score: {res.score:.2f}"):
                    st.markdown(f"**Category:** `{res.document.category}` | **Source:** `{res.document.source}`")
                    st.markdown(f"**Matching Snippet:**\n> {res.snippet}")
                    st.markdown("**Full Content:**")
                    st.write(res.document.content)
        else:
            st.warning("No matching documents found. Try broader keywords or add new documents.")

    st.markdown("---")
    st.markdown("#### 📑 All Indexed Documents")
    for doc in kb_service.documents:
        with st.expander(f"📘 {doc.title} ({doc.category})"):
            st.caption(f"Document ID: `{doc.id}` | Source: `{doc.source}`")
            st.write(doc.content)
