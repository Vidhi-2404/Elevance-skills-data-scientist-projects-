"""
Configuration module for Multimodal Gemini Chatbot.
Handles environment variables, Streamlit secrets, model options, and application limits.
"""

import os
from pathlib import Path
from typing import Optional

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Base Paths
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DEFAULT_KB_PATH = DATA_DIR / "default_knowledge_base.json"

# Image Upload Constraints
MAX_IMAGE_SIZE_BYTES = 10 * 1024 * 1024  # 10 MB
ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"]
ALLOWED_IMAGE_EXTENSIONS = [".jpg", ".jpeg", ".png", ".webp"]

# Available Models (Configured independently per capability)
AVAILABLE_TEXT_MODELS = [
    "gemini-2.5-flash",
    "gemini-1.5-flash",
    "gemini-2.0-flash",
    "gemini-1.5-pro"
]
DEFAULT_TEXT_MODEL = "gemini-2.5-flash"

AVAILABLE_VISION_MODELS = [
    "gemini-2.5-flash",
    "gemini-1.5-flash",
    "gemini-2.0-flash",
    "gemini-1.5-pro"
]
DEFAULT_VISION_MODEL = "gemini-2.5-flash"

AVAILABLE_IMAGE_GEN_MODELS = [
    "imagen-3.0-generate-002"
]
DEFAULT_IMAGE_GEN_MODEL = "imagen-3.0-generate-002"

# Retrieval Settings
DEFAULT_TOP_K_RESULTS = 3
TFIDF_SIMILARITY_THRESHOLD = 0.08


def get_gemini_api_key() -> Optional[str]:
    """
    Retrieve Gemini API key safely from Streamlit secrets or OS environment variables.
    Never raises an exception or crashes if the key is missing; returns None instead.
    """
    # 1. Try Streamlit Secrets if running in Streamlit runtime
    try:
        import streamlit as st
        if hasattr(st, "secrets") and "GEMINI_API_KEY" in st.secrets:
            key = st.secrets["GEMINI_API_KEY"]
            if key and str(key).strip():
                return str(key).strip()
    except Exception:
        # Streamlit secrets might raise FileNotFoundError or KeyError outside Streamlit
        pass

    # 2. Try environment variables
    env_key = os.getenv("GEMINI_API_KEY")
    if env_key and env_key.strip():
        return env_key.strip()

    return None


def is_api_key_configured() -> bool:
    """Return True if an API key is available, False otherwise."""
    return get_gemini_api_key() is not None
