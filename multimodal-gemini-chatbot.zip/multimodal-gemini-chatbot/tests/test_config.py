"""
Unit tests for configuration and credentials management.
"""

import os
from unittest.mock import patch
import config


def test_get_gemini_api_key_from_env():
    with patch.dict(os.environ, {"GEMINI_API_KEY": "test_env_key_123"}):
        key = config.get_gemini_api_key()
        assert key == "test_env_key_123"
        assert config.is_api_key_configured() is True


def test_get_gemini_api_key_missing():
    with patch.dict(os.environ, {}, clear=True):
        # Ensure GEMINI_API_KEY is not in env
        if "GEMINI_API_KEY" in os.environ:
            del os.environ["GEMINI_API_KEY"]
        key = config.get_gemini_api_key()
        assert key is None
        assert config.is_api_key_configured() is False


def test_independent_models_configuration():
    assert len(config.AVAILABLE_TEXT_MODELS) >= 2
    assert config.DEFAULT_TEXT_MODEL in config.AVAILABLE_TEXT_MODELS

    assert len(config.AVAILABLE_VISION_MODELS) >= 2
    assert config.DEFAULT_VISION_MODEL in config.AVAILABLE_VISION_MODELS

    assert len(config.AVAILABLE_IMAGE_GEN_MODELS) >= 1
    assert config.DEFAULT_IMAGE_GEN_MODEL in config.AVAILABLE_IMAGE_GEN_MODELS


def test_image_constraints():
    assert config.MAX_IMAGE_SIZE_BYTES == 10 * 1024 * 1024
    assert "image/jpeg" in config.ALLOWED_IMAGE_TYPES
    assert "image/png" in config.ALLOWED_IMAGE_TYPES
    assert ".jpg" in config.ALLOWED_IMAGE_EXTENSIONS
    assert ".png" in config.ALLOWED_IMAGE_EXTENSIONS
