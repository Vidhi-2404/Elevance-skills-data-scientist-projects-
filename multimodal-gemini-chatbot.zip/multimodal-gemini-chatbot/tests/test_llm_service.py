"""
Unit tests for GeminiService: text conversation, multimodal vision, and error translation.
"""

from unittest.mock import MagicMock, patch
from PIL import Image

from services.llm_service import GeminiService


def test_gemini_service_not_configured():
    service = GeminiService(api_key=None)
    assert service.is_configured is False

    success, reply = service.generate_text_response(prompt="Hello")
    assert success is False
    assert "GEMINI_API_KEY" in reply

    img = Image.new("RGB", (50, 50))
    success_v, reply_v = service.generate_multimodal_response(prompt="Analyze this", image=img)
    assert success_v is False
    assert "GEMINI_API_KEY" in reply_v


@patch("google.genai.Client")
def test_gemini_text_generation_success(mock_client_cls):
    mock_client = MagicMock()
    mock_client_cls.return_value = mock_client

    mock_resp = MagicMock()
    mock_resp.text = "Hello! I am Gemini, ready to help."
    mock_client.models.generate_content.return_value = mock_resp

    service = GeminiService(api_key="valid_test_key")
    history = [
        {"role": "user", "content": "Hi"},
        {"role": "assistant", "content": "Hello there"}
    ]

    success, reply = service.generate_text_response(
        prompt="Tell me about python",
        history=history,
        model="gemini-2.5-flash"
    )

    assert success is True
    assert "ready to help" in reply
    mock_client.models.generate_content.assert_called_once()


@patch("google.genai.Client")
def test_gemini_vision_multimodal_success(mock_client_cls):
    mock_client = MagicMock()
    mock_client_cls.return_value = mock_client

    mock_resp = MagicMock()
    mock_resp.text = "The image shows a vibrant red square against a black backdrop."
    mock_client.models.generate_content.return_value = mock_resp

    service = GeminiService(api_key="valid_test_key")
    img = Image.new("RGB", (64, 64), color="red")

    success, reply = service.generate_multimodal_response(
        prompt="Describe this image in detail",
        image=img,
        model="gemini-2.5-flash"
    )

    assert success is True
    assert "vibrant red square" in reply
    mock_client.models.generate_content.assert_called_once()


@patch("google.genai.Client")
def test_gemini_error_403_invalid_key(mock_client_cls):
    mock_client = MagicMock()
    mock_client_cls.return_value = mock_client
    mock_client.models.generate_content.side_effect = Exception("403 API_KEY_INVALID: User key is unauthorized")

    service = GeminiService(api_key="bad_key")
    success, reply = service.generate_text_response(prompt="Test prompt")

    assert success is False
    assert "Authentication Error" in reply
    assert "HTTP 403" in reply


@patch("google.genai.Client")
def test_gemini_error_429_quota(mock_client_cls):
    mock_client = MagicMock()
    mock_client_cls.return_value = mock_client
    mock_client.models.generate_content.side_effect = Exception("429 RESOURCE_EXHAUSTED: Rate limit reached")

    service = GeminiService(api_key="valid_key")
    success, reply = service.generate_text_response(prompt="Test prompt")

    assert success is False
    assert "Quota Exceeded" in reply
    assert "HTTP 429" in reply


@patch("google.genai.Client")
def test_gemini_error_404_model_not_found(mock_client_cls):
    mock_client = MagicMock()
    mock_client_cls.return_value = mock_client
    mock_client.models.generate_content.side_effect = Exception("404 NOT_FOUND: Model not found")

    service = GeminiService(api_key="valid_key")
    success, reply = service.generate_text_response(prompt="Test prompt", model="nonexistent-model")

    assert success is False
    assert "Model Unavailable" in reply
    assert "HTTP 404" in reply
