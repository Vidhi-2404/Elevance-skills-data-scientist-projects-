"""
Unit tests for the Free Knowledge-Base Retrieval service (zero-API-key mode).
"""

from services.retrieval_service import KnowledgeBaseService, Document


def test_knowledge_base_initialization():
    kb = KnowledgeBaseService()
    assert len(kb.documents) > 0
    # Default docs include Gemini overview, vision, etc.
    titles = [d.title for d in kb.documents]
    assert any("Gemini" in t for t in titles)


def test_add_document_and_reindex():
    kb = KnowledgeBaseService()
    initial_count = len(kb.documents)

    doc = kb.add_document(
        title="Autonomous Mobile Robots",
        content="Autonomous mobile robots (AMRs) use LiDAR, SLAM, and computer vision to navigate warehouses.",
        category="Robotics"
    )

    assert len(kb.documents) == initial_count + 1
    assert doc.title == "Autonomous Mobile Robots"

    # Search for new content
    results = kb.search("LiDAR and SLAM navigation")
    assert len(results) > 0
    assert results[0].document.title == "Autonomous Mobile Robots"


def test_ingest_text_file():
    kb = KnowledgeBaseService()
    doc = kb.ingest_text_file("edge_computing.md", "Edge AI runs deep learning models locally on low-power accelerators.")
    assert doc.title == "Edge Computing"
    assert doc.source == "edge_computing.md"

    results = kb.search("Edge AI low-power accelerators")
    assert len(results) > 0
    assert results[0].document.title == "Edge Computing"


def test_retrieval_answer_query_found():
    kb = KnowledgeBaseService()
    answer = kb.answer_query("Tell me about Gemini vision and multimodal capabilities")
    assert answer.has_answer is True
    assert len(answer.sources) > 0
    assert "Retrieval-Based Answering" in answer.mode_label
    assert "Source: Local Knowledge Base" in answer.answer_text


def test_retrieval_answer_query_not_found():
    kb = KnowledgeBaseService()
    answer = kb.answer_query("xyzqwerty nonexistent quantum baking recipe 987654321")
    assert answer.has_answer is False
    assert "No matching documents found" in answer.answer_text
    assert "Free Knowledge-Base Retrieval Mode" in answer.answer_text
