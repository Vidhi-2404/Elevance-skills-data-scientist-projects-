"""
Smoke tests for app module imports, syntax, and zero-key startup resilience.
"""

import ast
import os
from pathlib import Path
from unittest.mock import patch


def test_app_syntax():
    app_path = Path(__file__).resolve().parent.parent / "app.py"
    assert app_path.exists(), "app.py does not exist"

    with open(app_path, "r", encoding="utf-8") as f:
        source = f.read()

    # Must parse without syntax errors
    tree = ast.parse(source)
    assert tree is not None


def test_app_runs_without_api_key_configured():
    """Verify that importing or running config and services without an API key does not crash."""
    with patch.dict(os.environ, {}, clear=True):
        if "GEMINI_API_KEY" in os.environ:
            del os.environ["GEMINI_API_KEY"]

        import config
        from services.retrieval_service import get_knowledge_base
        from services.llm_service import GeminiService
        from services.image_service import validate_uploaded_image

        assert config.get_gemini_api_key() is None

        # Knowledge base works seamlessly
        kb = get_knowledge_base()
        assert len(kb.documents) > 0

        # LLM service handles missing key without raising
        llm = GeminiService()
        assert llm.is_configured is False
        success, reply = llm.generate_text_response("test")
        assert success is False
        assert "not configured" in reply.lower()
