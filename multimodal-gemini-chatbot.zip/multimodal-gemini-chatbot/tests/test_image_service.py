"""
Unit tests for image service: validation, sizing, Imagen 3, and demo preview.
"""

import io
from unittest.mock import MagicMock, patch
from PIL import Image

from services.image_service import (
    validate_uploaded_image,
    generate_image_with_imagen,
    generate_offline_demo_image,
)
from config import MAX_IMAGE_SIZE_BYTES


class MockUploadedFile:
    def __init__(self, name: str, data: bytes):
        self.name = name
        self._data = data
        self.size = len(data)
        self._io = io.BytesIO(data)

    def read(self):
        return self._data

    def seek(self, pos, whence=0):
        return self._io.seek(pos, whence)

    def tell(self):
        return self._io.tell()


def create_test_image_bytes(format="JPEG", size=(100, 100), color=(255, 0, 0)) -> bytes:
    img = Image.new("RGB", size, color=color)
    buf = io.BytesIO()
    img.save(buf, format=format)
    return buf.getvalue()


def test_validate_valid_jpeg():
    raw_bytes = create_test_image_bytes(format="JPEG")
    file_obj = MockUploadedFile(name="sample.jpg", data=raw_bytes)

    res = validate_uploaded_image(file_obj)
    assert res.is_valid is True
    assert res.format == "JPEG"
    assert res.dimensions == (100, 100)
    assert res.error_message is None


def test_validate_valid_png():
    raw_bytes = create_test_image_bytes(format="PNG")
    file_obj = MockUploadedFile(name="sample.png", data=raw_bytes)

    res = validate_uploaded_image(file_obj)
    assert res.is_valid is True
    assert res.format == "PNG"
    assert res.dimensions == (100, 100)


def test_validate_unsupported_extension():
    raw_bytes = b"fake-content"
    file_obj = MockUploadedFile(name="script.py", data=raw_bytes)

    res = validate_uploaded_image(file_obj)
    assert res.is_valid is False
    assert "Unsupported file extension" in res.error_message


def test_validate_oversize_image():
    raw_bytes = b"x" * (MAX_IMAGE_SIZE_BYTES + 1024)
    file_obj = MockUploadedFile(name="large.jpg", data=raw_bytes)

    res = validate_uploaded_image(file_obj)
    assert res.is_valid is False
    assert "exceeds maximum allowed limit" in res.error_message


def test_validate_corrupt_image():
    corrupt_bytes = b"Not an image at all"
    file_obj = MockUploadedFile(name="corrupt.jpg", data=corrupt_bytes)

    res = validate_uploaded_image(file_obj)
    assert res.is_valid is False
    assert "Corrupt or unreadable" in res.error_message


def test_validate_none_upload():
    res = validate_uploaded_image(None)
    assert res.is_valid is False
    assert "No file uploaded" in res.error_message


def test_generate_image_without_api_key():
    success, img_bytes, err = generate_image_with_imagen(
        prompt="A cute cat",
        api_key=None
    )
    assert success is False
    assert img_bytes is None
    assert "GEMINI_API_KEY" in err


def test_generate_image_empty_prompt():
    success, img_bytes, err = generate_image_with_imagen(
        prompt="   ",
        api_key="valid_key"
    )
    assert success is False
    assert "empty" in err.lower()


@patch("google.genai.Client")
def test_generate_image_success(mock_client_cls):
    mock_client = MagicMock()
    mock_client_cls.return_value = mock_client

    fake_bytes = b"fake_imagen_jpeg_bytes"
    mock_gen_img = MagicMock()
    mock_gen_img.image.image_bytes = fake_bytes

    mock_response = MagicMock()
    mock_response.generated_images = [mock_gen_img]
    mock_client.models.generate_images.return_value = mock_response

    success, img_bytes, err = generate_image_with_imagen(
        prompt="A beautiful sunset",
        api_key="test_key"
    )
    assert success is True
    assert img_bytes == fake_bytes
    assert err is None


@patch("google.genai.Client")
def test_generate_image_quota_exceeded(mock_client_cls):
    mock_client = MagicMock()
    mock_client_cls.return_value = mock_client
    mock_client.models.generate_images.side_effect = Exception("429 RESOURCE_EXHAUSTED: Rate limit reached")

    success, img_bytes, err = generate_image_with_imagen(
        prompt="A beautiful sunset",
        api_key="test_key"
    )
    assert success is False
    assert img_bytes is None
    assert "quota exceeded" in err.lower()


def test_generate_offline_demo_image():
    prompt = "A futuristic city in the clouds"
    demo_bytes = generate_offline_demo_image(prompt)
    assert demo_bytes is not None
    assert len(demo_bytes) > 0

    # Ensure it's a valid readable image
    img = Image.open(io.BytesIO(demo_bytes))
    assert img.size == (768, 512)
    assert img.format == "JPEG"
