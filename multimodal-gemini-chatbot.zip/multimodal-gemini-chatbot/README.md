# Multimodal AI Chatbot (Google Gemini & Free Local Retrieval)

[![Streamlit App](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://streamlit.io)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![Google GenAI SDK](https://img.shields.io/badge/SDK-google--genai-green.svg)](https://github.com/googleapis/python-genai)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A production-grade, standalone **Multimodal AI Chatbot** built with Python, Streamlit, and the official Google GenAI SDK (`google-genai`). The application supports multimodal reasoning (text + vision), text-to-image synthesis using **Imagen 3**, and a **Free, Zero-API-Key Knowledge Base Retrieval Mode** using local TF-IDF vectorization and cosine similarity.

---

## 🌟 Key Features

### 1. 💬 Multimodal Conversational AI (Google Gemini)
- **Natural Language Chat**: Multi-turn dialogue powered by `gemini-2.5-flash` or `gemini-1.5-flash` with preserved context.
- **Vision Understanding**: Upload JPEG, PNG, or WebP images to ask questions, describe complex visual scenes, or extract visible text via Optical Character Recognition (OCR).
- **Independent Model Configuration**: Independently configure models for text conversation, vision understanding, and image generation.

### 2. 🎨 High-Fidelity Image Generation (Google Imagen 3)
- **Text-to-Image Generation**: Generate photorealistic images using `imagen-3.0-generate-002`.
- **Interactive UI**: Includes curated example prompt presets, high-resolution previewing, and one-click JPEG image downloads.
- **Offline Demo Mode**: When running without an API key, users can test the image generation interface with simulated previews clearly stamped with an offline banner.

### 3. 🔵 Free Knowledge-Base Retrieval Mode (Zero API Key Required)
- **Zero-Key Resilience**: The app never crashes if `GEMINI_API_KEY` is omitted.
- **TF-IDF & Keyword Search**: Queries local knowledge base documents using `scikit-learn` TF-IDF vectorization and cosine similarity.
- **Transparent Attribution**: All responses are explicitly labeled as `Retrieval-Based Answering (Knowledge Base)`, highlighting matched source documents and relevance scores.
- **Document Ingestion**: Users can upload `.txt` or `.md` files or type custom notes to immediately index new knowledge into memory.

### 4. 🛡️ Enterprise-Grade Resilience & Privacy
- **Strict Validation**: In-memory validation of image formats, dimensions, and file size limits (max 10 MB).
- **Graceful Error Handling**: Actionable diagnostic messages for HTTP 403 (Invalid Key), HTTP 429 (Quota Exceeded), HTTP 404 (Model Unavailable), and network dropouts.
- **Zero Hardcoded Secrets**: Reads keys strictly from Streamlit Secrets or environment variables; uploaded images are processed in-memory and never permanently stored on disk.

---

## 📁 Repository Structure

```
multimodal-gemini-chatbot/
├── app.py                     # Main Streamlit application entry point
├── config.py                  # Independent model configs, limits, and safe key retrieval
├── requirements.txt           # Production dependencies for Streamlit Cloud
├── .env.example               # Template for environment configuration
├── .gitignore                 # Excludes local secrets, caches, and logs
├── README.md                  # Complete documentation and deployment guide
├── data/
│   └── default_knowledge_base.json  # Pre-bundled knowledge articles
├── services/
│   ├── __init__.py
│   ├── llm_service.py         # Gemini text & vision handling via google-genai
│   ├── image_service.py       # Image validation, Pillow processing, and Imagen 3
│   └── retrieval_service.py   # TF-IDF knowledge base search and document ingestion
└── tests/
    ├── __init__.py
    ├── test_config.py         # Configuration and credential retrieval tests
    ├── test_image_service.py  # Image validation and sizing tests
    ├── test_llm_service.py    # LLM and vision error handling tests
    ├── test_retrieval.py      # TF-IDF search and ingestion tests
    └── test_app_smoke.py      # App import and zero-key resilience tests
```

---

## 🚀 Quickstart: Local Installation

### Prerequisites
- Python 3.10 or 3.11
- Git

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/multimodal-gemini-chatbot.git
cd multimodal-gemini-chatbot
```

### 2. Set Up a Virtual Environment
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure API Key (Optional)
If you wish to use Gemini AI and Imagen 3 features:
```bash
# Copy the example environment file
cp .env.example .env
```
Edit `.env` and set:
```ini
GEMINI_API_KEY=your_actual_gemini_api_key_here
```
> **Note**: If you skip this step, the application will automatically launch in **Free Knowledge-Base Retrieval Mode**. You can also enter an API key temporarily in the application sidebar during your session.

### 5. Launch the Streamlit App
```bash
python -m streamlit run app.py
```
Open your browser to `http://localhost:8501`.

---

## 🧪 Running the Automated Test Suite

The project includes unit, integration, and smoke tests:

```bash
python -m pytest -v
```

All 28 tests validate:
- Configuration parsing and credential handling
- Image size and format validation (JPEG, PNG, WebP)
- Mocked Gemini text generation and conversation history
- Mocked multimodal vision questions and OCR
- Mocked Imagen 3 image generation
- HTTP 403, 429, and 404 error translation
- TF-IDF indexing, document ingestion, and cosine similarity retrieval
- Zero-key application startup resilience

---

## ☁️ Deployment to Streamlit Community Cloud

This project is pre-configured for instant deployment to [Streamlit Community Cloud](https://share.streamlit.io).

### Option A: Zero-API-Key Deployment (Free Mode)
The application is designed to boot and run on Streamlit Cloud **without configuring any secrets**:
1. Push your code to GitHub:
   ```bash
   git add .
   git commit -m "Initial commit of Multimodal Gemini Chatbot"
   git remote add origin https://github.com/your-username/multimodal-gemini-chatbot.git
   git push -u origin main
   ```
2. Go to [share.streamlit.io](https://share.streamlit.io) and log in with GitHub.
3. Click **New app**.
4. Select your repository `multimodal-gemini-chatbot`, branch `main`, and main file `app.py`.
5. Click **Deploy!**
6. The app will launch immediately in **Free Knowledge-Base Retrieval Mode** with full document ingestion and offline search capabilities enabled.

### Option B: Enabling Gemini & Imagen 3 with Secrets
To unlock live Gemini conversational reasoning and Imagen 3 generation on Streamlit Cloud:
1. In your deployed app on Streamlit Cloud, click the three dots (`...`) in the bottom-right corner and select **Settings** -> **Secrets**.
2. Add your Gemini API key in TOML format:
   ```toml
   GEMINI_API_KEY = "AIzaSy..."
   ```
3. Click **Save**. The app will reload and activate **🟢 Gemini Multimodal Mode**.

---

## 🔒 Security & Privacy

- **No Hardcoded Secrets**: Secrets are loaded exclusively from Streamlit Secrets or environment variables.
- **In-Memory Image Processing**: Uploaded images are held in memory as PIL Image objects and discarded after processing.
- **Git Hygiene**: `.gitignore` prevents `.env`, local secrets, and caches from being committed.

---

## 📄 License
This project is licensed under the MIT License.
