"""
ArXiv Dataset Ingestion and Preprocessing Pipeline.

Processes raw arXiv metadata from Kaggle (arxiv-metadata-oai-snapshot.json)
or pre-filtered subsets into a clean, validated JSON dataset for indexing.

Features:
- Streaming line-by-line processing (low memory footprint for multi-GB files)
- Schema validation and malformed line recovery
- Category filtering (defaults to Computer Science categories: cs.*)
- Text cleanup (LaTeX artifact reduction, whitespace normalization)
- Derived field enrichment (arXiv link, PDF link, publication year)
- Duplicate detection by paper ID and title
"""

import argparse
import json
import logging
import re
import sys
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional, Set

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

DEFAULT_CS_CATEGORIES = {
    "cs.AI",  # Artificial Intelligence
    "cs.LG",  # Machine Learning
    "cs.CL",  # Computation and Language
    "cs.CV",  # Computer Vision
    "cs.CR",  # Cryptography and Security
    "cs.NE",  # Neural and Evolutionary Computing
    "cs.RO",  # Robotics
    "cs.SE",  # Software Engineering
    "cs.DC",  # Distributed Computing
    "cs.IR",  # Information Retrieval
}


def clean_text(text: Optional[str]) -> str:
    """Normalize whitespace and strip LaTeX newline markers."""
    if not text:
        return ""
    # Replace multiple whitespace/newlines with single space
    cleaned = re.sub(r"\s+", " ", text).strip()
    return cleaned


def extract_year_from_versions(versions: Optional[List[Dict[str, Any]]], update_date: Optional[str]) -> str:
    """Extract 4-digit publication year from versions or update_date."""
    if versions and isinstance(versions, list) and len(versions) > 0:
        first_created = versions[0].get("created", "")
        # Date string often format: "Mon, 12 Jun 2017 17:57:34 GMT"
        match = re.search(r"\b(19\d\d|20\d\d)\b", first_created)
        if match:
            return match.group(1)
            
    if update_date:
        match = re.search(r"^(19\d\d|20\d\d)", update_date)
        if match:
            return match.group(1)
            
    return "Unknown"


def validate_and_normalize_paper(record: Dict[str, Any], allowed_categories: Optional[Set[str]] = None) -> Optional[Dict[str, Any]]:
    """
    Validate a single arXiv record against schema requirements.
    Returns normalized dict or None if invalid/filtered out.
    """
    paper_id = str(record.get("id", "")).strip()
    title = clean_text(record.get("title"))
    abstract = clean_text(record.get("abstract"))
    categories_str = str(record.get("categories", "")).strip()

    # Minimum validation: must have ID, title, and abstract
    if not paper_id or not title or not abstract:
        return None
    
    # Filter by category if specified
    cats = [c.strip() for c in categories_str.split() if c.strip()]
    if allowed_categories:
        # Check if paper belongs to any allowed category
        if not any(c in allowed_categories for c in cats):
            return None

    # Authors formatting
    authors = clean_text(record.get("authors", ""))
    if not authors:
        authors_parsed = record.get("authors_parsed", [])
        if authors_parsed and isinstance(authors_parsed, list):
            names = []
            for item in authors_parsed:
                if isinstance(item, list) and len(item) >= 2:
                    last, first = item[0], item[1]
                    names.append(f"{first} {last}".strip())
            authors = ", ".join(names)
        if not authors:
            authors = "Unknown Authors"

    # Links
    arxiv_url = f"https://arxiv.org/abs/{paper_id}"
    pdf_url = f"https://arxiv.org/pdf/{paper_id}.pdf"
    
    doi = record.get("doi")
    doi_url = f"https://doi.org/{doi}" if doi else None

    year = extract_year_from_versions(record.get("versions"), record.get("update_date"))

    return {
        "id": paper_id,
        "title": title,
        "abstract": abstract,
        "authors": authors,
        "categories": categories_str,
        "primary_category": cats[0] if cats else "cs.AI",
        "category_list": cats,
        "year": year,
        "update_date": str(record.get("update_date", "")).strip(),
        "journal_ref": record.get("journal-ref"),
        "doi": doi,
        "arxiv_url": arxiv_url,
        "pdf_url": pdf_url,
        "doi_url": doi_url,
        "is_full_text": False,  # Strict disclosure: arXiv dataset stores abstracts, not full body
    }


def stream_arxiv_jsonl(file_path: Path) -> Generator[Dict[str, Any], None, None]:
    """Stream lines from a JSON lines file or single JSON array file safely."""
    with open(file_path, "r", encoding="utf-8", errors="replace") as f:
        first_char = f.read(1)
        f.seek(0)
        
        if first_char == "[":
            # Standard JSON array format
            try:
                data = json.load(f)
                for item in data:
                    yield item
            except Exception as e:
                logger.error("Failed to load JSON array: %s", e)
        else:
            # JSON-Lines format (Kaggle default)
            line_num = 0
            for line in f:
                line_num += 1
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                    yield record
                except json.JSONDecodeError:
                    logger.warning("Malformed JSON on line %d, skipping.", line_num)
                    continue


def process_arxiv_dataset(
    input_path: Path,
    output_path: Path,
    categories: Optional[Set[str]] = None,
    limit: Optional[int] = None,
) -> int:
    """
    Main extraction routine: read raw arXiv data, filter, validate, deduplicate, and write out clean dataset.
    """
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    logger.info("Processing arXiv dataset from %s", input_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    seen_ids: Set[str] = set()
    seen_titles: Set[str] = set()
    processed_papers: List[Dict[str, Any]] = []

    count = 0
    for raw_record in stream_arxiv_jsonl(input_path):
        normalized = validate_and_normalize_paper(raw_record, allowed_categories=categories)
        if not normalized:
            continue

        paper_id = normalized["id"]
        norm_title = normalized["title"].lower()

        # Duplicate check by ID and exact normalized title
        if paper_id in seen_ids or norm_title in seen_titles:
            continue

        seen_ids.add(paper_id)
        seen_titles.add(norm_title)
        processed_papers.append(normalized)
        count += 1

        if count % 1000 == 0:
            logger.info("Processed %d valid papers...", count)

        if limit and count >= limit:
            logger.info("Reached target limit of %d papers.", limit)
            break

    # Save to clean JSON
    with open(output_path, "w", encoding="utf-8") as out_f:
        json.dump(processed_papers, out_f, indent=2, ensure_ascii=False)

    logger.info("Successfully extracted %d papers to %s", len(processed_papers), output_path)
    return len(processed_papers)


def main():
    parser = argparse.ArgumentParser(description="Extract and prepare arXiv CS papers subset from Kaggle dataset.")
    parser.add_argument("--input", "-i", type=str, default="data/arxiv-metadata-oai-snapshot.json", help="Path to raw Kaggle arXiv JSONL")
    parser.add_argument("--output", "-o", type=str, default="data/processed_arxiv_cs.json", help="Path to write processed JSON")
    parser.add_argument("--limit", "-n", type=int, default=500, help="Maximum number of papers to extract (default: 500)")
    parser.add_argument("--categories", "-c", type=str, default="cs.AI,cs.LG,cs.CL,cs.CV,cs.CR,cs.SE,cs.RO", help="Comma-separated category filters")
    
    args = parser.parse_args()
    
    input_p = Path(args.input)
    output_p = Path(args.output)
    cats = set([c.strip() for c in args.categories.split(",") if c.strip()])

    if not input_p.exists():
        logger.warning(
            "Input file '%s' does not exist.\n"
            "To use real Kaggle data, download 'arxiv-metadata-oai-snapshot.json' from:\n"
            "https://www.kaggle.com/datasets/Cornell-University/arxiv\n"
            "Using bundled sample dataset at data/sample_arxiv_cs.json for verification.",
            input_p
        )
        sample_path = Path("data/sample_arxiv_cs.json")
        if sample_path.exists():
            process_arxiv_dataset(sample_path, output_p, categories=None, limit=args.limit)
            return
        else:
            logger.error("Sample dataset not found. Exiting.")
            sys.exit(1)

    process_arxiv_dataset(input_p, output_p, categories=cats, limit=args.limit)


if __name__ == "__main__":
    main()
