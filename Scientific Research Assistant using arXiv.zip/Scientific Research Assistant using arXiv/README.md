# 🔬 Scientific Research Assistant using arXiv

An autonomous, literature-grounded research intelligence assistant for computer science papers from the **Cornell University arXiv Dataset**.

[![Python 3.10+](https://img.shields.io/badge/python-3.10%20%7C%203.11-blue.svg)](https://www.python.org/)
[![Streamlit App](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://share.streamlit.io/)
[![License: CC0-1.0](https://img.shields.io/badge/License-CC0_1.0-lightgrey.svg)](https://creativecommons.org/publicdomain/zero/1.0/)
[![Tests](https://img.shields.io/badge/pytest-17%20passed-brightgreen.svg)]()

---

## 🌟 Highlights & Key Features

- **🚀 100% Free & Zero-API-Key Retrieval Mode**: Runs out of the box on Streamlit Community Cloud without requiring any API key, payment, or external account. Uses locally executed TF-IDF and dense vector indexing.
- **✨ Optional Gemini AI Mode**: Seamlessly toggle to Google Gemini when an API key is provided, with automated resilient fallback to Free Retrieval mode on network or quota errors.
- **🎓 Multi-Level Technical Explanations**: Breaks down complex computer science concepts into **Beginner** (intuitive analogies), **Intermediate** (architectural pipelines), and **Advanced** (algorithmic complexity, IO-awareness, and mathematical trade-offs).
- **🛡️ Strictly Grounded & Zero Hallucinations**: All citations, paper titles, authors, and arXiv IDs are strictly extracted from verified indexed records. Never invents citations or findings.
- **⚠️ Abstract-Only Scope Transparency**: Transparently distinguishes abstract metadata from full-text analysis.
- **🗺️ Interactive Concept Maps**: Auto-generates interactive Mermaid flowcharts illustrating the relationships between user queries, retrieved papers, and core mechanisms.
- **⚡ Dual-Engine Hybrid Retrieval**: Combines dense semantic vector search (ChromaDB) and sublinear TF-IDF lexical search with metadata filters (categories and publication year).
- **🔄 Incremental Indexing & Deduplication**: Prevents duplicate entries via arXiv ID matching and normalized title string comparison.

---

## 🏗️ Architecture

```
                                  User Query
                                      │
                     ┌────────────────┴────────────────┐
                     │                                 │
                     ▼                                 ▼
             [Lexical TF-IDF]                 [Semantic Vector]
            Scikit-Learn Index                ChromaDB Collection
                     │                                 │
                     └────────────────┬────────────────┘
                                      │
                                      ▼
                        [Hybrid Rank Fusion & Filters]
                           (Category & Year Bounds)
                                      │
                                      ▼
                     Top-K Verified Research Abstracts
                                      │
            ┌─────────────────────────┴─────────────────────────┐
            │                                                   │
            ▼                                                   ▼
 ⚡ Free Retrieval Engine                             ✨ Optional Gemini AI
 (100% Offline & Key-Free)                           (When API Key Supplied)
  • Sentence extractive scoring                       • Grounded generation
  • Multi-level structure (Beg/Int/Adv)               • Resilient auto-fallback
  • Validated Mermaid concept map                     • Validated Mermaid map
            │                                                   │
            └─────────────────────────┬─────────────────────────┘
                                      │
                                      ▼
                         Streamlit Interactive UI
```

---

## 📊 Dataset Schema & Acquisition

This project uses the official [Cornell University arXiv Dataset on Kaggle](https://www.kaggle.com/datasets/Cornell-University/arxiv).

### Schema Specification:
| Field | Type | Description |
|---|---|---|
| `id` | String | arXiv identifier (e.g., `1706.03762`) |
| `title` | String | Peer-reviewed paper title |
| `authors` | String | Author list |
| `categories` | String | Space-delimited category codes (e.g. `cs.CL cs.LG`) |
| `abstract` | String | Complete abstract text |
| `versions` | List[Dict] | Publication and revision timestamps |
| `doi` | String | Digital Object Identifier (when available) |

### Attribution & Licensing
- **Source**: Cornell University arXiv Dataset on Kaggle.
- **License**: CC0 1.0 Universal Public Domain.
- **Disclaimer**: Analysis is strictly based on peer-reviewed abstracts and bibliographic records. Full-text bodies are not analyzed unless explicitly stated.

---

## ⚡ Quickstart (Local Installation)

### 1. Clone Repository & Setup Virtual Environment
```bash
git clone https://github.com/your-username/arxiv-research-assistant.git
cd arxiv-research-assistant

python -m venv venv
# Windows:
venv\Scripts\activate
# Linux/macOS:
source venv/bin/activate
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. (Optional) Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
> **Note**: An API key is **completely optional**. The app runs at 100% functionality in **Free Retrieval Mode** without touching any API.

### 4. Run the Streamlit Application
```bash
streamlit run app.py
```
Open your browser to `http://localhost:8501`.

---

## 📥 Ingestion & Preprocessing Scripts

To preprocess a subset of raw Kaggle data:
```bash
# Extract 500 Computer Science papers
python scripts/prepare_arxiv.py --input data/arxiv-metadata-oai-snapshot.json --output data/processed_arxiv_cs.json --limit 500 --categories cs.AI,cs.LG,cs.CL,cs.CV,cs.CR
```
If the raw 4GB dataset is not downloaded, running `prepare_arxiv.py` automatically uses the bundled verified sample dataset in `data/sample_arxiv_cs.json`.

---

## 🧪 Automated Testing

Automated testing covers schema validation, streaming parsing, duplicate detection, hybrid retrieval, free synthesis, multi-level explanations, citation formatting, and error fallbacks.

Run the test suite:
```bash
python -m pytest -v
```

### Test Results Summary:
```
tests/test_parser.py::test_clean_text PASSED
tests/test_parser.py::test_extract_year PASSED
tests/test_parser.py::test_validate_and_normalize_valid PASSED
tests/test_parser.py::test_validate_and_normalize_missing_fields PASSED
tests/test_parser.py::test_category_filtering PASSED
tests/test_parser.py::test_process_arxiv_dataset_streaming_and_deduplication PASSED
tests/test_research_service.py::test_clean_mermaid_label PASSED
tests/test_research_service.py::test_extract_top_sentences PASSED
tests/test_research_service.py::test_free_retrieval_answer_synthesis PASSED
tests/test_research_service.py::test_empty_results_graceful_handling PASSED
tests/test_research_service.py::test_gemini_fallback_when_invalid_key PASSED
tests/test_retrieval.py::test_normalize_title PASSED
tests/test_retrieval.py::test_indexing_and_duplicate_detection PASSED
tests/test_retrieval.py::test_batch_indexing PASSED
tests/test_retrieval.py::test_keyword_search_tfidf PASSED
tests/test_retrieval.py::test_category_and_year_filtering PASSED
tests/test_retrieval.py::test_empty_query_and_no_crash PASSED

================== 17 passed in 1.16s ==================
```

---

## 🚀 Deployment to Streamlit Community Cloud (Zero API Key)

Deploying this app to Streamlit Community Cloud requires **no API keys**:

1. **Initialize Git Repository and Commit:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit of arXiv Scientific Research Assistant"
   ```

2. **Push to GitHub:**
   Create a new public repository named `arxiv-research-assistant` on GitHub, then push:
   ```bash
   git branch -M main
   git remote add origin https://github.com/your-username/arxiv-research-assistant.git
   git push -u origin main
   ```

3. **Deploy on Streamlit Community Cloud:**
   - Go to [share.streamlit.io](https://share.streamlit.io) and log in with your GitHub account.
   - Click **"New app"**.
   - Select repository: `your-username/arxiv-research-assistant`.
   - Branch: `main`.
   - Main file path: `app.py`.
   - **Secrets**: Leave empty! No API key is required. The app automatically runs in Free Retrieval Mode.
   - Click **"Deploy!"**.

4. **Verify Deployment:**
   - Your public URL will be `https://<your-app-name>.streamlit.app`.
   - Try queries like *"How does FlashAttention optimize memory?"* or *"Explain LoRA parameter-efficient fine-tuning"*.
   - Verify that the badge shows **`Engine: Free Retrieval-Based Extractive Synthesis`** and multi-level explanations and concept maps render smoothly.

---

## 📌 Project Structure

```
arxiv-research-assistant/
├── .env.example                    # Configuration template
├── .gitignore                      # Git ignore excluding large data/caches
├── README.md                       # Complete documentation & deployment guide
├── requirements.txt                # Lean Streamlit Cloud dependencies
├── config.py                       # Application configuration
├── app.py                          # Streamlit application entrypoint
├── data/
│   ├── sample_arxiv_cs.json        # Bundled seminal CS papers
│   └── processed_arxiv_cs.json     # Processed pre-filtered dataset
├── scripts/
│   └── prepare_arxiv.py            # Stream parser, validator & deduplicator
├── services/
│   ├── __init__.py
│   ├── retrieval_service.py        # Vector + TF-IDF hybrid retrieval
│   └── research_service.py         # Multi-level synthesis & Mermaid mapping
└── tests/
    ├── __init__.py
    ├── conftest.py                 # Synthetic paper fixtures
    ├── test_parser.py              # Parsing & validation unit tests
    ├── test_retrieval.py           # Indexing & search unit tests
    └── test_research_service.py    # Answering & citation integrity tests
```

---

## ⚠️ Limitations & Scope
- **Abstract-Level Knowledge**: Answers and citations are strictly generated from indexed arXiv abstracts. Internal paper tables, appendices, and implementation code bodies outside the abstract are not indexed.
- **Hardware Footprint**: In Free Mode, the application operates entirely within Streamlit Cloud's ~1GB RAM boundary using Scikit-Learn TF-IDF and lightweight vector matrices.
