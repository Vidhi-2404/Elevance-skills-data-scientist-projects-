import os
from pathlib import Path
from dataclasses import dataclass
from dotenv import load_dotenv

# Load .env file if available
load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
CHROMA_DIR = BASE_DIR / "chroma_db"
SAMPLE_DATA_PATH = DATA_DIR / "sample_arxiv_cs.json"

# Ensure runtime directories exist
DATA_DIR.mkdir(parents=True, exist_ok=True)


@dataclass
class AppConfig:
    """Central configuration for arXiv Scientific Research Assistant."""
    
    # Environment & API
    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "").strip()
    gemini_model_name: str = os.getenv("GEMINI_MODEL", "gemini-1.5-flash").strip()
    
    # Retrieval Settings
    default_top_k: int = int(os.getenv("DEFAULT_TOP_K", "5"))
    chroma_db_dir: Path = CHROMA_DIR
    data_dir: Path = DATA_DIR
    sample_data_path: Path = SAMPLE_DATA_PATH
    
    # Categories
    default_categories: tuple = (
        "cs.AI",  # Artificial Intelligence
        "cs.LG",  # Machine Learning
        "cs.CL",  # Computation and Language (NLP)
        "cs.CV",  # Computer Vision
        "cs.CR",  # Cryptography and Security
        "cs.NE",  # Neural and Evolutionary Computing
        "cs.RO",  # Robotics
        "cs.SE",  # Software Engineering
        "cs.DC",  # Distributed Computing
        "cs.IR",  # Information Retrieval
    )

    @property
    def has_gemini_key(self) -> bool:
        """Returns True only if a valid, non-placeholder Gemini API key is configured."""
        if not self.gemini_api_key:
            return False
        # Avoid common placeholders
        if self.gemini_api_key in ("your_api_key_here", "TODO", "NONE", "test"):
            return False
        return len(self.gemini_api_key) > 8


config = AppConfig()
