"""
Scientific Research Assistant using arXiv.
A standalone, production-ready Streamlit research intelligence application.
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List

import streamlit as st
import streamlit.components.v1 as components

from config import config
from services.research_service import ResearchService
from services.retrieval_service import RetrievalService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Streamlit Page Configuration
st.set_page_config(
    page_title="ArXiv Research Assistant",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS for Sleek Scientific Theme
st.markdown(
    """
    <style>
    .main-header {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        font-weight: 800;
        background: linear-gradient(135deg, #0ea5e9 0%, #3b82f6 50%, #6366f1 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-size: 2.3rem;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        color: #94a3b8;
        font-size: 1.05rem;
        margin-bottom: 1.5rem;
    }
    .badge-free {
        background-color: #064e3b;
        color: #34d399;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
        border: 1px solid #059669;
        display: inline-block;
    }
    .badge-gemini {
        background-color: #1e1b4b;
        color: #a5b4fc;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
        border: 1px solid #4f46e5;
        display: inline-block;
    }
    .badge-scope {
        background-color: #451a03;
        color: #fbbf24;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
        border: 1px solid #d97706;
        display: inline-block;
    }
    .paper-card {
        background-color: rgba(30, 41, 59, 0.6);
        border: 1px solid rgba(148, 163, 184, 0.2);
        border-radius: 10px;
        padding: 1.2rem;
        margin-bottom: 1rem;
        transition: transform 0.15s ease, border-color 0.15s ease;
    }
    .paper-card:hover {
        border-color: #38bdf8;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 12px;
    }
    .stTabs [data-baseweb="tab"] {
        border-radius: 6px;
        padding: 8px 16px;
        font-weight: 600;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


def render_mermaid(diagram_code: str, height: int = 340):
    """Render Mermaid chart safely via HTML iframe component."""
    html_code = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
        <script>
            mermaid.initialize({{
                startOnLoad: true,
                theme: 'dark',
                securityLevel: 'loose',
                themeVariables: {{
                    darkMode: true,
                    background: '#0f172a',
                    primaryColor: '#1e293b',
                    primaryTextColor: '#f8fafc',
                    lineColor: '#38bdf8',
                    secondaryColor: '#334155'
                }}
            }});
        </script>
        <style>
            body {{
                margin: 0;
                background-color: transparent;
                display: flex;
                justify-content: center;
                align-items: center;
                font-family: sans-serif;
            }}
        </style>
    </head>
    <body>
        <div class="mermaid">
        {diagram_code}
        </div>
    </body>
    </html>
    """
    if hasattr(st, "html"):
        st.html(html_code)
    else:
        components.html(html_code, height=height, scrolling=True)


@st.cache_resource
def get_retrieval_service() -> RetrievalService:
    """Initialize and persist RetrievalService across reruns."""
    service = RetrievalService(chroma_db_dir=config.chroma_db_dir)

    # Automatically seed with pre-processed or sample data on first load
    processed_p = config.data_dir / "processed_arxiv_cs.json"
    if processed_p.exists():
        service.load_from_json(processed_p)
    elif config.sample_data_path.exists():
        service.load_from_json(config.sample_data_path)

    return service


@st.cache_resource
def get_research_service(api_key: str = "") -> ResearchService:
    """Initialize ResearchService with configurable API key."""
    key = api_key or config.gemini_api_key
    return ResearchService(gemini_api_key=key, gemini_model=config.gemini_model_name)


# Initialize services
retrieval_service = get_retrieval_service()

# Initialize session state variables
if "active_query" not in st.session_state:
    st.session_state.active_query = ""
if "last_results" not in st.session_state:
    st.session_state.last_results = None
if "selected_paper_id" not in st.session_state:
    st.session_state.selected_paper_id = None


# --- SIDEBAR CONFIGURATION ---
with st.sidebar:
    st.image("https://upload.wikimedia.org/wikipedia/commons/b/bc/ArXiv_logo_2022.svg", width=140)
    st.markdown("### 🔬 System Configuration")

    # API Key Configuration (Optional)
    st.markdown("#### ⚙️ LLM Backend")
    gemini_key_input = st.text_input(
        "Gemini API Key (Optional)",
        type="password",
        value=config.gemini_api_key,
        help="Leave blank to run 100% Free Local Mode without API keys or external dependencies.",
        placeholder="AIzaSy...",
    )

    # Backend selection
    backend_options = ["Auto-Detect (Free by Default)", "Free Retrieval Engine (100% Local)", "Gemini AI"]
    selected_backend = st.selectbox(
        "Answering Mode",
        options=backend_options,
        index=0,
        help="Select answering backend. Free mode requires zero API keys and never fails.",
    )

    # Active status badge in sidebar
    has_custom_key = bool(gemini_key_input and len(gemini_key_input) > 8 and "your_" not in gemini_key_input)
    if (selected_backend == "Gemini AI" or selected_backend == "Auto-Detect (Free by Default)") and has_custom_key:
        st.markdown('<div class="badge-gemini">✨ Gemini AI Active</div>', unsafe_allow_html=True)
        active_mode = "gemini"
    else:
        st.markdown('<div class="badge-free">⚡ Free Retrieval Engine (Key-Free)</div>', unsafe_allow_html=True)
        active_mode = "retrieval_free"

    st.markdown("---")

    # Retrieval Tuning
    st.markdown("#### 🔍 Retrieval Settings")
    retrieval_method = st.radio(
        "Search Algorithm",
        options=["Hybrid (Semantic + TF-IDF)", "ChromaDB Semantic Vector", "TF-IDF Lexical Match"],
        index=0,
    )
    top_k = st.slider("Top Sources to Retrieve", min_value=1, max_value=10, value=config.default_top_k)

    available_categories = ["All"] + retrieval_service.get_categories()
    category_filter = st.selectbox("Category Filter", options=available_categories, index=0)

    year_filter = st.slider("Publication Year Range", min_value=2015, max_value=2026, value=(2015, 2026))

    st.markdown("---")
    stats = retrieval_service.get_stats()
    st.markdown("#### 📊 Knowledge Base Stats")
    col_s1, col_s2 = st.columns(2)
    col_s1.metric("Indexed Papers", stats["total_papers"])
    col_s2.metric("Categories", stats["categories_count"])


# Instantiate Research Service
research_service = get_research_service(api_key=gemini_key_input if has_custom_key else "")


# --- MAIN INTERFACE ---
st.markdown('<h1 class="main-header">Scientific Research Assistant</h1>', unsafe_allow_html=True)
st.markdown(
    '<p class="sub-header">Autonomous literature retrieval, multi-level technical QA, and grounded concept synthesis from the arXiv scientific corpus.</p>',
    unsafe_allow_html=True,
)

tab_qa, tab_search, tab_graph, tab_ingest = st.tabs([
    "🔬 Research QA & Synthesis",
    "🔍 Paper Search & Explorer",
    "🗺️ Concept Graph Visualizer",
    "📚 Knowledge Base Management",
])


# ==========================================
# TAB 1: RESEARCH QA & SYNTHESIS
# ==========================================
with tab_qa:
    st.markdown("### 💬 Ask a Research Question")
    st.caption("Ask questions about models, algorithms, benchmarks, and architectures. Answers are strictly grounded in indexed arXiv research.")

    # Quick sample query pills
    st.markdown("**Suggested Research Queries:**")
    q_cols = st.columns(4)
    if q_cols[0].button("⚡ FlashAttention IO-Awareness"):
        st.session_state.active_query = "How does FlashAttention optimize memory access and IO complexity?"
    if q_cols[1].button("🧩 LoRA Fine-Tuning"):
        st.session_state.active_query = "How does LoRA low-rank adaptation work for parameter-efficient tuning?"
    if q_cols[2].button("📚 Retrieval-Augmented Generation"):
        st.session_state.active_query = "What is Retrieval-Augmented Generation (RAG) and how does it combine memory?"
    if q_cols[3].button("🔄 Transformers vs Convolution"):
        st.session_state.active_query = "Compare Transformer self-attention with deep residual networks"

    query_input = st.text_input(
        "Enter your research query:",
        value=st.session_state.active_query,
        placeholder="e.g. How does Low-Rank Adaptation (LoRA) reduce GPU memory requirements?",
        key="qa_query_box",
    )

    col_btn1, col_btn2 = st.columns([1, 5])
    submit_query = col_btn1.button("🚀 Analyze & Synthesize", type="primary", use_container_width=True)

    if submit_query and query_input.strip():
        st.session_state.active_query = query_input.strip()

        with st.spinner("Retrieving literature and synthesizing technical explanation..."):
            # Step 1: Retrieval
            cat_arg = None if category_filter == "All" else category_filter
            if "Hybrid" in retrieval_method:
                retrieved = retrieval_service.search_hybrid(
                    query_input, top_k=top_k, category_filter=cat_arg, year_filter=year_filter
                )
            elif "Semantic" in retrieval_method:
                retrieved = retrieval_service.search_semantic(
                    query_input, top_k=top_k, category_filter=cat_arg, year_filter=year_filter
                )
            else:
                retrieved = retrieval_service.search_keyword(
                    query_input, top_k=top_k, category_filter=cat_arg, year_filter=year_filter
                )

            # Step 2: Synthesis
            result = research_service.answer_query(
                query=query_input,
                retrieved_papers=retrieved,
                engine_mode=active_mode,
            )
            st.session_state.last_results = (query_input, retrieved, result)

    # Render results if available
    if st.session_state.last_results:
        q_used, papers_used, ans = st.session_state.last_results

        st.markdown("---")

        # Status and Badges
        c_badge1, c_badge2 = st.columns([3, 1])
        with c_badge1:
            if ans["is_generative_ai"]:
                st.markdown(f'<span class="badge-gemini">Engine: {ans["engine_used"]}</span>', unsafe_allow_html=True)
            else:
                st.markdown('<span class="badge-free">Engine: Free Retrieval-Based Extractive Synthesis (Key-Free)</span>', unsafe_allow_html=True)
            st.markdown(' <span class="badge-scope">Scope: Indexed arXiv Abstracts Only</span>', unsafe_allow_html=True)

        if ans.get("fallback_occurred"):
            st.warning(f"⚠️ {ans.get('fallback_reason')}")

        st.markdown(f"#### 📑 Core Research Synthesis for: *'{q_used}'*")
        st.markdown(ans["summary"])

        # Multi-Level Explanation Tabs
        st.markdown("#### 🎓 Multi-Level Technical Explanations")
        lvl_tab1, lvl_tab2, lvl_tab3 = st.tabs(["🌱 Beginner", "⚙️ Intermediate", "🔬 Advanced"])

        with lvl_tab1:
            st.info(ans["beginner_explanation"])
        with lvl_tab2:
            st.markdown(ans["intermediate_explanation"])
        with lvl_tab3:
            st.markdown(ans["advanced_explanation"])

        # Concept Map Visualization
        st.markdown("#### 🗺️ Literature Concept Map")
        st.caption("Auto-generated visual relationships between query concepts, retrieved architectures, and key findings.")
        render_mermaid(ans["concept_map_mermaid"], height=320)

        # Verified Citations & References
        st.markdown("#### 📚 Verified Source Citations")
        st.caption("Direct references extracted from indexed arXiv records. All URLs and IDs are verified.")
        for cit in ans["citations"]:
            with st.expander(f"📄 [{cit['paper_id']}] {cit['title']} ({cit['year']})"):
                st.markdown(f"**Authors:** {cit['authors']}")
                st.markdown(f"**Category:** `{cit['category']}`")
                st.markdown(f"**Verified Links:** [arXiv Abstract Page]({cit['arxiv_url']}) | [PDF Document]({cit['pdf_url']})")
                st.markdown(f"**Extracted Evidence Excerpt:** *\"{cit['evidence_quote']}\"*")

        # Grounded Follow-up Questions
        if ans["follow_up_questions"]:
            st.markdown("#### 💡 Suggested Follow-Up Research Questions")
            for fq in ans["follow_up_questions"]:
                if st.button(f"👉 {fq}", key=f"fq_{abs(hash(fq))}"):
                    st.session_state.active_query = fq
                    st.rerun()


# ==========================================
# TAB 2: PAPER SEARCH & EXPLORER
# ==========================================
with tab_search:
    st.markdown("### 🔍 Search arXiv Knowledge Base")
    st.caption("Directly search indexed papers by title, abstract, or domain keywords.")

    search_term = st.text_input("Enter search keywords or paper title:", placeholder="e.g. Attention, BERT, Diffusion, LoRA...")
    
    col_s_btn, _ = st.columns([1, 4])
    do_search = col_s_btn.button("Search Papers", type="secondary")

    if search_term or do_search:
        cat_arg = None if category_filter == "All" else category_filter
        if "Hybrid" in retrieval_method:
            search_res = retrieval_service.search_hybrid(search_term, top_k=top_k, category_filter=cat_arg, year_filter=year_filter)
        elif "Semantic" in retrieval_method:
            search_res = retrieval_service.search_semantic(search_term, top_k=top_k, category_filter=cat_arg, year_filter=year_filter)
        else:
            search_res = retrieval_service.search_keyword(search_term, top_k=top_k, category_filter=cat_arg, year_filter=year_filter)

        st.markdown(f"Found **{len(search_res)}** matching research papers:")

        for p in search_res:
            with st.container():
                st.markdown(
                    f"""
                    <div class="paper-card">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <h4 style="margin:0; color:#38bdf8;">{p['title']}</h4>
                            <span style="font-size:0.8rem; background:#334155; padding:2px 8px; border-radius:4px;">{p.get('year', 'N/A')}</span>
                        </div>
                        <p style="color:#94a3b8; font-size:0.85rem; margin-top:4px;">
                            <strong>Authors:</strong> {p.get('authors', 'Unknown')} | 
                            <strong>Categories:</strong> <code>{p.get('categories', '')}</code> | 
                            <strong>Match Score:</strong> {p.get('retrieval_score', 0.0)} ({p.get('retrieval_method', '')})
                        </p>
                        <p style="font-size:0.9rem; line-height:1.5;">{p.get('abstract', '')[:350]}...</p>
                        <div style="margin-top:8px;">
                            <a href="{p.get('arxiv_url')}" target="_blank" style="margin-right:15px; color:#38bdf8;">🔗 arXiv Abstract</a>
                            <a href="{p.get('pdf_url')}" target="_blank" style="margin-right:15px; color:#a78bfa;">📥 Download PDF</a>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

                # Expandable full paper details & BibTeX
                with st.expander(f"View Full Abstract & BibTeX for {p['id']}"):
                    st.markdown("**Full Abstract:**")
                    st.write(p.get("abstract"))
                    st.markdown("**BibTeX Citation:**")
                    bibtex = (
                        f"@article{{arxiv_{p['id'].replace('.', '_')},\n"
                        f"  title={{{p.get('title')}}},\n"
                        f"  author={{{p.get('authors')}}},\n"
                        f"  journal={{arXiv preprint arXiv:{p['id']}}},\n"
                        f"  year={{{p.get('year')}}}\n"
                        f"}}"
                    )
                    st.code(bibtex, language="bibtex")


# ==========================================
# TAB 3: CONCEPT GRAPH VISUALIZER
# ==========================================
with tab_graph:
    st.markdown("### 🗺️ Research Literature Concept Map")
    st.caption("Visualizing hierarchical relationships and technical cross-references among indexed papers.")

    all_papers = retrieval_service.get_all_papers()
    if all_papers:
        # Generate comprehensive graph for top papers
        graph_lines = ["graph LR"]
        for p in all_papers[:6]:
            pid = p.get("id").replace(".", "_")
            title = p.get("title")[:30] + "..."
            cat = p.get("primary_category", "cs.AI")
            graph_lines.append(f'    P_{pid}["{title}"] --> C_{cat}["{cat}"]')
            
        render_mermaid("\n".join(graph_lines), height=380)
    else:
        st.info("No papers currently loaded. Use the Knowledge Base tab to ingest papers.")


# ==========================================
# TAB 4: KNOWLEDGE BASE MANAGEMENT
# ==========================================
with tab_ingest:
    st.markdown("### 📚 Knowledge Base Ingestion & Preprocessing")
    st.caption("Manage, upload, and incrementally index arXiv research papers into the vector and lexical index.")

    col_up, col_info = st.columns([1, 1])

    with col_up:
        st.markdown("#### 📤 Upload arXiv Records")
        uploaded_file = st.file_uploader(
            "Upload arXiv JSON or JSONL file",
            type=["json", "jsonl"],
            help="Upload raw or pre-filtered arXiv papers matching Kaggle schema.",
        )
        if uploaded_file is not None:
            if st.button("📥 Ingest and Index File", type="primary"):
                try:
                    content = uploaded_file.read().decode("utf-8")
                    if content.strip().startswith("["):
                        new_papers = json.loads(content)
                    else:
                        new_papers = [json.loads(line) for line in content.splitlines() if line.strip()]

                    added = retrieval_service.index_papers_batch(new_papers)
                    st.success(f"Successfully indexed {added} new unique papers into the knowledge base!")
                except Exception as e:
                    st.error(f"Error parsing uploaded file: {e}")

        st.markdown("---")
        st.markdown("#### 🔄 Reset to Sample Dataset")
        if st.button("Reload Bundled CS Papers"):
            if config.sample_data_path.exists():
                count = retrieval_service.load_from_json(config.sample_data_path)
                st.success(f"Reloaded {count} seminal research papers.")
                st.rerun()

    with col_info:
        st.markdown("#### 📋 Dataset Schema & Acquisition")
        st.markdown(
            """
            This application uses metadata from the **Cornell University arXiv Dataset** hosted on Kaggle:
            - **Source:** [Kaggle arXiv Dataset](https://www.kaggle.com/datasets/Cornell-University/arxiv)
            - **License:** CC0 1.0 Universal Public Domain
            - **Attribution:** arXiv is maintained by Cornell University.
            - **Schema fields validated:** `id`, `title`, `authors`, `categories`, `abstract`, `versions`, `doi`
            - **Abstract vs Full Text:** Only peer-reviewed abstracts and bibliographic metadata are indexed.
            """
        )
