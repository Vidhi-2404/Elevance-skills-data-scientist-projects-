"""
Tests for arXiv Dataset Preprocessing and Parsing (scripts/prepare_arxiv.py).
"""

import json
from pathlib import Path
from scripts.prepare_arxiv import (
    clean_text,
    extract_year_from_versions,
    validate_and_normalize_paper,
    process_arxiv_dataset,
    DEFAULT_CS_CATEGORIES,
)


def test_clean_text():
    raw = "  This is a   title\nwith tabs\tand multiple   spaces.  "
    expected = "This is a title with tabs and multiple spaces."
    assert clean_text(raw) == expected
    assert clean_text(None) == ""


def test_extract_year():
    versions = [{"version": "v1", "created": "Mon, 12 Jun 2017 17:57:34 GMT"}]
    assert extract_year_from_versions(versions, "2018-01-01") == "2017"
    
    # Fallback to update_date
    assert extract_year_from_versions([], "2020-05-15") == "2020"
    
    # No date info
    assert extract_year_from_versions([], None) == "Unknown"


def test_validate_and_normalize_valid(raw_kaggle_records):
    valid_record = raw_kaggle_records[0]
    normalized = validate_and_normalize_paper(valid_record, allowed_categories=DEFAULT_CS_CATEGORIES)
    
    assert normalized is not None
    assert normalized["id"] == "2101.11111"
    assert normalized["title"] == "Deep Neural Networks with Adaptive Learning Rates"
    assert "We investigate adaptive learning rates" in normalized["abstract"]
    assert normalized["primary_category"] == "cs.LG"
    assert normalized["year"] == "2021"
    assert normalized["arxiv_url"] == "https://arxiv.org/abs/2101.11111"
    assert normalized["pdf_url"] == "https://arxiv.org/pdf/2101.11111.pdf"
    assert normalized["doi_url"] == "https://doi.org/10.1145/test"
    assert normalized["is_full_text"] is False


def test_validate_and_normalize_missing_fields(raw_kaggle_records):
    # Missing abstract
    assert validate_and_normalize_paper(raw_kaggle_records[1]) is None
    # Missing ID
    assert validate_and_normalize_paper(raw_kaggle_records[2]) is None


def test_category_filtering(raw_kaggle_records):
    physics_paper = raw_kaggle_records[3]
    # Filter with CS categories should exclude physics
    assert validate_and_normalize_paper(physics_paper, allowed_categories=DEFAULT_CS_CATEGORIES) is None
    
    # Allowed when allowed_categories is None
    assert validate_and_normalize_paper(physics_paper, allowed_categories=None) is not None


def test_process_arxiv_dataset_streaming_and_deduplication(tmp_path, raw_kaggle_records):
    # Write a file with valid records + duplicate record + malformed line
    input_file = tmp_path / "raw_input.jsonl"
    with open(input_file, "w", encoding="utf-8") as f:
        # Valid record 1
        f.write(json.dumps(raw_kaggle_records[0]) + "\n")
        # Malformed JSON line
        f.write("{this is not valid json}\n")
        # Duplicate of record 1
        f.write(json.dumps(raw_kaggle_records[0]) + "\n")
        # Invalid missing field record
        f.write(json.dumps(raw_kaggle_records[1]) + "\n")
        # Valid distinct record
        distinct = dict(raw_kaggle_records[0])
        distinct["id"] = "2101.99999"
        distinct["title"] = "Different Title on Machine Learning"
        f.write(json.dumps(distinct) + "\n")

    output_file = tmp_path / "output_processed.json"
    count = process_arxiv_dataset(input_file, output_file, categories=None)

    assert count == 2
    assert output_file.exists()

    with open(output_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert len(data) == 2
    ids = [p["id"] for p in data]
    assert "2101.11111" in ids
    assert "2101.99999" in ids
