"""
Shared Pytest Fixtures with Synthetic arXiv Research Papers.
"""

import pytest
from typing import Any, Dict, List


@pytest.fixture
def synthetic_valid_papers() -> List[Dict[str, Any]]:
    """Fixture providing clean, valid synthetic research papers across multiple CS categories."""
    return [
        {
            "id": "2401.00001",
            "title": "Scalable Transformers with Sparse Attention Matrices",
            "abstract": "We introduce a sparse attention matrix mechanism that scales Transformers linearly with sequence length. Our algorithm achieves state of the art latency on long context NLP benchmarks while reducing memory usage by 4x.",
            "authors": "Alice Smith, Bob Jones",
            "categories": "cs.CL cs.LG",
            "primary_category": "cs.CL",
            "category_list": ["cs.CL", "cs.LG"],
            "year": "2024",
            "arxiv_url": "https://arxiv.org/abs/2401.00001",
            "pdf_url": "https://arxiv.org/pdf/2401.00001.pdf",
            "doi": "10.1000/182",
            "doi_url": "https://doi.org/10.1000/182",
            "is_full_text": False,
        },
        {
            "id": "2305.99999",
            "title": "Efficient Vision Transformers via Token Pruning",
            "abstract": "Vision transformers suffer from high computational cost during inference. We propose a dynamic token pruning framework that adaptively discards uninformative patches in image recognition tasks, accelerating inference speed by 50%.",
            "authors": "Carol White, David Green",
            "categories": "cs.CV cs.AI",
            "primary_category": "cs.CV",
            "category_list": ["cs.CV", "cs.AI"],
            "year": "2023",
            "arxiv_url": "https://arxiv.org/abs/2305.99999",
            "pdf_url": "https://arxiv.org/pdf/2305.99999.pdf",
            "doi": None,
            "doi_url": None,
            "is_full_text": False,
        },
        {
            "id": "2209.12345",
            "title": "Robust Reinforcement Learning in Adversarial Robotics",
            "abstract": "Deep reinforcement learning policies often fail when transferred to real world robotics due to noise. We demonstrate an adversarial training curriculum that guarantees bounded policy error under physical perturbation.",
            "authors": "Eve Black, Frank Miller",
            "categories": "cs.RO cs.LG",
            "primary_category": "cs.RO",
            "category_list": ["cs.RO", "cs.LG"],
            "year": "2022",
            "arxiv_url": "https://arxiv.org/abs/2209.12345",
            "pdf_url": "https://arxiv.org/pdf/2209.12345.pdf",
            "doi": None,
            "doi_url": None,
            "is_full_text": False,
        },
    ]


@pytest.fixture
def raw_kaggle_records() -> List[Dict[str, Any]]:
    """Fixture providing raw Kaggle arXiv records including missing values and malformed items."""
    return [
        {
            "id": "2101.11111",
            "submitter": "Test Submitter",
            "authors": "Jane Doe, John Smith",
            "title": "  Deep Neural Networks   with Adaptive Learning Rates\n  ",
            "comments": "12 pages",
            "journal-ref": None,
            "doi": "10.1145/test",
            "report-no": None,
            "categories": "cs.LG cs.AI",
            "license": "http://arxiv.org/licenses/nonexclusive-distrib/1.0/",
            "abstract": "  We investigate adaptive learning rates for deep networks.\nResults show fast convergence.  ",
            "versions": [{"version": "v1", "created": "Mon, 18 Jan 2021 12:00:00 GMT"}],
            "update_date": "2021-01-18",
            "authors_parsed": [["Doe", "Jane", ""], ["Smith", "John", ""]],
        },
        {
            # Missing abstract - invalid
            "id": "2101.22222",
            "title": "Paper Without Abstract",
            "abstract": "",
            "categories": "cs.LG",
        },
        {
            # Missing ID - invalid
            "id": "",
            "title": "Paper Without ID",
            "abstract": "Valid abstract text.",
            "categories": "cs.LG",
        },
        {
            # Non-CS category - should be filterable
            "id": "2101.33333",
            "title": "Quantum Mechanics of Spin Chains",
            "abstract": "A theoretical study in quantum physics.",
            "authors": "Physicist One",
            "categories": "quant-ph physics.chem-ph",
            "versions": [{"version": "v1", "created": "Sun, 10 Jan 2021 10:00:00 GMT"}],
        },
    ]
