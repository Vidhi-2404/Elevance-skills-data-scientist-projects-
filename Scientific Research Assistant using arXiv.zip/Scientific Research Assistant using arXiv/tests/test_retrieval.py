"""
Tests for Retrieval Service (services/retrieval_service.py).
"""

from services.retrieval_service import RetrievalService, normalize_title


def test_normalize_title():
    assert normalize_title("Attention Is All You Need!") == "attention is all you need"
    assert normalize_title("  BERT: Pre-training of Deep... ") == "bert pretraining of deep"


def test_indexing_and_duplicate_detection(synthetic_valid_papers):
    service = RetrievalService(chroma_db_dir=None)  # in-memory
    assert len(service.papers_store) == 0

    # Index first paper
    p1 = synthetic_valid_papers[0]
    added = service.index_paper(p1)
    assert added is True
    assert len(service.papers_store) == 1

    # Attempt duplicate by ID
    dup_id = service.index_paper(p1)
    assert dup_id is False
    assert len(service.papers_store) == 1

    # Attempt duplicate by title with different ID
    p_dup_title = dict(p1)
    p_dup_title["id"] = "9999.99999"
    dup_title = service.index_paper(p_dup_title)
    assert dup_title is False
    assert len(service.papers_store) == 1


def test_batch_indexing(synthetic_valid_papers):
    service = RetrievalService(chroma_db_dir=None)
    added_count = service.index_papers_batch(synthetic_valid_papers)
    assert added_count == 3
    assert len(service.papers_store) == 3
    assert service.get_paper_by_id("2401.00001") is not None


def test_keyword_search_tfidf(synthetic_valid_papers):
    service = RetrievalService(chroma_db_dir=None)
    service.index_papers_batch(synthetic_valid_papers)

    # Search for vision / patches
    results = service.search_keyword("vision transformers token pruning patches", top_k=2)
    assert len(results) > 0
    top_hit = results[0]
    assert top_hit["id"] == "2305.99999"
    assert "retrieval_score" in top_hit
    assert top_hit["retrieval_method"] == "TF-IDF Lexical Match"


def test_category_and_year_filtering(synthetic_valid_papers):
    service = RetrievalService(chroma_db_dir=None)
    service.index_papers_batch(synthetic_valid_papers)

    # Filter by category cs.RO (robotics)
    results = service.search_keyword("transformers robotics error", top_k=5, category_filter="cs.RO")
    assert len(results) == 1
    assert results[0]["id"] == "2209.12345"

    # Filter by year range (exclude 2024 paper)
    year_filtered = service.search_keyword("transformers", top_k=5, year_filter=(2022, 2023))
    for r in year_filtered:
        assert int(r["year"]) in (2022, 2023)


def test_empty_query_and_no_crash(synthetic_valid_papers):
    service = RetrievalService(chroma_db_dir=None)
    assert service.search_keyword("") == []
    assert service.search_semantic("") == []
    assert service.search_hybrid("") == []

    # With indexed papers
    service.index_papers_batch(synthetic_valid_papers)
    assert service.search_keyword("") == []
    assert service.search_keyword("xyznonexistentterm123456") == []
