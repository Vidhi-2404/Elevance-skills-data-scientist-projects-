"""
Tests for Research Service (services/research_service.py).
"""

from services.research_service import ResearchService, clean_mermaid_label, extract_top_sentences


def test_clean_mermaid_label():
    dirty = 'Method "Attention" (Self-Attention) [2017] {O(N^2)}'
    cleaned = clean_mermaid_label(dirty)
    assert '"' not in cleaned
    assert '(' not in cleaned
    assert ')' not in cleaned
    assert '[' not in cleaned
    assert ']' not in cleaned


def test_extract_top_sentences():
    abstract = (
        "Deep learning has achieved breakthrough performance in vision. "
        "We introduce a sparse attention matrix mechanism that scales Transformers linearly with sequence length. "
        "Our experiments show 4x memory savings on benchmark datasets."
    )
    sents = extract_top_sentences(abstract, "sparse attention transformers memory", max_sentences=2)
    assert len(sents) <= 2
    assert any("sparse attention matrix mechanism" in s for s in sents)


def test_free_retrieval_answer_synthesis(synthetic_valid_papers):
    service = ResearchService(gemini_api_key="")
    query = "How to scale Transformers to long sequence lengths?"

    res = service.answer_query(
        query=query,
        retrieved_papers=synthetic_valid_papers,
        engine_mode="retrieval_free",
    )

    assert res["is_generative_ai"] is False
    assert "Free Retrieval-Based" in res["engine_used"]
    assert res["abstract_only_disclosure"] is True
    assert res["source_papers_count"] == len(synthetic_valid_papers)

    # Check multi-level explanations
    assert len(res["beginner_explanation"]) > 20
    assert len(res["intermediate_explanation"]) > 20
    assert len(res["advanced_explanation"]) > 20

    # Check citations integrity: IDs must belong to synthetic_valid_papers
    valid_ids = {p["id"] for p in synthetic_valid_papers}
    assert len(res["citations"]) == len(synthetic_valid_papers)
    for cit in res["citations"]:
        assert cit["paper_id"] in valid_ids
        assert cit["arxiv_url"] == f"https://arxiv.org/abs/{cit['paper_id']}"
        assert len(cit["evidence_quote"]) > 0

    # Check Mermaid diagram
    mermaid = res["concept_map_mermaid"]
    assert "graph TD" in mermaid
    assert "Query:" in mermaid

    # Check follow-ups
    assert len(res["follow_up_questions"]) >= 3


def test_empty_results_graceful_handling():
    service = ResearchService(gemini_api_key="")
    res = service.answer_query(
        query="Unrelated query",
        retrieved_papers=[],
        engine_mode="retrieval_free",
    )

    assert res["source_papers_count"] == 0
    assert "No matching research papers" in res["summary"]
    assert len(res["citations"]) == 0
    assert "graph TD" in res["concept_map_mermaid"]


def test_gemini_fallback_when_invalid_key(synthetic_valid_papers):
    # Pass an invalid key - when called, should gracefully fall back to Free Retrieval
    service = ResearchService(gemini_api_key="invalid_fake_key_12345")
    res = service.answer_query(
        query="What is sparse attention?",
        retrieved_papers=synthetic_valid_papers,
        engine_mode="gemini",
    )

    # Must not crash! Must fall back cleanly
    assert res is not None
    assert "summary" in res
    assert len(res["citations"]) > 0
    if res.get("fallback_occurred"):
        assert res.get("fallback_reason") is not None
