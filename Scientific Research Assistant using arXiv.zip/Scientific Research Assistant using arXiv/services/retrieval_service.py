"""
Retrieval Service: Dual-Engine Vector and Lexical Retrieval with Incremental Indexing.

Features:
- ChromaDB vector collection for dense semantic search
- Scikit-Learn TF-IDF vectorizer for instantaneous, 100% offline lexical search
- Hybrid Search combining semantic similarity and BM25/TF-IDF ranking
- Incremental indexing with duplicate detection (by paper ID & normalized title)
- Category and Year metadata filtering
- In-memory fast document cache for zero-latency paper lookups
"""

import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

try:
    import chromadb
    from chromadb.config import Settings
    CHROMA_AVAILABLE = True
except ImportError:
    CHROMA_AVAILABLE = False

logger = logging.getLogger(__name__)


def normalize_title(title: str) -> str:
    """Normalize paper title for fuzzy duplicate detection."""
    clean = re.sub(r"[^\w\s]", "", title.lower())
    return re.sub(r"\s+", " ", clean).strip()


class RetrievalService:
    def __init__(self, chroma_db_dir: Optional[Path] = None, collection_name: str = "arxiv_papers"):
        self.chroma_db_dir = chroma_db_dir
        self.collection_name = collection_name
        self.papers_store: Dict[str, Dict[str, Any]] = {}
        self.title_to_id: Dict[str, str] = {}
        
        # TF-IDF Lexical Index
        self.tfidf_vectorizer: Optional[TfidfVectorizer] = None
        self.tfidf_matrix = None
        self.indexed_doc_ids: List[str] = []

        # Vector Index (ChromaDB)
        self.chroma_client = None
        self.chroma_collection = None
        self._init_chroma()

    def _init_chroma(self):
        """Initialize ChromaDB client and collection with safe fallback."""
        if not CHROMA_AVAILABLE:
            logger.info("ChromaDB not installed; using TF-IDF vector indexing exclusively.")
            return

        try:
            if self.chroma_db_dir:
                self.chroma_db_dir.mkdir(parents=True, exist_ok=True)
                self.chroma_client = chromadb.PersistentClient(
                    path=str(self.chroma_db_dir),
                    settings=Settings(anonymized_telemetry=False)
                )
            else:
                self.chroma_client = chromadb.Client(
                    settings=Settings(anonymized_telemetry=False)
                )

            self.chroma_collection = self.chroma_client.get_or_create_collection(
                name=self.collection_name,
                metadata={"description": "ArXiv Computer Science Research Papers"}
            )
            logger.info("ChromaDB collection '%s' initialized.", self.collection_name)
        except Exception as e:
            logger.warning("Could not initialize ChromaDB: %s. Using TF-IDF fallback.", e)
            self.chroma_collection = None

    def detect_duplicate(self, paper_id: str, title: str) -> Tuple[bool, str]:
        """
        Check if paper is already indexed by exact ID or normalized title.
        Returns: (is_duplicate, reason)
        """
        if paper_id in self.papers_store:
            return True, f"Paper with ID '{paper_id}' already exists."

        norm_title = normalize_title(title)
        if norm_title in self.title_to_id:
            existing_id = self.title_to_id[norm_title]
            return True, f"Duplicate title match with existing paper ID '{existing_id}'."

        return False, ""

    def index_paper(self, paper: Dict[str, Any], rebuild_tfidf: bool = True) -> bool:
        """
        Index a single paper incrementally into memory, TF-IDF, and ChromaDB.
        Returns True if paper was newly added, False if duplicate or invalid.
        """
        paper_id = str(paper.get("id", "")).strip()
        title = paper.get("title", "").strip()
        abstract = paper.get("abstract", "").strip()

        if not paper_id or not title or not abstract:
            return False

        is_dup, reason = self.detect_duplicate(paper_id, title)
        if is_dup:
            logger.debug("Skipping duplicate: %s", reason)
            return False

        # Store in document lookup
        self.papers_store[paper_id] = paper
        self.title_to_id[normalize_title(title)] = paper_id

        # Insert into ChromaDB collection if active
        if self.chroma_collection:
            try:
                text_to_embed = f"Title: {title}\nAbstract: {abstract}"
                meta = {
                    "paper_id": paper_id,
                    "title": title[:300],
                    "categories": paper.get("categories", "")[:200],
                    "primary_category": paper.get("primary_category", "")[:50],
                    "year": str(paper.get("year", "Unknown")),
                }
                self.chroma_collection.upsert(
                    ids=[paper_id],
                    documents=[text_to_embed],
                    metadatas=[meta]
                )
            except Exception as e:
                logger.warning("Failed to index paper %s in ChromaDB: %s", paper_id, e)

        if rebuild_tfidf:
            self._rebuild_tfidf_index()

        return True

    def index_papers_batch(self, papers: List[Dict[str, Any]]) -> int:
        """
        Index a list of papers in batch with single TF-IDF index compilation.
        Returns count of newly indexed papers.
        """
        added_count = 0
        chroma_ids = []
        chroma_docs = []
        chroma_metas = []

        for p in papers:
            paper_id = str(p.get("id", "")).strip()
            title = p.get("title", "").strip()
            abstract = p.get("abstract", "").strip()
            if not paper_id or not title or not abstract:
                continue

            is_dup, _ = self.detect_duplicate(paper_id, title)
            if is_dup:
                continue

            self.papers_store[paper_id] = p
            self.title_to_id[normalize_title(title)] = paper_id
            added_count += 1

            if self.chroma_collection:
                chroma_ids.append(paper_id)
                chroma_docs.append(f"Title: {title}\nAbstract: {abstract}")
                chroma_metas.append({
                    "paper_id": paper_id,
                    "title": title[:300],
                    "categories": p.get("categories", "")[:200],
                    "primary_category": p.get("primary_category", "")[:50],
                    "year": str(p.get("year", "Unknown")),
                })

        # Batch upsert to Chroma
        if self.chroma_collection and chroma_ids:
            try:
                self.chroma_collection.upsert(
                    ids=chroma_ids,
                    documents=chroma_docs,
                    metadatas=chroma_metas
                )
            except Exception as e:
                logger.warning("ChromaDB batch upsert error: %s", e)

        self._rebuild_tfidf_index()
        logger.info("Indexed %d new papers. Total indexed: %d", added_count, len(self.papers_store))
        return added_count

    def load_from_json(self, file_path: Path) -> int:
        """Load and index papers from a JSON or JSONL file."""
        if not file_path.exists():
            logger.warning("File not found: %s", file_path)
            return 0

        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            first_char = f.read(1)
            f.seek(0)
            if first_char == "[":
                try:
                    papers = json.load(f)
                except Exception as e:
                    logger.error("Error reading JSON file %s: %s", file_path, e)
                    return 0
            else:
                papers = []
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            papers.append(json.loads(line))
                        except Exception:
                            continue

        return self.index_papers_batch(papers)

    def _rebuild_tfidf_index(self):
        """Fit or refit TF-IDF matrix over all indexed documents."""
        if not self.papers_store:
            self.tfidf_vectorizer = None
            self.tfidf_matrix = None
            self.indexed_doc_ids = []
            return

        corpus = []
        self.indexed_doc_ids = list(self.papers_store.keys())

        for pid in self.indexed_doc_ids:
            p = self.papers_store[pid]
            # Combine title (given higher weight by repetition) and abstract
            doc_text = f"{p.get('title', '')} {p.get('title', '')} {p.get('abstract', '')} {p.get('categories', '')}"
            corpus.append(doc_text)

        self.tfidf_vectorizer = TfidfVectorizer(
            ngram_range=(1, 2),
            stop_words="english",
            sublinear_tf=True,
            max_features=25000,
        )
        self.tfidf_matrix = self.tfidf_vectorizer.fit_transform(corpus)

    def _passes_filters(
        self,
        paper: Dict[str, Any],
        category_filter: Optional[str] = None,
        year_filter: Optional[Tuple[int, int]] = None,
    ) -> bool:
        """Check if paper meets category and year constraints."""
        if category_filter and category_filter != "All":
            paper_cats = paper.get("categories", "").split()
            if category_filter not in paper_cats and paper.get("primary_category") != category_filter:
                return False

        if year_filter:
            try:
                min_year, max_year = year_filter
                paper_year = int(paper.get("year", 0))
                if paper_year != 0 and (paper_year < min_year or paper_year > max_year):
                    return False
            except (ValueError, TypeError):
                pass

        return True

    def search_keyword(
        self,
        query: str,
        top_k: int = 5,
        category_filter: Optional[str] = None,
        year_filter: Optional[Tuple[int, int]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Perform fast, free lexical search using TF-IDF cosine similarity.
        Works 100% offline without any API keys or GPU memory.
        """
        if not query.strip() or not self.papers_store or self.tfidf_vectorizer is None or self.tfidf_matrix is None:
            return []

        try:
            query_vec = self.tfidf_vectorizer.transform([query])
            scores = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
            
            # Sort descending by score
            top_indices = np.argsort(scores)[::-1]
            
            results = []
            for idx in top_indices:
                score = float(scores[idx])
                if score <= 0.001:
                    break
                pid = self.indexed_doc_ids[idx]
                paper = self.papers_store[pid]
                
                if not self._passes_filters(paper, category_filter, year_filter):
                    continue

                res = dict(paper)
                res["retrieval_score"] = round(score, 4)
                res["retrieval_method"] = "TF-IDF Lexical Match"
                results.append(res)
                if len(results) >= top_k:
                    break

            return results
        except Exception as e:
            logger.error("TF-IDF search error: %s", e)
            return []

    def search_semantic(
        self,
        query: str,
        top_k: int = 5,
        category_filter: Optional[str] = None,
        year_filter: Optional[Tuple[int, int]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Dense vector semantic search using ChromaDB.
        Falls back automatically to TF-IDF if ChromaDB is unavailable.
        """
        if not self.chroma_collection or len(self.papers_store) == 0:
            return self.search_keyword(query, top_k, category_filter, year_filter)

        try:
            fetch_k = min(top_k * 3, len(self.papers_store))
            query_res = self.chroma_collection.query(
                query_texts=[query],
                n_results=fetch_k
            )

            ids = query_res["ids"][0] if query_res.get("ids") else []
            distances = query_res["distances"][0] if query_res.get("distances") else []

            results = []
            for i, pid in enumerate(ids):
                if pid not in self.papers_store:
                    continue
                paper = self.papers_store[pid]
                if not self._passes_filters(paper, category_filter, year_filter):
                    continue

                dist = distances[i] if i < len(distances) else 1.0
                # Convert distance to similarity score
                similarity = round(max(0.0, 1.0 - (dist / 2.0)), 4)

                res = dict(paper)
                res["retrieval_score"] = similarity
                res["retrieval_method"] = "ChromaDB Semantic Vector"
                results.append(res)
                if len(results) >= top_k:
                    break

            if not results:
                # If vector search returned nothing due to filters, try TF-IDF fallback
                return self.search_keyword(query, top_k, category_filter, year_filter)

            return results
        except Exception as e:
            logger.warning("ChromaDB query failed (%s). Falling back to TF-IDF.", e)
            return self.search_keyword(query, top_k, category_filter, year_filter)

    def search_hybrid(
        self,
        query: str,
        top_k: int = 5,
        category_filter: Optional[str] = None,
        year_filter: Optional[Tuple[int, int]] = None,
        semantic_weight: float = 0.6,
    ) -> List[Dict[str, Any]]:
        """
        Hybrid search combining Dense Semantic + TF-IDF Lexical scores.
        """
        lexical_results = self.search_keyword(query, top_k=top_k * 2, category_filter=category_filter, year_filter=year_filter)
        semantic_results = self.search_semantic(query, top_k=top_k * 2, category_filter=category_filter, year_filter=year_filter)

        combined_scores: Dict[str, float] = {}
        paper_map: Dict[str, Dict[str, Any]] = {}

        lexical_weight = 1.0 - semantic_weight

        for item in semantic_results:
            pid = item["id"]
            paper_map[pid] = item
            combined_scores[pid] = combined_scores.get(pid, 0.0) + (item["retrieval_score"] * semantic_weight)

        for item in lexical_results:
            pid = item["id"]
            paper_map[pid] = item
            combined_scores[pid] = combined_scores.get(pid, 0.0) + (item["retrieval_score"] * lexical_weight)

        # Sort by combined score
        sorted_pids = sorted(combined_scores.keys(), key=lambda x: combined_scores[x], reverse=True)

        final_results = []
        for pid in sorted_pids[:top_k]:
            paper = dict(paper_map[pid])
            paper["retrieval_score"] = round(combined_scores[pid], 4)
            paper["retrieval_method"] = "Hybrid (Semantic + TF-IDF)"
            final_results.append(paper)

        return final_results

    def get_paper_by_id(self, paper_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve full record for a specific arXiv ID."""
        return self.papers_store.get(paper_id)

    def get_all_papers(self) -> List[Dict[str, Any]]:
        """Return all currently indexed papers."""
        return list(self.papers_store.values())

    def get_categories(self) -> List[str]:
        """Return unique sorted list of categories across indexed papers."""
        cats = set()
        for p in self.papers_store.values():
            for c in p.get("categories", "").split():
                if c.strip():
                    cats.add(c.strip())
        return sorted(list(cats))

    def get_stats(self) -> Dict[str, Any]:
        """Return index statistics."""
        return {
            "total_papers": len(self.papers_store),
            "categories_count": len(self.get_categories()),
            "chroma_active": self.chroma_collection is not None,
            "tfidf_active": self.tfidf_matrix is not None,
        }
